import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "../supabaseClient";
import "../styles.css";

export default function ResetPasswordPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [session, setSession] = useState(null);

  useEffect(() => {
    // Check if user came from password reset link
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) {
        setSession(session);
      } else {
        // No session means invalid or expired link
        setError("Invalid or expired password reset link. Please request a new one.");
      }
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    // Validation
    if (password.length < 6) {
      setError("Password must be at least 6 characters long");
      return;
    }

    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    setLoading(true);

    try {
      const { error: updateError } = await supabase.auth.updateUser({
        password: password
      });

      if (updateError) throw updateError;

      setSuccess(true);

      // Wait 2 seconds then redirect to login
      setTimeout(() => {
        supabase.auth.signOut();
        navigate("/");
      }, 2000);

    } catch (err) {
      console.error("Error updating password:", err);
      setError(err.message || "Failed to update password");
      setLoading(false);
    }
  };

  const handleBackToLogin = () => {
    supabase.auth.signOut();
    navigate("/");
  };

  if (success) {
    return (
      <div className="auth-page">
        <div className="auth-hero">
          <div className="hero-content">
            <h1 className="brand-big">Success!</h1>
            <p className="hero-sub">
              Your password has been updated successfully.
            </p>
          </div>
        </div>

        <div className="auth-card">
          <div style={{
            textAlign: "center",
            padding: "20px"
          }}>
            <div style={{
              fontSize: "64px",
              marginBottom: "16px"
            }}>
              ✅
            </div>
            <h3 style={{ color: "var(--pink)", marginBottom: "12px" }}>
              Password Reset Complete
            </h3>
            <p style={{ color: "#666", marginBottom: "24px" }}>
              You can now sign in with your new password.
            </p>
            <p style={{ color: "#999", fontSize: "14px" }}>
              Redirecting to login page...
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="auth-page">
      <div className="auth-hero">
        <div className="nav-slim">
          <span>Reset Your Password</span>
        </div>
        
        <div className="hero-content">
          <h1 className="brand-big">Hinahon</h1>
          <p className="hero-sub">
            Create a new password for your account.
          </p>
          <p className="hero-sub" style={{ marginTop: "16px", fontSize: "14px" }}>
            Choose a strong password that you haven't used before.
          </p>
        </div>
      </div>

      <div className="auth-card">
        <div className="card-header">
          <div className="logo-small">Reset Password</div>
          <div className="small-tag">Enter your new password</div>
        </div>

        {error && (
          <div style={{
            backgroundColor: "#ffebee",
            color: "#c62828",
            padding: "12px",
            borderRadius: "8px",
            fontSize: "13px",
            marginBottom: "12px"
          }}>
            {error}
          </div>
        )}

        {!session ? (
          <div style={{ textAlign: "center", padding: "20px" }}>
            <p style={{ color: "#666", marginBottom: "20px" }}>
              This password reset link is invalid or has expired.
            </p>
            <button
              onClick={handleBackToLogin}
              className="btn-primary"
              style={{ width: "100%" }}
            >
              Back to Login
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="login-form">
            <div className="field">
              <label style={{
                display: "block",
                marginBottom: "6px",
                fontSize: "13px",
                fontWeight: "600",
                color: "#333"
              }}>
                New Password *
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter new password"
                disabled={loading}
                required
                minLength="6"
              />
              <small style={{ color: "#666", fontSize: "12px", marginTop: "4px", display: "block" }}>
                Must be at least 6 characters
              </small>
            </div>

            <div className="field">
              <label style={{
                display: "block",
                marginBottom: "6px",
                fontSize: "13px",
                fontWeight: "600",
                color: "#333"
              }}>
                Confirm New Password *
              </label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirm new password"
                disabled={loading}
                required
                minLength="6"
              />
            </div>

            <button
              type="submit"
              className="btn-primary"
              disabled={loading}
              style={{
                opacity: loading ? 0.6 : 1,
                cursor: loading ? "not-allowed" : "pointer"
              }}
            >
              {loading ? "Updating Password..." : "Update Password"}
            </button>
          </form>
        )}

        <div style={{ 
          textAlign: "center", 
          marginTop: "16px",
          paddingTop: "16px",
          borderTop: "1px solid #e0e0e0"
        }}>
          <button
            onClick={handleBackToLogin}
            disabled={loading}
            style={{
              background: "none",
              border: "none",
              color: "var(--pink)",
              cursor: loading ? "not-allowed" : "pointer",
              textDecoration: "underline",
              fontSize: "14px",
              padding: "0",
              opacity: loading ? 0.6 : 1
            }}
          >
            ← Back to Login
          </button>
        </div>
      </div>
    </div>
  );
}