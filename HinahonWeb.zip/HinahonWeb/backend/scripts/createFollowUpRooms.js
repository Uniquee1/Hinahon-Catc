// backend/scripts/createFollowUpRooms.js
// This script should be run daily (via cron job) to create rooms for follow-up consultations scheduled for today

require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

const DAILY_API_KEY = process.env.DAILY_API_KEY;

/**
 * Main function to create rooms for today's follow-up consultations
 */
async function createRoomsForToday() {
  try {
    console.log('🚀 Starting follow-up room creation process...');
    console.log(`📅 Date: ${new Date().toISOString()}`);

    const today = new Date().toISOString().split('T')[0];

    // Get all follow-up consultations for today that don't have a room yet
    const { data: consultations, error } = await supabase
      .from('consultations')
      .select(`
        *,
        counselor:counselor_id(name, email),
        student:student_id(name, email)
      `)
      .eq('date', today)
      .eq('is_followup', true)
      .eq('status', 'accepted')
      .is('video_link', null);

    if (error) {
      console.error('❌ Error fetching follow-up consultations:', error);
      throw error;
    }

    if (!consultations || consultations.length === 0) {
      console.log('✅ No follow-up consultations need rooms today');
      return { success: true, created: 0, total: 0 };
    }

    console.log(`📋 Found ${consultations.length} follow-up consultation(s) needing rooms`);

    const results = [];

    // Import email functions
    const { sendAcceptanceNotification, sendCounselorAcceptanceNotification } = require('../utils/emailService');

    for (const consultation of consultations) {
      try {
        console.log(`\n🔨 Processing consultation ${consultation.id}...`);
        console.log(`   Student: ${consultation.student?.name || 'Unknown'}`);
        console.log(`   Counselor: ${consultation.counselor?.name || 'Unknown'}`);
        console.log(`   Time: ${consultation.time}`);

        // Create unique room name
        const roomName = `hinahon-followup-${consultation.id.slice(0, 8)}-${Date.now()}`;

        // Call Daily.co API to create room
        console.log('   📹 Creating Daily.co room...');
        const dailyResponse = await fetch('https://api.daily.co/v1/rooms', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${DAILY_API_KEY}`
          },
          body: JSON.stringify({
            name: roomName,
            properties: {
              enable_screenshare: true,
              enable_chat: true,
              start_video_off: false,
              start_audio_off: false,
              max_participants: 2,
              // Room expires 24 hours from now
              exp: Math.floor(Date.now() / 1000) + (24 * 60 * 60),
              enable_prejoin_ui: true,
            }
          })
        });

        if (!dailyResponse.ok) {
          const errorText = await dailyResponse.text();
          console.error(`   ❌ Daily.co API error:`, errorText);
          results.push({
            consultationId: consultation.id,
            success: false,
            error: `Daily.co API error: ${dailyResponse.status}`
          });
          continue;
        }

        const roomData = await dailyResponse.json();
        console.log(`   ✅ Room created: ${roomData.url}`);

        // Update consultation with video link
        const { error: updateError } = await supabase
          .from('consultations')
          .update({ video_link: roomData.url })
          .eq('id', consultation.id);

        if (updateError) {
          console.error(`   ❌ Error updating consultation:`, updateError);
          results.push({
            consultationId: consultation.id,
            success: false,
            error: 'Failed to save video link'
          });
          continue;
        }

        console.log('   💾 Database updated with video link');

        // Send room link emails to both parties
        const studentName = consultation.student?.name || consultation.student?.email?.split('@')[0] || 'Student';
        const counselorName = consultation.counselor?.name || consultation.counselor?.email?.split('@')[0] || 'Counselor';

        try {
          console.log('   📧 Sending email to student...');
          await sendAcceptanceNotification(
            consultation.student.email,
            studentName,
            counselorName,
            consultation.date,
            consultation.time,
            roomData.url
          );
          console.log('   ✅ Student email sent');

          // Wait 2 seconds before sending counselor email
          console.log('   ⏳ Waiting before sending counselor email...');
          await new Promise(resolve => setTimeout(resolve, 2000));

          console.log('   📧 Sending email to counselor...');
          await sendCounselorAcceptanceNotification(
            consultation.counselor.email,
            counselorName,
            studentName,
            consultation.student.email,
            consultation.date,
            consultation.time,
            roomData.url
          );
          console.log('   ✅ Counselor email sent');

        } catch (emailErr) {
          console.error('   ⚠️ Failed to send room link emails:', emailErr);
          // Don't fail the whole operation if email fails
        }

        results.push({
          consultationId: consultation.id,
          success: true,
          roomUrl: roomData.url
        });

        console.log(`   ✅ Successfully processed consultation ${consultation.id}`);

      } catch (err) {
        console.error(`   ❌ Error processing consultation ${consultation.id}:`, err);
        results.push({
          consultationId: consultation.id,
          success: false,
          error: err.message
        });
      }
    }

    const successCount = results.filter(r => r.success).length;
    const failCount = results.filter(r => !r.success).length;

    console.log('\n' + '='.repeat(60));
    console.log('📊 SUMMARY');
    console.log('='.repeat(60));
    console.log(`✅ Successful: ${successCount}/${results.length}`);
    console.log(`❌ Failed: ${failCount}/${results.length}`);
    console.log('='.repeat(60));

    return {
      success: true,
      created: successCount,
      failed: failCount,
      total: results.length,
      results: results
    };

  } catch (err) {
    console.error('❌ Fatal error in room creation process:', err);
    return {
      success: false,
      error: err.message
    };
  }
}

// Run the script
if (require.main === module) {
  createRoomsForToday()
    .then(result => {
      console.log('\n✅ Script completed');
      process.exit(result.success ? 0 : 1);
    })
    .catch(err => {
      console.error('\n❌ Script failed:', err);
      process.exit(1);
    });
}

module.exports = { createRoomsForToday };