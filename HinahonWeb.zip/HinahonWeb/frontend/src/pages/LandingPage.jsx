import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "../supabaseClient";
import Footer from "../components/Footer";
import { checkVideoLinkAccess, getConsultationStatusBadge } from "../utils/consultationTimeUtils";
import logo from "../assets/hinahon.png";
import logo1 from "../assets/lpub.png";
import logo2 from "../assets/catc.png";
import bgImage2 from "../assets/bg-lotus.jpg";
import bgImage3 from "../assets/bg-animated.gif";
import bgVideo from "../assets/bg-animated.mp4";
import AIAssistantFloating from "../components/AIAssistantFloating";
import "../styles.css";
import "../styles2.css";
import ResponsiveHeader from "../components/ResponsiveHeader";
import FeedbackModal from '../components/FeedbackModal';

export default function LandingPage({ session, setSession }) {
  const navigate = useNavigate();
  const user = session?.user;

  const [selectedEmotion, setSelectedEmotion] = useState(null);
  const [allConsultations, setAllConsultations] = useState([]);
  const [displayedConsultations, setDisplayedConsultations] = useState([]);
  const [loadingConsultations, setLoadingConsultations] = useState(true);
  const [userName, setUserName] = useState("");
  const [hasMore, setHasMore] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [showBookingsModal, setShowBookingsModal] = useState(false);
  const [showConsentModal, setShowConsentModal] = useState(false);
  const [pendingEmotion, setPendingEmotion] = useState(null);
  const [hasConsented, setHasConsented] = useState(false);
  const [hasOngoingConsultation, setHasOngoingConsultation] = useState(false);
  const [isFeedbackOpen, setIsFeedbackOpen] = useState(false);


  const observerTarget = useRef(null);
  const emotionsGridRef = useRef(null); // <-- ref to detect outside clicks
  const ITEMS_PER_PAGE = 3;

  useEffect(() => {
    if (user) {
      fetchUserName();
      fetchConsultations();
      checkConsentStatus();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);


  // Setup intersection observer for infinite scroll in modal
  useEffect(() => {
    if (!showBookingsModal) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !isLoadingMore) {
          loadMoreConsultations();
        }
      },
      { threshold: 0.1 }
    );

    const currentTarget = observerTarget.current;
    if (currentTarget) {
      observer.observe(currentTarget);
    }

    return () => {
      if (currentTarget) {
        observer.unobserve(currentTarget);
      }
    };
  }, [showBookingsModal, hasMore, isLoadingMore, displayedConsultations.length]);

  const fetchUserName = async () => {
    try {
      const { data, error } = await supabase.from("users").select("name").eq("id", user.id).single();
      if (error) throw error;
      setUserName(data?.name || user.email?.split("@")[0] || "User");
    } catch (err) {
      console.error("Error fetching user name:", err);
      setUserName(user.email?.split("@")[0] || "User");
    }
  };

  const checkConsentStatus = () => {
    try {
      const consentKey = `tele_counseling_consent_${user.id}`;
      const consentStatus = localStorage.getItem(consentKey);
      if (consentStatus === "accepted") {
        setHasConsented(true);
      }
    } catch (err) {
      console.error("Error checking consent status:", err);
    }
  };

  const fetchConsultations = async () => {
    try {
      const { data, error } = await supabase
        .from("consultations")
        .select(`
          id,
          date,
          time,
          status,
          video_link,
          reason,
          rejection_reason,
          meeting_ended,
          start_time,
          end_time,
          availability_id,
          counselor:counselor_id(name, email)
        `)
        .eq("student_id", user.id)
        .order("date", { ascending: true })
        .order("time", { ascending: true });

      if (error) throw error;

      const sortedConsultations = prioritizeConsultations(data || []);

      // Check if there's any ongoing consultation
      const hasOngoing = sortedConsultations.some((consultation) => {
        const accessInfo = checkVideoLinkAccess(consultation.date, consultation.time);
        return (
          consultation.status === "accepted" &&
          !consultation.meeting_ended &&
          accessInfo.canAccess &&
          accessInfo.reason === "active"
        );
      });
      setHasOngoingConsultation(hasOngoing);

      setAllConsultations(sortedConsultations);
      setDisplayedConsultations(sortedConsultations.slice(0, ITEMS_PER_PAGE));
      setHasMore(sortedConsultations.length > ITEMS_PER_PAGE);
    } catch (err) {
      console.error("Error fetching consultations:", err);
    } finally {
      setLoadingConsultations(false);
    }
  };

  const handleCancelConsultation = async (consultationId, availabilityId) => {
    if (!window.confirm("Are you sure you want to cancel this consultation request? This action cannot be undone.")) {
      return;
    }

    try {
      console.log("Cancelling consultation:", consultationId);

      // Update consultation status to cancelled
      const { error: consultationError } = await supabase
        .from("consultations")
        .update({ status: "cancelled" })
        .eq("id", consultationId)
        .eq("student_id", user.id) // Security: ensure only the student can cancel their own
        .eq("status", "pending"); // Only allow cancelling pending consultations

      if (consultationError) {
        console.error("Error updating consultation:", consultationError);
        throw consultationError;
      }

      console.log("✅ Consultation status updated to cancelled");

      // Free up the availability slot if it exists
      if (availabilityId) {
        const { error: availabilityError } = await supabase.from("availability").update({ is_booked: false }).eq("id", availabilityId);
        if (availabilityError) {
          console.warn("⚠️ Warning: Failed to free up availability slot:", availabilityError);
        } else {
          console.log("✅ Availability slot freed up");
        }
      }

      // Refresh consultations list
      await fetchConsultations();

      alert("✅ Consultation request cancelled successfully");
    } catch (err) {
      console.error("❌ Error cancelling consultation:", err);
      alert("Failed to cancel consultation: " + err.message);
    }
  };

  const prioritizeConsultations = (consultations) => {
    const categorized = consultations.map((consultation) => {
      const accessInfo = checkVideoLinkAccess(consultation.date, consultation.time);
      const consultDate = new Date(`${consultation.date}T${consultation.time}`);

      let priority = 0;
      let category = "";

      if (consultation.status === "accepted" && !consultation.meeting_ended && accessInfo.canAccess && accessInfo.reason === "active") {
        priority = 1;
        category = "ongoing";
      } else if (consultation.status === "pending") {
        priority = 2;
        category = "pending";
      } else if (consultation.status === "accepted" && !consultation.meeting_ended && accessInfo.reason === "not_started") {
        priority = 3;
        category = "upcoming";
      } else if (consultation.status === "cancelled") {
        priority = 6;
        category = "cancelled";
      } else if (consultation.meeting_ended || consultation.status === "completed") {
        priority = 5;
        category = "completed";
      } else {
        priority = 4;
        category = "past";
      }

      return { ...consultation, priority, category, consultDate, accessInfo };
    });

    // Sort by date descending (newest first)
    return categorized.sort((a, b) => {
      return b.consultDate - a.consultDate;
    });
  };

  const loadMoreConsultations = () => {
    if (isLoadingMore) return;

    setIsLoadingMore(true);

    setTimeout(() => {
      const currentLength = displayedConsultations.length;
      const nextBatch = allConsultations.slice(currentLength, currentLength + ITEMS_PER_PAGE);

      setDisplayedConsultations((prev) => [...prev, ...nextBatch]);
      setHasMore(currentLength + ITEMS_PER_PAGE < allConsultations.length);
      setIsLoadingMore(false);
    }, 300);
  };

  async function handleSignOut() {
    await supabase.auth.signOut();
    setSession(null);
    navigate("/");
  }

  const emotions = [
    { label: "Happy", icon: "🙂", tag: "happy" },
    { label: "Sad", icon: "😢", tag: "sad" },
    { label: "Angry", icon: "😡", tag: "angry" },
    { label: "Scared", icon: "😨", tag: "scared" },
    { label: "Worried", icon: "😟", tag: "worried" },
    { label: "Tired", icon: "😴", tag: "tired" },
    { label: "Disgusted", icon: "🤢", tag: "disgusted" },
    { label: "Overwhelmed", icon: "😵", tag: "overwhelmed" },
  ];

  // Toggle selection if same emotion clicked, otherwise select
  const handleEmotionClick = (label) => {
    setSelectedEmotion((prev) => (prev === label ? null : label));
  };

  // Also allow keyboard toggling (Enter / Space) for accessibility
  const handleEmotionKeyDown = (e, label) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      handleEmotionClick(label);
    }
  };

  // Detect clicks outside emotions grid (but ignore clicks on buttons or interactive elements)
  useEffect(() => {
    let touchStartTime = 0;

    function handleClickOutside(event) {
      // Don't deselect if clicked inside the emotions grid
      if (emotionsGridRef.current?.contains(event.target)) return;

      const clickableTags = ["BUTTON", "A", "INPUT", "SELECT", "TEXTAREA", "LABEL"];
      if (
        clickableTags.includes(event.target.tagName) ||
        event.target.closest("button, a, input, select, textarea, label, [role='button']")
      ) {
        return;
      }

      setSelectedEmotion(null);
    }

    function handleTouchStart(event) {
      touchStartTime = Date.now(); // record time touch began
    }

    function handleTouchEnd(event) {
      const touchDuration = Date.now() - touchStartTime;

      // Only deselect if it was a QUICK TAP (less than 200ms)
      if (touchDuration < 200) {
        handleClickOutside(event);
      }
    }

    // Desktop: immediate deselection
    document.addEventListener("mousedown", handleClickOutside);

    // Mobile: tap-based deselection
    document.addEventListener("touchstart", handleTouchStart, { passive: true });
    document.addEventListener("touchend", handleTouchEnd, { passive: true });

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("touchstart", handleTouchStart);
      document.removeEventListener("touchend", handleTouchEnd);
    };
  }, []);



  function handleBookAppointment() {
    const emotion = emotions.find((e) => e.label === selectedEmotion);
    const emotionTag = emotion?.tag || "general";

    // Check if user has already consented
    if (hasConsented) {
      // Skip consent modal and go directly to booking
      navigate("/booking", { state: { emotion: emotionTag } });
    } else {
      // Show consent modal for first-time users
      setPendingEmotion(emotionTag);
      setShowConsentModal(true);
    }
  }

  function handleConsentAccept() {
    try {
      // Save consent to localStorage
      const consentKey = `tele_counseling_consent_${user.id}`;
      localStorage.setItem(consentKey, "accepted");
      setHasConsented(true);
    } catch (err) {
      console.error("Error saving consent:", err);
    }

    setShowConsentModal(false);
    navigate("/booking", { state: { emotion: pendingEmotion } });
  }

  function handleConsentReject() {
    setShowConsentModal(false);
    setPendingEmotion(null);
  }

  function handleReadArticles() {
    const emotion = emotions.find((e) => e.label === selectedEmotion);
    const emotionTag = emotion?.tag || "happy";
    navigate(`/articles/${emotionTag}`);
  }

  const formatDate = (dateStr) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  const formatTime = (timeStr) => {
    const [hours, minutes] = timeStr.split(":");
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? "PM" : "AM";
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  const getStatusColor = (status, date, time) => {
    return getConsultationStatusBadge(status, date, time);
  };

  return (
    /*
      Key change to keep the footer pinned to bottom on desktop (and still behave
      responsively on mobile):
      - Make the root a column flex container with min-height: 100vh
      - Make the main content area grow (flex: 1)
      - Wrap Footer in a container with marginTop: 'auto' so it is pushed to the bottom
      This approach doesn't change other code or the DOM structure besides adding
      a couple of safe layout styles.
    */
    <div
      className="landing-root"
      style={{
        position: "relative",
        minHeight: "100vh",
        overflow: "hidden",
        display: "flex",
        flexDirection: "column"
      }}
    >
      <div>
        <video
          key={bgVideo}
          autoPlay
          loop
          muted
          playsInline
          poster={bgImage3}
          aria-hidden="true"
          style={{
            position: "absolute",
            top: "49%",
            left: "50%",
            width: "145%",
            height: "115%",
            transform: "translate(-50%, -50%) scale(0.78)",
            transformOrigin: "center center",
            objectFit: "cover",
            zIndex: 0,
          }}
        >
          <source src={bgVideo} type="video/mp4" />
        </video>

        <div />
      </div>

      {/* make this content wrapper take available vertical space so footer can sit at bottom */} 
      <div style={{ position: "relative", zIndex: 2, display: "flex", flexDirection: "column", flex: 1 }}>
        <style>{`
          /* One-time entrance for header title */
          @keyframes fadeIn {
            from { opacity: 0; transform: translateY(8px) scale(0.99); filter: blur(2px); }
            to { opacity: 1; transform: translateY(0) scale(1); filter: blur(0); }
          }
          /* Continuous float for the title */

          .animated-welcome {
            display: inline-block;
            will-change: transform, opacity;
            text-shadow: 0 6px 18px rgba(0,0,0,0.18);
            background: linear-gradient(90deg, #c71e70, #41c6b7ff);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
          }

          /* Emotion idle animation (subtle float + gentle glow) */
          @keyframes emotionFloat {
            0% { transform: translateY(0) scale(1); }
            25% { transform: translateY(-3px) scale(1.03); }
            50% { transform: translateY(0) scale(1); }
            75% { transform: translateY(-2px) scale(1.02); }
            100% { transform: translateY(0) scale(1); }
          }
          @keyframes emotionGlow {
            0% { box-shadow: 0 0 0px rgba(199,30,112,0.0); }
            50% { box-shadow: 0 10px 24px rgba(199,30,112,0.08); }
            100% { box-shadow: 0 0 0px rgba(199,30,112,0.0); }
          }

          /* New: rotating gradient ring keyframes */
          @keyframes spin {
            to { transform: rotate(360deg); }
          }

          /* Teal color variable */
          :root { --teal: #00bfa5; }

          /* Ensure the selected emotion still has the float/glow + rotating border ring */
          .emotion.selected .emotion-circle, .emotion:focus-visible .emotion-circle {
            animation: emotionFloat 3.6s ease-in-out infinite, emotionGlow 3.6s ease-in-out infinite;
            will-change: transform, box-shadow;
          }

          :root {
            --teal: #00bfa5;
            /* default values you can tweak */
            --ring-gap: 5px;        /* distance between the circle and the ring */
            --ring-thickness: -1px;  /* <-- change this to control the ring thickness */
          }

          .emotion .emotion-circle {
            position: relative;
            z-index: 1;
          }
          /* Base circle style */
          .emotion .emotion-circle {
            width: 52px;
            height: 52px;
            border-radius: 999px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(255,255,255,0.85);
            box-shadow: 0 4px 12px rgba(2, 6, 23, 0.08);
            border: 1px solid rgba(0,0,0,0.06);
            transition: transform 200ms ease, border-color 200ms ease, background 200ms ease, box-shadow 200ms ease;
            font-size: 22px;
            user-select: none;
            position: relative; /* for pseudo-element ring */
            z-index: 0;
          }

          /* Pseudo-element to create the rotating gradient ring around the circle.
             This uses a conic-gradient background and a radial mask to make a donut (ring).
             The pseudo-element sits behind the main circle (z-index:0) while the circle content stays above it.
          */
          .emotion.selected .emotion-circle::before {
            content: "";
            position: absolute;
            inset: calc(-1 * (var(--ring-gap) + var(--ring-thickness)));
            border-radius: 999px;
            background: conic-gradient(from 0deg, var(--teal), #41c6b7, #1e91c7ff, var(--teal));
            -webkit-mask: radial-gradient(farthest-side, transparent calc(100% - 10px), black calc(100% - 8px));
            mask: radial-gradient(farthest-side, transparent calc(100% - 3px), black calc(100% - 1px));
            pointer-events: none;
            z-index: 0;
            animation: spin 2.6s linear infinite;
            will-change: transform;
            box-shadow: 0 4px 12px rgba(2, 6, 23, 0.08);
            filter: drop-shadow(0 6px 16px rgba(0, 191, 166, 0.69));
          }

          
          /* subtle teal glow on selected circle */
          .emotion.selected .emotion-circle {
            box-shadow: 0 8px 28px rgba(0,191,165,0.12);
          }

          /* Make sure the pseudo-element ring doesn't show on non-selected states */
          .emotion .emotion-circle::before { display: none; }

          /* Show ring only for selected (so the display rule above is safe) */
          .emotion.selected .emotion-circle::before { display: block; }

          @media (prefers-reduced-motion: reduce) {
            .emotion.selected .emotion-circle, .emotion:focus-visible .emotion-circle { animation: none; transform: none !important; box-shadow: 0 8px 20px rgba(0,0,0,0.08) !important; }
            .animated-welcome { animation: none; transform: none; opacity: 1; }
            .emotion.selected .emotion-circle::before { animation: none; }
          }

          /* small adjustments for modal and buttons readability on top of video */
          .modal-container, .modal-content, .consultation-card {
            background: rgba(255,255,255,0.98);
          }
          .modal-overlay {
            backdrop-filter: blur(4px);
          }

          /* ongoing indicator */
          .ongoing-indicator {
            display: inline-flex;
            gap: 8px;
            align-items: center;
            margin-left: 8px;
            font-size:8px;
            background: rgba(255, 255, 255, 1);
            padding: 1.5px 8px;
            border-radius: 999px;
            color: #ff5a5f;
            border: 1px solid rgba(255,255,255,0.12);
            box-shadow: 0 4px 12px rgba(0,0,0,0.25);
          }
          .pulse-dot {
            width: 8px;
            height: 8px;
            border-radius: 999px;
            background: #ff5a5f;
            box-shadow: 0 0 8px rgba(255,90,95,0.6);
            animation: pulse 1.6s infinite;
          }
          @keyframes pulse {
            0% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.4); opacity: 0.6; }
            100% { transform: scale(1); opacity: 1; }
          }

          /* ensure hero content remains readable on small screens */
          @media (max-width: 768px) {
            .hero-note { margin-left: 16px !important; font-size: 14px; }
            .brand-display { font-size: 28px; margin-left: 16px !important; }
            .greet-small { margin-left: 16px; font-size: 14px; }
            .emotions-grid { gap: 8px; }
            .emotion-circle { width: 48px; height: 48px; font-size: 20px; }
            .post-actions { padding: 12px 16px; }
            .action-buttons { display: flex; flex-direction: column; gap: 8px; }
            .btn-action { width: 100%; }
          }

          /* NEW: ensure the landing hero block stays centered in the viewport (even on zoom-out)
             - center the main (landing-hero) area with flexbox
             - constrain the inner block to a reasonable max width so it doesn't stretch too wide when zooming out
             - keep mobile behavior unchanged
          */
          .landing-hero {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 50px 0;
            box-sizing: border-box;
            min-height: 0; /* allow flex parent to control height */
          }

          .hero-inner {
            width: min(1100px, 96%);
            max-width: 1100px;
            box-sizing: border-box;
          }

          @media (max-width: 480px) {
            .hero-inner { width: 100%; padding: 0 12px; }
          }
        `}</style>

        <ResponsiveHeader 
          session={session} 
          title="A Mental Health Booking Solution" 
          showNavigation={true} 
          showBackButton={false}
          onFeedbackClick={() => setIsFeedbackOpen(true)}
        />

        <FeedbackModal 
          isOpen={isFeedbackOpen}
          onClose={() => setIsFeedbackOpen(false)}
        />

        {/* make main flexible so it grows and pushes footer down */}
        <main className="landing-hero" style={{ flex: 1 }}>
          <div className="hero-inner">
            <div className="greeting">
              <div className="greet-small">
                Hello, <span style={{ color: "#c71e70ff" }}>{userName}</span> !
              </div>

              <h2 className="brand-display" style={{ marginTop: 10, marginLeft: 15 }}>
                <span className="animated-welcome">Welcome Back!</span>
              </h2>

              <p className="hero-note" style={{ marginLeft: 30 }}>
                We're glad you're here! This is your safe space to reflect and feel supported.
              </p>

              <div className="emotion-section">
                <div className="feeling-ask" style={{ marginRight: 25 }}>
                  How are you feeling today?
                </div>

                <div className="emotions-grid" role="list" aria-label="Emotions" ref={emotionsGridRef}>
                  {emotions.map((e) => (
                    <button
                      key={e.label}
                      className={`emotion ${selectedEmotion === e.label ? "selected" : ""}`}
                      type="button"
                      onClick={() => handleEmotionClick(e.label)}
                      onKeyDown={(ev) => handleEmotionKeyDown(ev, e.label)}
                      aria-pressed={selectedEmotion === e.label}
                      aria-label={`Select ${e.label} emotion`}
                    >
                      <div className="emotion-circle" style={{ fontSize: "23px" }}>{e.icon}</div>
                      <div className="emotion-label">{e.label}</div>
                    </button>
                  ))}
                </div>

                <div className="post-actions">
                  {selectedEmotion && (
                    <p className="selected-note" style={{ marginRight: 35 }}>
                      You're feeling{""}
                      <strong
                        className="selected-emotion-inline"
                        style={{
                          background: "linear-gradient(90deg, #c71e70, #41c6b7)",
                          WebkitBackgroundClip: "text",
                          backgroundClip: "text",
                          color: "transparent",
                          fontWeight: 700,
                          marginLeft: 6,
                          marginRight: 6,
                        }}
                      >
                        {selectedEmotion}
                      </strong>
                      . Take a breath — what feels right for you next?
                    </p>
                  )}
                  <div className="action-buttons" style={{ marginRight: 35 }}>
                      <button className="btn-action view-bookings" onClick={() => setShowBookingsModal(true)}>
                        <svg
                          viewBox="0 0 1000 1000"
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          style={{
                            marginRight: 6,
                            verticalAlign: "middle",
                            transform: "translateY(-1px)",
                            fill: "white",
                          }}
                        >
                          <path d="M790 166h-41V83h-84v83H333V83h-83v83h-42q-34 0-58.5 24.5T125 250v582q0 34 24 58.5t59 24.5h582q35 0 59-24.5t24-58.5V250q0-35-24.5-59.5T790 166zm0 666H208V374h582v458zM291 457h208v208H291V457z" />
                        </svg>
                        My Bookings
                        {hasOngoingConsultation && (
                          <span className="ongoing-indicator">
                            <span className="pulse-dot" />
                            AVAILABLE
                          </span>
                        )}
                      </button>

                      {selectedEmotion && (
                        <>
                          <button className="btn-action primary" onClick={handleBookAppointment}>
                            <svg
                              viewBox="0 0 1000 1000"
                              xmlns="http://www.w3.org/2000/svg"
                              width="20"
                              height="20"
                              style={{
                                marginRight: 6,
                                verticalAlign: "middle",
                                transform: "translateY(-1px)",
                                fill: "white",
                              }}
                            >
                              <path d="M860 265h-61q-8 0-13.5 5.5T780 284v246q0 39-28 67t-68 28H279q-8 0-13.5 5.5T260 644v61q0 17 11.5 28.5T300 745h415q25 0 43 18l110 110q4 4 9.5 5t11-1 8.5-7 3-11V305q0-17-11.5-28.5T860 265zM700 505V145q0-17-11.5-28.5T660 105H140q-17 0-28.5 11.5T100 145v514q0 6 3 11t8.5 7 11 1 9.5-5l110-110q18-18 43-18h375q17 0 28.5-12t11.5-28z" />
                            </svg>
                            Talk to Someone
                          </button>

                      <button className="btn-action secondary" onClick={handleReadArticles}>
                        <svg
                          viewBox="0 0 512 512"
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          style={{
                            marginRight: 6,
                            verticalAlign: "middle",
                            transform: "translateY(-1px)",
                            fill: "#555",
                          }}
                        >
                          <path d="M164.128,155.406c-0.017-11.098-0.017-20.759,1.346-29.9l-7.987,9.166c-14.001,16.134-49.379,26.563-79.029,23.301c-29.666-3.262-42.346-18.986-28.345-35.128l105.4-110.292c2.049-2.15,2.626-5.311,1.456-8.054c-1.163-2.727-3.856-4.5-6.825-4.5h-16.978c-4.968,0-9.719,1.982-13.206,5.52L28.527,98.174c-18.76,19.638-17.89,30.544-17.89,61.089c0,21.812,0,301.06,0,301.06c0,26.196,32.92,47.824,62.578,51.078c29.65,3.27,70.272-7.168,84.273-23.302l9.317-10.832c-1.673-5.402-2.676-11.04-2.676-16.945V155.406z" />
                          <path d="M493.952,0h-18.375c-5.36,0-10.454,2.324-13.984,6.356l-111.84,128.316c-14,16.134-49.379,26.563-79.02,23.301c-29.667-3.262-42.346-18.986-28.345-35.128l105.4-110.292c2.041-2.15,2.626-5.311,1.456-8.054c-1.172-2.727-3.856-4.5-6.825-4.5H325.44c-4.968,0-9.727,1.982-13.206,5.52l-91.432,92.654c-18.76,19.638-17.89,30.544-17.89,61.089c0,21.812,0,301.06,0,301.06c0,26.196,32.92,47.824,62.569,51.078c29.658,3.27,70.272-7.168,84.272-23.302L487.896,327.64c8.69-10.103,13.474-22.984,13.474-36.315V7.418C501.37,3.328,498.051,0,493.952,0z" />
                        </svg>
                        Find Helpful Reads
                      </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>

        {/*
          Important: wrap Footer in a container that uses margin-top: auto so the footer
          is pushed to the bottom of the page on larger viewports. This does not alter
          Footer's internal implementation.
        */}
        <div style={{ marginTop: "auto" }}>
          <Footer />
        </div>

        {/* Bookings Modal */}
        {showBookingsModal && (
          <div className="modal-overlay" onClick={() => setShowBookingsModal(false)}>
            <div className="modal-container" onClick={(e) => e.stopPropagation()}>
              <div className="modal-header">
                <h3>Your Consultations</h3>
                <button className="modal-close" onClick={() => setShowBookingsModal(false)} aria-label="Close modal">
                  ✕
                </button>
              </div>

              <div className="modal-content">
                {loadingConsultations ? (
                  <p style={{ color: "#666", fontSize: "14px", textAlign: "center", padding: "20px" }}>Loading...</p>
                ) : allConsultations.length === 0 ? (
                  <div style={{ textAlign: "center", padding: "40px 20px", color: "#666" }}>
                    <div style={{ fontSize: "48px", marginBottom: "16px" }}>📅</div>
                    <p style={{ fontSize: "16px", marginBottom: "8px", fontWeight: "500" }}>No consultations yet</p>
                    <p style={{ fontSize: "14px", color: "#999" }}>Book your first appointment to get started!</p>
                  </div>
                ) : (
                  <>
                    <div className="consultations-list">
                      {displayedConsultations.map((consultation) => {
                        const statusInfo = getStatusColor(consultation.status, consultation.date, consultation.time);
                        const accessInfo = consultation.accessInfo || checkVideoLinkAccess(consultation.date, consultation.time);

                        return (
                          <div key={consultation.id} className="consultation-card">
                            <div className="consultation-header">
                              <div>
                                <div className="counselor-name">{consultation.counselor?.name || consultation.counselor?.email || "Counselor"}</div>
                                <div className="consultation-datetime">
                                  📅 {formatDate(consultation.date)} • 🕐 {formatTime(consultation.time)}
                                </div>
                              </div>
                              <span className="status-badge" style={{ backgroundColor: statusInfo.bg, color: statusInfo.color }}>
                                {statusInfo.text}
                              </span>
                            </div>

                            {consultation.reason && (
                              <div className="consultation-reason">
                                <p className="reason-label">Reason:</p>
                                <p className="reason-text">{consultation.reason || "Follow up"}</p>
                              </div>
                            )}

                            {/* ONLY apply the new "Occupied" status rendering here in the modal */}
                            {consultation.status === "occupied" && (
                              <p className="access-message error">⚠️ This time slot is already booked by another student.</p>
                            )}

                            {consultation.status === "unavailable" && consultation.rejection_reason && (
                              <div className="rejection-reason">
                                <p className="reason-label">Invalid:</p>
                                <p className="reason-text">{consultation.rejection_reason}</p>
                              </div>
                            )}

                            {consultation.status === "accepted" && consultation.video_link && !consultation.meeting_ended && accessInfo.reason !== "completed" && (
                              <>
                                {accessInfo.canAccess ? (
                                  <div>
                                    <a href={consultation.video_link} target="_blank" rel="noopener noreferrer" className="video-link-button">
                                      🎥 Join Video Session
                                    </a>
                                    <p className="access-message success">{accessInfo.message}</p>
                                  </div>
                                ) : (
                                  <div>
                                    <button disabled className="video-link-button disabled">
                                      🎥 Join Video Session
                                    </button>
                                    <p className="access-message warning">{accessInfo.message}</p>
                                  </div>
                                )}
                              </>
                            )}

                            {consultation.status === "pending" && (
                              <>
                                <p className="access-message warning">Waiting for counselor to accept...</p>
                                <button onClick={() => handleCancelConsultation(consultation.id, consultation.availability_id)} className="cancel-consultation-button">
                                  ❌ Cancel Request
                                </button>
                              </>
                            )}

                            {consultation.status === "cancelled" && <p className="access-message error">❌ You cancelled this consultation</p>}

                            {/*{(consultation.meeting_ended) && <p className="access-message completed">✅ Meeting completed</p>}*/}
                          </div>
                        );
                      })}
                    </div>

                    {hasMore && (
                      <div ref={observerTarget} className="load-more-trigger">
                        {isLoadingMore ? (
                          <div className="loading-spinner">
                            <div className="spinner" />
                            Loading more...
                          </div>
                        ) : (
                          "Scroll for more"
                        )}
                      </div>
                    )}

                    {!hasMore && displayedConsultations.length > ITEMS_PER_PAGE && <div className="no-more-items">No more consultations</div>}
                  </>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Informed Consent Modal */}
        {showConsentModal && (
          <div className="modal-overlay" onClick={handleConsentReject}>
            <div className="modal-container consent-modal" onClick={(e) => e.stopPropagation()}>
              <div className="modal-header">
                <h3>Informed Consent for Tele-Counseling</h3>
                <button className="modal-close" onClick={handleConsentReject} aria-label="Close modal">
                  ✕
                </button>
              </div>

              <div className="modal-content">
                <div className="consent-content">
                  <div className="consent-icon">📋</div>

                  <div className="consent-text">
                    <p>By proceeding with this booking, I acknowledge and agree to the following:</p>

                    <ul className="consent-list">
                      <li>I am <strong>willing to undergo tele-counseling</strong> services through this platform.</li>
                      <li>I understand that I will be <strong>disclosing my concerns or problems</strong> with my guidance counselor.</li>
                      <li>I consent to participate in online counseling sessions and understand the nature of virtual mental health services.</li>
                      <li>I understand that all information shared will be kept confidential in accordance with professional guidelines.</li>
                    </ul>

                    <p className="consent-note">Please click "I Accept" if you agree to proceed with booking your counseling session.</p>
                  </div>
                </div>

                <div className="consent-actions">
                  <button className="btn-consent reject" onClick={handleConsentReject}>
                    I Decline
                  </button>
                  <button className="btn-consent accept" onClick={handleConsentAccept}>
                    I Accept
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        <AIAssistantFloating />
      </div>
    </div>
  );
}
