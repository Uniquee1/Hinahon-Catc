import React, { useEffect, useState, useRef } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import LoginPage from "./pages/LoginPage";
import AuthCallback from "./pages/AuthCallback";
import ProfileCompletionPage from "./pages/ProfileCompletionPage";
import ResetPasswordPage from "./pages/ResetPasswordPage";
import LandingPage from "./pages/LandingPage";
import AdminPage from "./pages/AdminPage";
import CounselorPage from "./pages/CounselorPage";
import ArticlesPage from "./pages/ArticlesPage";
import BookingPage from "./pages/BookingPage";
import AboutPage from "./pages/AboutPage";
import ProfilePage from "./pages/ProfilePage";
import { supabase } from "./supabaseClient";

export default function App() {
  const [session, setSession] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const initialized = useRef(false);
  const authListenerReady = useRef(false);

  // Fetch user profile
  const fetchUserProfile = async (userId) => {
    try {
      const { data, error } = await supabase
        .from("users")
        .select("*")
        .eq("id", userId)
        .single();

      if (error) {
        console.error("Profile fetch error:", error);
        return { id: userId, profile_completed: false, role: 'student' };
      }

      // Auto-complete for counselors/admins
      if ((data.role === 'counselor' || data.role === 'admin') && !data.profile_completed) {
        await supabase
          .from('users')
          .update({ profile_completed: true })
          .eq('id', userId);
        
        return { ...data, profile_completed: true };
      }

      return data;
    } catch (err) {
      console.error("Profile fetch exception:", err);
      return { id: userId, profile_completed: false, role: 'student' };
    }
  };

  // Refresh profile
  const refreshUserProfile = async () => {
    if (session?.user) {
      const profile = await fetchUserProfile(session.user.id);
      setUserProfile(profile);
    }
  };

  // Initialize auth - runs once
  useEffect(() => {
    let mounted = true;
    let timeoutId = null;

    const initAuth = async () => {
      try {
        console.log("🔄 Initializing auth...");

        // Safety timeout
        timeoutId = setTimeout(() => {
          if (mounted) {
            console.warn("⏰ Timeout - forcing loading stop");
            setLoading(false);
            authListenerReady.current = true;
          }
        }, 5000);

        const { data: { session: currentSession }, error } = await supabase.auth.getSession();

        if (!mounted) return;

        if (error) {
          console.error("Session error:", error);
          setLoading(false);
          authListenerReady.current = true;
          if (timeoutId) clearTimeout(timeoutId);
          return;
        }

        if (currentSession?.user) {
          console.log("✅ Session found:", currentSession.user.email);
          setSession(currentSession);
          
          const profile = await fetchUserProfile(currentSession.user.id);
          if (mounted) {
            setUserProfile(profile);
            // Only stop loading after BOTH session and profile are set
            setLoading(false);
            authListenerReady.current = true;
          }
        } else {
          console.log("ℹ️ No session");
          setLoading(false);
          authListenerReady.current = true;
        }

        if (timeoutId) clearTimeout(timeoutId);
      } catch (err) {
        console.error("Init error:", err);
        if (mounted) {
          setLoading(false);
          authListenerReady.current = true;
          if (timeoutId) clearTimeout(timeoutId);
        }
      }
    };

    // Always run initialization, StrictMode will handle double mounting correctly
    initAuth();

    return () => {
      mounted = false;
      if (timeoutId) clearTimeout(timeoutId);
      // Reset the ready flag on cleanup
      authListenerReady.current = false;
    };
  }, []);

  // Auth state listener
  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, newSession) => {
        console.log("🔔 Auth event:", event);

        // Skip events until initialization is complete
        if (!authListenerReady.current) {
          console.log("⏭️ Skipping event - not ready yet");
          return;
        }

        // Skip INITIAL_SESSION
        if (event === 'INITIAL_SESSION') {
          console.log("⏭️ Skipping INITIAL_SESSION");
          return;
        }

        if (event === 'SIGNED_IN' && newSession?.user) {
          console.log("✅ Signed in via auth change:", newSession.user.email);
          setSession(newSession);
          const profile = await fetchUserProfile(newSession.user.id);
          setUserProfile(profile);
        } 
        else if (event === 'SIGNED_OUT') {
          console.log("👋 Signed out");
          setSession(null);
          setUserProfile(null);
        }
        else if (event === 'TOKEN_REFRESHED') {
          console.log("🔄 Token refreshed");
          if (newSession) setSession(newSession);
        }
        else if (event === 'USER_UPDATED' && newSession?.user) {
          console.log("📝 User updated");
          setSession(newSession);
          const profile = await fetchUserProfile(newSession.user.id);
          setUserProfile(profile);
        }
      }
    );

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  // Loading screen
  if (loading) {
    return (
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh',
        flexDirection: 'column',
        gap: '16px',
        backgroundColor: '#fafafa'
      }}>
        <div style={{
          width: '50px',
          height: '50px',
          border: '5px solid #f3f3f3',
          borderTop: '5px solid #e91e63',
          borderRadius: '50%',
          animation: 'spin 1s linear infinite'
        }}></div>
        <p style={{ color: '#666', fontSize: '15px', fontWeight: '500' }}>
          Loading...
        </p>
        <style>{`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    );
  }

  // Helper
  const needsProfileCompletion = (profile) => {
    if (!profile) return false;
    if (profile.role !== 'student') return false;
    return !profile.profile_completed;
  };

  return (
    <Router>
      <Routes>
        {/* Login */}
        <Route
          path="/"
          element={
            !session ? (
              <LoginPage setSession={setSession} />
            ) : needsProfileCompletion(userProfile) ? (
              <Navigate to="/profile-completion" replace />
            ) : userProfile?.role === "admin" ? (
              <Navigate to="/admin" replace />
            ) : userProfile?.role === "counselor" ? (
              <Navigate to="/counselor" replace />
            ) : (
              <Navigate to="/landing" replace />
            )
          }
        />

        {/* Reset Password */}
        <Route path="/reset-password" element={<ResetPasswordPage />} />

        {/* Auth Callback */}
        <Route path="/auth/callback" element={<AuthCallback />} />

        {/* Profile Completion */}
        <Route
          path="/profile-completion"
          element={
            session && userProfile && needsProfileCompletion(userProfile) ? (
              <ProfileCompletionPage 
                user={session.user} 
                onComplete={refreshUserProfile}
              />
            ) : !session ? (
              <Navigate to="/" replace />
            ) : userProfile?.role === "admin" ? (
              <Navigate to="/admin" replace />
            ) : userProfile?.role === "counselor" ? (
              <Navigate to="/counselor" replace />
            ) : (
              <Navigate to="/landing" replace />
            )
          }
        />

        {/* Landing Page */}
        <Route
          path="/landing"
          element={
            session && userProfile?.profile_completed && userProfile.role === "student" ? (
              <LandingPage session={session} setSession={setSession} />
            ) : !session ? (
              <Navigate to="/" replace />
            ) : needsProfileCompletion(userProfile) ? (
              <Navigate to="/profile-completion" replace />
            ) : (
              <Navigate to="/" replace />
            )
          }
        />

        {/* Articles */}
        <Route
          path="/articles"
          element={
            session && userProfile ? (
              <ArticlesPage session={session} />
            ) : (
              <Navigate to="/" replace />
            )
          }
        />

        <Route
          path="/articles/:emotion"
          element={
            session && userProfile ? (
              <ArticlesPage session={session} />
            ) : (
              <Navigate to="/" replace />
            )
          }
        />

        {/* Booking */}
        <Route
          path="/booking"
          element={
            session && userProfile?.profile_completed && userProfile.role === "student" ? (
              <BookingPage session={session} />
            ) : (
              <Navigate to="/" replace />
            )
          }
        />

        {/* Counselor */}
        <Route
          path="/counselor"
          element={
            session && userProfile?.role === "counselor" ? (
              <CounselorPage />
            ) : (
              <Navigate to="/" replace />
            )
          }
        />

        {/* Admin */}
        <Route
          path="/admin"
          element={
            session && userProfile?.role === "admin" ? (
              <AdminPage />
            ) : (
              <Navigate to="/" replace />
            )
          }
        />

        {/* About */}
        <Route
          path="/about"
          element={
            session && userProfile ? (
              <AboutPage session={session} />
            ) : (
              <Navigate to="/" replace />
            )
          }
        />

        {/* Profile */}
        <Route
          path="/profile"
          element={
            session && userProfile ? (
              <ProfilePage session={session} />
            ) : (
              <Navigate to="/" replace />
            )
          }
        />

        {/* Catch all */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}