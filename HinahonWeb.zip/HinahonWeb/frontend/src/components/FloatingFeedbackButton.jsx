import React from 'react';
import './FloatingFeedbackButton.css';

export default function FloatingFeedbackButton({ onClick }) {
  return (
    <button
      onClick={onClick}
      className="floating-feedback-btn"
      aria-label="Give Feedback"
    >
      
      <span>Feedback</span>
    </button>
  );
}