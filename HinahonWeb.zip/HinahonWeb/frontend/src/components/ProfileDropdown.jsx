// FILE: src/components/ProfileDropdown.jsx
import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "../supabaseClient";

export default function ProfileDropdown({ session }) {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const [profileImage, setProfileImage] = useState(null);
  const dropdownRef = useRef(null);

  // Get user's profile image from Google OAuth or use default
  useEffect(() => {
    if (session?.user?.user_metadata?.avatar_url) {
      setProfileImage(session.user.user_metadata.avatar_url);
    }
  }, [session]);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isOpen]);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate("/");
  };

  return (
    <div ref={dropdownRef} style={{ position: "relative" }}>
      {/* Profile Image Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        style={{
          width: "40px",
          height: "40px",
          borderRadius: "50%",
          border: "2px solid var(--teal)",
          background: profileImage 
            ? `url(${profileImage})` 
            : "linear-gradient(135deg, var(--pink), var(--teal))",
          backgroundSize: "cover",
          backgroundPosition: "center",
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "white",
          fontSize: "16px",
          fontWeight: "600",
          transition: "all 0.2s",
          overflow: "hidden",
          padding: 0
        }}
        aria-label="Profile menu"
        onMouseEnter={(e) => {
          e.target.style.transform = "scale(1.05)";
          e.target.style.boxShadow = "0 4px 12px rgba(0,191,165,0.3)";
        }}
        onMouseLeave={(e) => {
          e.target.style.transform = "scale(1)";
          e.target.style.boxShadow = "none";
        }}
      >
        {!profileImage && (
          <svg 
            width="20" 
            height="20" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2"
          >
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
            <circle cx="12" cy="7" r="4" />
          </svg>
        )}
      </button>

      {/* Dropdown Menu */}
      {isOpen && (
        <div
          style={{
            position: "absolute",
            top: "calc(100% + 8px)",
            right: 0,
            backgroundColor: "white",
            borderRadius: "12px",
            boxShadow: "0 4px 20px rgba(0,0,0,0.15)",
            border: "1px solid #e0e0e0",
            minWidth: "200px",
            zIndex: 1000,
            overflow: "hidden",
            animation: "dropdownFade 0.2s ease-out"
          }}
        >
          {/* User Info Section */}
          <div
            style={{
              padding: "16px",
              borderBottom: "1px solid #f0f0f0",
              backgroundColor: "#f8f9fa"
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
              <div
                style={{
                  width: "32px",
                  height: "32px",
                  borderRadius: "50%",
                  background: profileImage 
                    ? `url(${profileImage})` 
                    : "linear-gradient(135deg, var(--pink), var(--teal))",
                  backgroundSize: "cover",
                  backgroundPosition: "center",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: "white",
                  fontSize: "14px",
                  fontWeight: "600"
                }}
              >
                {!profileImage && (
                  <svg 
                    width="16" 
                    height="16" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    stroke="currentColor" 
                    strokeWidth="2"
                  >
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                    <circle cx="12" cy="7" r="4" />
                  </svg>
                )}
              </div>
              <div style={{ flex: 1, overflow: "hidden" }}>
                <div
                  style={{
                    fontSize: "14px",
                    fontWeight: "600",
                    color: "var(--text)",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap"
                  }}
                >
                  {session?.user?.user_metadata?.name || session?.user?.email?.split('@')[0] || "User"}
                </div>
                <div
                  style={{
                    fontSize: "12px",
                    color: "#999",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap"
                  }}
                >
                  {session?.user?.email}
                </div>
              </div>
            </div>
          </div>

          {/* Menu Items */}
          <div style={{ padding: "8px 0" }}>
            <button
              onClick={() => {
                setIsOpen(false);
                navigate("/profile");
              }}
              style={{
                width: "100%",
                padding: "12px 16px",
                border: "none",
                background: "white",
                textAlign: "left",
                cursor: "pointer",
                fontSize: "14px",
                color: "var(--text)",
                fontWeight: "500",
                display: "flex",
                alignItems: "center",
                gap: "12px",
                transition: "background 0.2s"
              }}
              onMouseEnter={(e) => {
                e.target.style.backgroundColor = "#f8f9fa";
              }}
              onMouseLeave={(e) => {
                e.target.style.backgroundColor = "white";
              }}
            >
              <svg 
                width="18" 
                height="18" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2"
              >
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                <circle cx="12" cy="7" r="4" />
              </svg>
              Account Profile
            </button>

            <div
              style={{
                height: "1px",
                backgroundColor: "#f0f0f0",
                margin: "4px 0"
              }}
            />

            <button
              onClick={() => {
                setIsOpen(false);
                handleSignOut();
              }}
              style={{
                width: "100%",
                padding: "12px 16px",
                border: "none",
                background: "white",
                textAlign: "left",
                cursor: "pointer",
                fontSize: "14px",
                color: "var(--pink)",
                fontWeight: "500",
                display: "flex",
                alignItems: "center",
                gap: "12px",
                transition: "background 0.2s"
              }}
              onMouseEnter={(e) => {
                e.target.style.backgroundColor = "#fff5f8";
              }}
              onMouseLeave={(e) => {
                e.target.style.backgroundColor = "white";
              }}
            >
              <svg 
                width="18" 
                height="18" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2"
              >
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                <polyline points="16 17 21 12 16 7" />
                <line x1="21" y1="12" x2="9" y2="12" />
              </svg>
              Sign Out
            </button>
          </div>
        </div>
      )}

      {/* Add animation keyframes */}
      <style>{`
        @keyframes dropdownFade {
          from {
            opacity: 0;
            transform: translateY(-8px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}