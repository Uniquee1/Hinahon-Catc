import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "../supabaseClient";
import "../styles.css";

export default function LoginPage({ setSession }) {
  const navigate = useNavigate();
  const [isSignUp, setIsSignUp] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: ""
  });

  useEffect(() => {
    let mounted = true;

    (async () => {
      const { data } = await supabase.auth.getSession();
      if (!mounted) return;

      if (data?.session) {
        setSession(data.session);
        await handleRedirect(data.session);
      }
    })();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (_event, session) => {
        if (mounted && session?.user) {
          setSession(session);
          await handleRedirect(session);
        }
      }
    );

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [navigate, setSession]);

  async function handleRedirect(session) {
    if (!session?.user) return;

    try {
      console.log("Login redirect - fetching profile for:", session.user.email);
      
      const { data: profile, error } = await supabase
        .from("users")
        .select("role, profile_completed")
        .eq("id", session.user.id)
        .single();

      if (error) {
        console.error("Error fetching profile:", error);
        navigate("/profile-completion");
        return;
      }

      console.log("Login redirect - profile:", profile);

      // Auto-complete profile for counselors and admins
      if ((profile?.role === 'counselor' || profile?.role === 'admin') && !profile.profile_completed) {
        console.log("Auto-completing profile for counselor/admin");
        
        await supabase
          .from('users')
          .update({ profile_completed: true })
          .eq('id', session.user.id);
      }

      // Redirect based on role
      if (profile?.role === "admin") {
        console.log("Redirecting admin to /admin");
        navigate("/admin");
      } else if (profile?.role === "counselor") {
        console.log("Redirecting counselor to /counselor");
        navigate("/counselor");
      } else if (!profile?.profile_completed) {
        console.log("Redirecting student to profile completion");
        navigate("/profile-completion");
      } else {
        console.log("Redirecting to landing");
        navigate("/landing");
      }
    } catch (err) {
      console.error("Error in redirect:", err);
      navigate("/profile-completion");
    }
  }

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    setError("");
  };

  async function signInWithGoogle() {
    try {
      setLoading(true);
      setError("");
      
      const { error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: { 
          redirectTo: window.location.origin,
          // ✅ NO PROMPT: Only shows on first login, completely silent for returning users
          // Google will automatically detect if user is already authenticated
          queryParams: {
            access_type: 'offline'
            // Removed 'prompt' parameter entirely for silent auth
          }
        }
      });

      if (error) throw error;
    } catch (err) {
      console.error("Google sign in error:", err);
      setError(err.message || "Failed to sign in with Google");
      setLoading(false);
    }
  }

  async function handleEmailAuth(e) {
    e.preventDefault();
    setError("");
    
    // Validation
    if (!formData.email || !formData.password) {
      setError("Please fill in all fields");
      return;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      setError("Please enter a valid email address");
      return;
    }

    // Password validation
    if (formData.password.length < 6) {
      setError("Password must be at least 6 characters");
      return;
    }

    if (isSignUp && formData.password !== formData.confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    setLoading(true);

    try {
      if (isSignUp) {
        // Sign up
        const { data, error } = await supabase.auth.signUp({
          email: formData.email,
          password: formData.password,
          options: {
            emailRedirectTo: window.location.origin,
            data: {
              email: formData.email
            }
          }
        });

        if (error) throw error;

        if (data?.user) {
          // Check if email confirmation is required
          if (data.user.identities && data.user.identities.length === 0) {
            setError("This email is already registered. Please sign in instead.");
            setIsSignUp(false);
            setLoading(false);
            return;
          }

          // For email signup, Supabase may require email confirmation
          if (data.user.confirmed_at) {
            // Email is auto-confirmed (development mode)
            alert("Account created successfully! Please complete your profile.");
            setSession(data.session);
            navigate("/profile-completion");
          } else {
            // Email confirmation required
            alert("Please check your email to confirm your account before signing in.");
            setIsSignUp(false);
            setFormData({ email: "", password: "", confirmPassword: "" });
          }
        }
      } else {
        // Sign in
        const { data, error } = await supabase.auth.signInWithPassword({
          email: formData.email,
          password: formData.password
        });

        if (error) throw error;

        if (data?.session) {
          setSession(data.session);
          await handleRedirect(data.session);
        }
      }
    } catch (err) {
      console.error("Auth error:", err);
      
      // Handle specific error messages
      if (err.message.includes("Invalid login credentials")) {
        setError("Invalid email or password");
      } else if (err.message.includes("Email not confirmed")) {
        setError("Please confirm your email before signing in");
      } else {
        setError(err.message || "Authentication failed");
      }
    } finally {
      setLoading(false);
    }
  }

  const toggleAuthMode = () => {
    setIsSignUp(!isSignUp);
    setError("");
    setFormData({ email: "", password: "", confirmPassword: "" });
  };

  return (
    <div className="auth-page">
      <div className="auth-hero">
        <div className="nav-slim">
          <span>Mental Health Support</span>
        </div>
        
        <div className="hero-content">
          <h1 className="brand-big">Hinahon</h1>
          <p className="hero-sub">
            The Digital Solution to Accessible Mental Health Services in the Philippines.
          </p>
          <p className="hero-sub" style={{ marginTop: "16px", fontSize: "14px" }}>
            {isSignUp 
              ? "Join our community and start your journey to better mental health."
              : "Welcome back! Sign in to continue your mental health journey."
            }
          </p>
        </div>
      </div>

      <div className="auth-card">
        <div className="card-header">
          <div className="logo-small">Hinahon</div>
          <div className="small-tag">
            {isSignUp ? "Create your account" : "Sign in to your account"}
          </div>
        </div>

        {error && (
          <div style={{
            backgroundColor: "#ffebee",
            color: "#c62828",
            padding: "12px",
            borderRadius: "8px",
            fontSize: "13px",
            marginBottom: "12px"
          }}>
            {error}
          </div>
        )}

        <form onSubmit={handleEmailAuth} className="login-form">
          <div className="field">
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Email address"
              disabled={loading}
              required
            />
          </div>

          <div className="field">
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="Password"
              disabled={loading}
              required
            />
          </div>

          {isSignUp && (
            <div className="field">
              <input
                type="password"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
                placeholder="Confirm password"
                disabled={loading}
                required
              />
            </div>
          )}

          <button
            type="submit"
            className="btn-primary"
            disabled={loading}
            style={{
              opacity: loading ? 0.6 : 1,
              cursor: loading ? "not-allowed" : "pointer"
            }}
          >
            {loading ? "Please wait..." : (isSignUp ? "Sign Up" : "Sign In")}
          </button>
        </form>

        <div className="divider">or</div>

        <button
          className="btn-google"
          onClick={signInWithGoogle}
          disabled={loading}
          aria-label="Continue with Google"
        >
          <svg width="18" height="18" viewBox="0 0 18 18">
            <path fill="#4285F4" d="M16.51 8H8.98v3h4.3c-.18 1-.74 1.48-1.6 2.04v2.01h2.6a7.8 7.8 0 0 0 2.38-5.88c0-.57-.05-.66-.15-1.18z"/>
            <path fill="#34A853" d="M8.98 17c2.16 0 3.97-.72 5.3-1.94l-2.6-2a4.8 4.8 0 0 1-7.18-2.54H1.83v2.07A8 8 0 0 0 8.98 17z"/>
            <path fill="#FBBC05" d="M4.5 10.52a4.8 4.8 0 0 1 0-3.04V5.41H1.83a8 8 0 0 0 0 7.18l2.67-2.07z"/>
            <path fill="#EA4335" d="M8.98 4.18c1.17 0 2.23.4 3.06 1.2l2.3-2.3A8 8 0 0 0 1.83 5.4L4.5 7.49a4.77 4.77 0 0 1 4.48-3.3z"/>
          </svg>
          Continue with Google
        </button>

        <div style={{ 
          textAlign: "center", 
          marginTop: "16px",
          fontSize: "14px"
        }}>
          <button
            onClick={toggleAuthMode}
            disabled={loading}
            style={{
              background: "none",
              border: "none",
              color: "var(--pink)",
              cursor: loading ? "not-allowed" : "pointer",
              textDecoration: "underline",
              fontSize: "14px",
              padding: "0",
              opacity: loading ? 0.6 : 1
            }}
          >
            {isSignUp 
              ? "Already have an account? Sign in"
              : "Don't have an account? Sign up"
            }
          </button>
        </div>

        <div className="card-footer" style={{ marginTop: 12 }}>
          {!isSignUp && (
            <a 
              className="link-muted" 
              href="#" 
              onClick={(e) => {
                e.preventDefault();
                alert("Password reset feature coming soon! Please contact support if you need help.");
              }}
            >
              Forgot Password?
            </a>
          )}
          <a 
            className="link-muted" 
            href="#" 
            onClick={(e) => {
              e.preventDefault();
              alert("For help, please contact support@hinahon.ph or visit our help center.");
            }}
          >
            Help
          </a>
        </div>
      </div>
    </div>
  );
}