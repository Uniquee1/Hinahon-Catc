// backend/server.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const dailyRoutes = require('./routes/daily');
const adminRoutes = require('./routes/admin');
const bookingRoutes = require('./routes/bookings');
const chatRoutes = require('./routes/chat'); 
const followupRoutes = require('./routes/followup');
const feedbackRoutes = require('./routes/feedback.js');

const app = express();
const PORT = process.env.PORT || 3001;

// ⚠️ CRITICAL: CORS Configuration for Production
// Add your Vercel frontend URL to allowed origins
const allowedOrigins = [
  'http://localhost:5173',        // Local development (Vite default)
  'http://localhost:3000',        // Local development (alternative)
  'http://localhost:5174',        // Local development (Vite alternative)
  process.env.FRONTEND_URL,       // Production frontend from .env
  'https://hinahon-catc.vercel.app',
  'https://www.hinahon.me',
].filter(Boolean); // Remove undefined values

app.use(cors({
  origin: function (origin, callback) {
    // Allow requests with no origin (mobile apps, Postman, etc.)
    if (!origin) return callback(null, true);
    
    if (allowedOrigins.indexOf(origin) !== -1) {
      callback(null, true);
    } else {
      console.warn(`⚠️ CORS blocked origin: ${origin}`);
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json());

// Request logging middleware (enhanced for production)
app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  const origin = req.headers.origin || 'no-origin';
  console.log(`[${timestamp}] ${req.method} ${req.path} - Origin: ${origin}`);
  next();
});

// Health check endpoint (enhanced)
app.get('/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    message: 'Hinahon Backend API is running',
    environment: process.env.NODE_ENV || 'development',
    timestamp: new Date().toISOString(),
    services: {
      resendEmail: !!process.env.RESEND_API_KEY,
      dailyVideo: !!process.env.DAILY_API_KEY,
      supabase: !!process.env.SUPABASE_URL && !!process.env.SUPABASE_SERVICE_ROLE_KEY,
      openAI: !!process.env.OPENAI_API_KEY
    }
  });
});

// API Routes
app.use('/api/daily', dailyRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/bookings', bookingRoutes);
app.use('/api/followup', followupRoutes);
app.use('/api', chatRoutes);
app.use('/api/feedback', feedbackRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('❌ Error:', err);
  
  // Don't expose internal error details in production
  const isDevelopment = process.env.NODE_ENV === 'development';
  
  res.status(err.status || 500).json({ 
    error: isDevelopment ? err.message : 'Internal server error',
    ...(isDevelopment && { stack: err.stack })
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ 
    error: 'Route not found',
    path: req.path,
    method: req.method,
    availableRoutes: [
      '/health',
      '/api/daily/*',
      '/api/admin/*',
      '/api/bookings/*',
      '/api/followup/*',
      '/api/chat'
    ]
  });
});

// Start server
const server = app.listen(PORT, () => {
  const isDevelopment = process.env.NODE_ENV !== 'production';
  
  console.log('\n' + '='.repeat(60));
  console.log('🚀 HINAHON BACKEND SERVER');
  console.log('='.repeat(60));
  console.log(`📍 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`📍 Server URL: http://localhost:${PORT}`);
  console.log(`🏥 Health check: http://localhost:${PORT}/health`);
  console.log('\n📡 CORS ALLOWED ORIGINS:');
  allowedOrigins.forEach(origin => {
    console.log(`   ✓ ${origin}`);
  });
  
  if (isDevelopment) {
    console.log('\n📋 AVAILABLE ENDPOINTS:');
    console.log('\n   🎥 Daily.co Video:');
    console.log('   - POST   /api/daily/create-room');
    console.log('   - GET    /api/daily/room/:consultationId');
    console.log('   - DELETE /api/daily/room/:consultationId');
    console.log('\n   👥 Admin Management:');
    console.log('   - POST   /api/admin/create-user');
    console.log('   - PUT    /api/admin/update-user/:userId');
    console.log('   - PUT    /api/admin/update-user-role/:userId');
    console.log('   - DELETE /api/admin/delete-user/:userId');
    console.log('\n   📅 Booking & Notifications:');
    console.log('   - POST   /api/bookings/notify');
    console.log('   - POST   /api/bookings/send-acceptance');
    console.log('   - POST   /api/bookings/send-rejection');
    console.log('\n   🤖 AI Assistant:');
    console.log('   - POST   /api/chat');
  }
  
  console.log('\n🔧 SERVICE STATUS:');
  console.log(`   📧 Resend Email:    ${process.env.RESEND_API_KEY ? '✅' : '❌'} ${process.env.RESEND_API_KEY ? '' : '(Set RESEND_API_KEY)'}`);
  console.log(`   🎥 Daily.co Video:  ${process.env.DAILY_API_KEY ? '✅' : '❌'} ${process.env.DAILY_API_KEY ? '' : '(Set DAILY_API_KEY)'}`);
  console.log(`   🗄️  Supabase:        ${process.env.SUPABASE_URL ? '✅' : '❌'} ${process.env.SUPABASE_URL ? '' : '(Set SUPABASE_URL)'}`);
  console.log(`   🤖 OpenAI:          ${process.env.OPENAI_API_KEY ? '✅' : '❌'} ${process.env.OPENAI_API_KEY ? '' : '(Set OPENAI_API_KEY)'}`);
  console.log(`   🌐 Frontend URL:    ${process.env.FRONTEND_URL || '❌ Not Set'}`);
  console.log(`   ✉️  Sender Email:    ${process.env.SENDER_EMAIL || '❌ Not Set'}`);
  
  console.log(`\n⏰ Started at: ${new Date().toLocaleString()}`);
  console.log('='.repeat(60) + '\n');
  
  // Warnings for missing critical env variables
  if (!process.env.RESEND_API_KEY) {
    console.warn('⚠️  WARNING: RESEND_API_KEY not set - Email notifications will fail');
  }
  if (!process.env.SENDER_EMAIL || process.env.SENDER_EMAIL.includes('yourdomain.com')) {
    console.warn('⚠️  WARNING: SENDER_EMAIL not configured - Update to your verified domain');
  }
  if (!process.env.FRONTEND_URL) {
    console.warn('⚠️  WARNING: FRONTEND_URL not set - Email links will be incorrect');
  }
  if (!process.env.DAILY_API_KEY) {
    console.warn('⚠️  WARNING: DAILY_API_KEY not set - Video calls will fail');
  }
});

// Graceful shutdown
const gracefulShutdown = (signal) => {
  console.log(`\n${signal} received. Starting graceful shutdown...`);
  server.close(() => {
    console.log('✅ HTTP server closed');
    console.log('👋 Goodbye!');
    process.exit(0);
  });

  // Force close after 10 seconds
  setTimeout(() => {
    console.error('⚠️  Forced shutdown after timeout');
    process.exit(1);
  }, 10000);
};

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Handle uncaught errors
process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (error) => {
  console.error('❌ Uncaught Exception:', error);
  gracefulShutdown('UNCAUGHT_EXCEPTION');
});