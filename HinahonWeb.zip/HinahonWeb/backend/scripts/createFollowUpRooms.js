// backend/scripts/createFollowUpRooms.js
// This script should be run daily (via cron job) to create rooms for follow-up consultations scheduled for today

require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

const DAILY_API_KEY = process.env.DAILY_API_KEY;

/**
 * Get today's date in YYYY-MM-DD format
 * Uses UTC to match database storage
 */
function getTodayDate() {
  const now = new Date();
  // Convert to Philippine time (UTC+8)
  const philippineTime = new Date(now.toLocaleString('en-US', { timeZone: 'Asia/Manila' }));
  const year = philippineTime.getFullYear();
  const month = String(philippineTime.getMonth() + 1).padStart(2, '0');
  const day = String(philippineTime.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Main function to create rooms for today's follow-up consultations
 */
async function createRoomsForToday() {
  try {
    console.log('🚀 Starting follow-up room creation process...');
    console.log(`📅 Current Date/Time: ${new Date().toISOString()}`);
    console.log(`📅 Philippine Time: ${new Date().toLocaleString('en-US', { timeZone: 'Asia/Manila' })}`);
    
    const today = getTodayDate();
    console.log(`🎯 Looking for consultations on: ${today}`);

    // First, let's check what consultations exist for debugging
    console.log('\n🔍 DEBUG: Checking all follow-up consultations...');
    const { data: allFollowUps, error: debugError } = await supabase
      .from('consultations')
      .select('id, date, is_followup, status, video_link, student_id, counselor_id')
      .eq('is_followup', true)
      .order('date', { ascending: true });

    if (debugError) {
      console.error('❌ Error in debug query:', debugError);
    } else {
      console.log(`📊 Total follow-up consultations in database: ${allFollowUps?.length || 0}`);
      if (allFollowUps && allFollowUps.length > 0) {
        console.log('\n📋 Follow-up consultations breakdown:');
        const grouped = allFollowUps.reduce((acc, c) => {
          const key = `${c.date} (${c.status})`;
          acc[key] = (acc[key] || 0) + 1;
          return acc;
        }, {});
        Object.entries(grouped).forEach(([key, count]) => {
          console.log(`   ${key}: ${count} consultation(s)`);
        });
        
        // Show consultations for today specifically
        const todayConsultations = allFollowUps.filter(c => c.date === today);
        if (todayConsultations.length > 0) {
          console.log(`\n🎯 Follow-ups scheduled for TODAY (${today}):`);
          todayConsultations.forEach(c => {
            console.log(`   • ID: ${c.id.slice(0, 8)}... | Status: ${c.status} | Has video_link: ${c.video_link ? 'Yes' : 'No'}`);
          });
        } else {
          console.log(`\n⚠️  No follow-up consultations found for today (${today})`);
          console.log('   Dates found in database:');
          const uniqueDates = [...new Set(allFollowUps.map(c => c.date))].sort();
          uniqueDates.forEach(date => {
            console.log(`   • ${date}`);
          });
        }
      }
    }

    // Get all follow-up consultations for today that don't have a room yet
    console.log('\n🔍 Querying for follow-ups needing rooms...');
    const { data: consultations, error } = await supabase
      .from('consultations')
      .select(`
        *,
        counselor:counselor_id(name, email),
        student:student_id(name, email)
      `)
      .eq('date', today)
      .eq('is_followup', true)
      .eq('status', 'accepted')
      .is('video_link', null);

    if (error) {
      console.error('❌ Error fetching follow-up consultations:', error);
      throw error;
    }

    if (!consultations || consultations.length === 0) {
      console.log('\n✅ No follow-up consultations need rooms today');
      console.log('   This could mean:');
      console.log('   1. No follow-ups scheduled for today');
      console.log('   2. All follow-ups already have video links');
      console.log('   3. No accepted follow-ups for today');
      console.log('   4. Date format mismatch (check database date format)');
      return { success: true, created: 0, total: 0 };
    }

    console.log(`\n📋 Found ${consultations.length} follow-up consultation(s) needing rooms`);

    const results = [];

    // Import email functions
    const { sendAcceptanceNotification, sendCounselorAcceptanceNotification } = require('../utils/emailService');

    for (const consultation of consultations) {
      try {
        console.log(`\n🔨 Processing consultation ${consultation.id}...`);
        console.log(`   Student: ${consultation.student?.name || consultation.student?.email || 'Unknown'}`);
        console.log(`   Counselor: ${consultation.counselor?.name || consultation.counselor?.email || 'Unknown'}`);
        console.log(`   Time: ${consultation.time}`);
        console.log(`   Date: ${consultation.date}`);

        // Create unique room name
        const roomName = `hinahon-followup-${consultation.id.slice(0, 8)}-${Date.now()}`;

        // Validate we have Daily API key
        if (!DAILY_API_KEY) {
          console.error('   ❌ DAILY_API_KEY not set!');
          results.push({
            consultationId: consultation.id,
            success: false,
            error: 'DAILY_API_KEY not configured'
          });
          continue;
        }

        // Call Daily.co API to create room
        console.log('   📹 Creating Daily.co room...');
        const dailyResponse = await fetch('https://api.daily.co/v1/rooms', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${DAILY_API_KEY}`
          },
          body: JSON.stringify({
            name: roomName,
            properties: {
              enable_screenshare: true,
              enable_chat: true,
              start_video_off: false,
              start_audio_off: false,
              max_participants: 2,
              // Room expires 24 hours from now
              exp: Math.floor(Date.now() / 1000) + (24 * 60 * 60),
              enable_prejoin_ui: true,
            }
          })
        });

        if (!dailyResponse.ok) {
          const errorText = await dailyResponse.text();
          console.error(`   ❌ Daily.co API error (${dailyResponse.status}):`, errorText);
          results.push({
            consultationId: consultation.id,
            success: false,
            error: `Daily.co API error: ${dailyResponse.status}`
          });
          continue;
        }

        const roomData = await dailyResponse.json();
        console.log(`   ✅ Room created: ${roomData.url}`);

        // Update consultation with video link
        console.log('   💾 Updating database with video link...');
        const { error: updateError } = await supabase
          .from('consultations')
          .update({ video_link: roomData.url })
          .eq('id', consultation.id);

        if (updateError) {
          console.error(`   ❌ Error updating consultation:`, updateError);
          results.push({
            consultationId: consultation.id,
            success: false,
            error: 'Failed to save video link'
          });
          continue;
        }

        console.log('   ✅ Database updated with video link');

        // Send room link emails to both parties
        const studentName = consultation.student?.name || consultation.student?.email?.split('@')[0] || 'Student';
        const counselorName = consultation.counselor?.name || consultation.counselor?.email?.split('@')[0] || 'Counselor';

        try {
          console.log('   📧 Sending email to student...');
          await sendAcceptanceNotification(
            consultation.student.email,
            studentName,
            counselorName,
            consultation.date,
            consultation.time,
            roomData.url
          );
          console.log('   ✅ Student email sent');

          // Wait 2 seconds before sending counselor email
          console.log('   ⏳ Waiting before sending counselor email...');
          await new Promise(resolve => setTimeout(resolve, 2000));

          console.log('   📧 Sending email to counselor...');
          await sendCounselorAcceptanceNotification(
            consultation.counselor.email,
            counselorName,
            studentName,
            consultation.student.email,
            consultation.date,
            consultation.time,
            roomData.url
          );
          console.log('   ✅ Counselor email sent');

        } catch (emailErr) {
          console.error('   ⚠️ Failed to send room link emails:', emailErr.message);
          // Don't fail the whole operation if email fails
        }

        results.push({
          consultationId: consultation.id,
          success: true,
          roomUrl: roomData.url
        });

        console.log(`   ✅ Successfully processed consultation ${consultation.id}`);

      } catch (err) {
        console.error(`   ❌ Error processing consultation ${consultation.id}:`, err.message);
        results.push({
          consultationId: consultation.id,
          success: false,
          error: err.message
        });
      }
    }

    const successCount = results.filter(r => r.success).length;
    const failCount = results.filter(r => !r.success).length;

    console.log('\n' + '='.repeat(60));
    console.log('📊 SUMMARY');
    console.log('='.repeat(60));
    console.log(`✅ Successful: ${successCount}/${results.length}`);
    console.log(`❌ Failed: ${failCount}/${results.length}`);
    console.log('='.repeat(60));

    return {
      success: true,
      created: successCount,
      failed: failCount,
      total: results.length,
      results: results
    };

  } catch (err) {
    console.error('❌ Fatal error in room creation process:', err);
    return {
      success: false,
      error: err.message
    };
  }
}

// Run the script
if (require.main === module) {
  createRoomsForToday()
    .then(result => {
      console.log('\n✅ Script completed');
      console.log('Result:', JSON.stringify(result, null, 2));
      process.exit(result.success ? 0 : 1);
    })
    .catch(err => {
      console.error('\n❌ Script failed:', err);
      process.exit(1);
    });
}

module.exports = { createRoomsForToday };