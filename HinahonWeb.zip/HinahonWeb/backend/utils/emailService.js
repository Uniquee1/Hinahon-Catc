// backend/utils/emailService.js
const { Resend } = require('resend');

const resend = new Resend(process.env.RESEND_API_KEY);

// 🔧 PRODUCTION CONFIGURATION
// Set your verified domain email as sender
const SENDER_EMAIL = process.env.SENDER_EMAIL || 'noreply@yourdomain.com'; // ⚠️ CHANGE THIS
const SENDER_NAME = 'Hinahon Mental Health';
const FRONTEND_URL = process.env.FRONTEND_URL || 'https://yourapp.vercel.app'; // ⚠️ CHANGE THIS
const REPLY_TO_EMAIL = process.env.REPLY_TO_EMAIL || 'support@hinahon.me';

// Testing mode: if true, all emails go to TEST_EMAIL
const TESTING_MODE = process.env.TESTING_MODE === 'true';
const TEST_EMAIL = process.env.TEST_EMAIL;

/**
 * Helper to get recipient email (test mode override)
 */
function getRecipientEmail(intendedEmail) {
  if (TESTING_MODE && TEST_EMAIL) {
    console.log(`📧 TEST MODE: Email intended for ${intendedEmail} → sending to ${TEST_EMAIL}`);
    return TEST_EMAIL;
  }
  return intendedEmail;
}

/**
 * Helper to get subject prefix for test mode
 */
function getSubjectPrefix(intendedEmail) {
  return TESTING_MODE ? `[TEST - To: ${intendedEmail}] ` : '';
}

/**
 * Helper to get test banner HTML
 */
function getTestBanner(intendedEmail) {
  if (!TESTING_MODE) return '';
  
  return `
    <div class="test-banner">
      <strong>🧪 TEST EMAIL</strong><br>
      This email would be sent to: <strong>${intendedEmail}</strong><br>
      Currently sent to your test email because TESTING_MODE is enabled.
    </div>
  `;
}

/**
 * Helper function to format time
 */
function formatTime(timeString) {
  const [hours, minutes] = timeString.split(':');
  const hour = parseInt(hours);
  const ampm = hour >= 12 ? 'PM' : 'AM';
  const displayHour = hour % 12 || 12;
  return `${displayHour}:${minutes} ${ampm}`;
}

/**
 * Send booking confirmation to student
 */
async function sendBookingConfirmation(studentEmail, studentName, counselorName, date, time) {
  try {
    const formattedDate = new Date(date).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    const formattedTime = formatTime(time);
    const recipientEmail = getRecipientEmail(studentEmail);
    const subjectPrefix = getSubjectPrefix(studentEmail);

    const { data, error } = await resend.emails.send({
      from: `${SENDER_NAME} <${SENDER_EMAIL}>`,
      to: recipientEmail,
      reply_to: REPLY_TO_EMAIL, 
      subject: `${subjectPrefix}Consultation Booking Confirmed - Hinahon`,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <style>
            body { 
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
              line-height: 1.6; 
              color: #333;
              margin: 0;
              padding: 0;
              background-color: #f5f5f5;
            }
            .container { 
              max-width: 600px; 
              margin: 20px auto; 
              background: white;
              border-radius: 8px;
              overflow: hidden;
              box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            }
            .header { 
              background: linear-gradient(135deg, #e91e63, #00bfa5); 
              color: white; 
              padding: 40px 30px; 
              text-align: center;
            }
            .header h1 {
              margin: 0 0 10px 0;
              font-size: 28px;
              font-weight: 600;
            }
            .header p {
              margin: 0;
              opacity: 0.9;
              font-size: 16px;
            }
            .content { 
              padding: 40px 30px;
            }
            .info-box { 
              background: #f8f9fa; 
              padding: 20px; 
              margin: 25px 0; 
              border-left: 4px solid #00bfa5; 
              border-radius: 4px;
            }
            .info-box h3 {
              margin-top: 0;
              color: #00bfa5;
              font-size: 18px;
            }
            .info-box p {
              margin: 8px 0;
            }
            .test-banner { 
              background: #fff3cd; 
              padding: 15px 20px; 
              margin: 20px 30px; 
              border-left: 4px solid #856404; 
              border-radius: 4px;
            }
            .footer { 
              text-align: center; 
              padding: 30px;
              background: #f8f9fa;
              color: #666; 
              font-size: 13px;
              border-top: 1px solid #e0e0e0;
            }
            .footer p {
              margin: 5px 0;
            }
            ol, ul {
              padding-left: 20px;
            }
            li {
              margin: 8px 0;
            }
            strong {
              color: #333;
            }
          </style>
        </head>
        <body>
          <div class="container">
            ${getTestBanner(studentEmail)}
            <div class="header">
              <h1>Hinahon</h1>
              <p>Mental Health Consultation</p>
            </div>
            <div class="content">
              <h2 style="color: #333; margin-top: 0;">Booking Confirmed! ✓</h2>
              <p>Hello <strong>${studentName}</strong>,</p>
              <p>Your consultation booking has been successfully submitted. We're here to support your mental health journey.</p>
              
              <div class="info-box">
                <h3>Consultation Details</h3>
                <p><strong>Counselor:</strong> ${counselorName}</p>
                <p><strong>Date:</strong> ${formattedDate}</p>
                <p><strong>Time:</strong> ${formattedTime}</p>
                <p><strong>Status:</strong> <span style="color: #856404;">⏳ Pending Approval</span></p>
              </div>

              <h3 style="color: #333;">What Happens Next?</h3>
              <ol>
                <li>Your counselor will review your booking request</li>
                <li>You'll receive a confirmation email once approved</li>
                <li>A video call link will be provided in the confirmation</li>
                <li>Join the call at your scheduled time</li>
              </ol>

              <p><strong>Note:</strong> The video link will be accessible starting at your scheduled time and will remain active for 1 hour.</p>

              <p>If you have any questions or need to reschedule, please contact us as soon as possible.</p>
            </div>
            <div class="footer">
              <p><strong>Hinahon Mental Health Services</strong></p>
              <p>Need help? Email us at <a href="mailto:${REPLY_TO_EMAIL}" style="color:#e91e63">${REPLY_TO_EMAIL}</a></p>
              <p>&copy; 2025 Team Hinahon. All Rights Reserved.</p>
            </div>
          </div>
        </body>
        </html>
      `
    });

    if (error) {
      console.error('❌ Error sending booking confirmation:', error);
      return { success: false, error };
    }

    console.log(`✅ Booking confirmation sent to: ${recipientEmail}`);
    return { success: true, data };

  } catch (err) {
    console.error('❌ Exception in sendBookingConfirmation:', err);
    return { success: false, error: err.message };
  }
}

/**
 * Send new booking notification to counselor
 */
async function sendCounselorNotification(counselorEmail, counselorName, studentName, studentEmail, date, time) {
  try {
    const formattedDate = new Date(date).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    const formattedTime = formatTime(time);
    const recipientEmail = getRecipientEmail(counselorEmail);
    const subjectPrefix = getSubjectPrefix(counselorEmail);

    const { data, error } = await resend.emails.send({
      from: `${SENDER_NAME} <${SENDER_EMAIL}>`,
      to: recipientEmail,
      reply_to: REPLY_TO_EMAIL, 
      subject: `${subjectPrefix}New Consultation Request - Hinahon`,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <style>
            body { 
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
              line-height: 1.6; 
              color: #333;
              margin: 0;
              padding: 0;
              background-color: #f5f5f5;
            }
            .container { 
              max-width: 600px; 
              margin: 20px auto; 
              background: white;
              border-radius: 8px;
              overflow: hidden;
              box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            }
            .header { 
              background: linear-gradient(135deg, #e91e63, #00bfa5); 
              color: white; 
              padding: 40px 30px; 
              text-align: center;
            }
            .header h1 {
              margin: 0 0 10px 0;
              font-size: 28px;
              font-weight: 600;
            }
            .header p {
              margin: 0;
              opacity: 0.9;
              font-size: 16px;
            }
            .content { 
              padding: 40px 30px;
            }
            .info-box { 
              background: #f8f9fa; 
              padding: 20px; 
              margin: 25px 0; 
              border-left: 4px solid #e91e63; 
              border-radius: 4px;
            }
            .info-box h3 {
              margin-top: 0;
              color: #e91e63;
              font-size: 18px;
            }
            .info-box p {
              margin: 8px 0;
            }
            .test-banner { 
              background: #fff3cd; 
              padding: 15px 20px; 
              margin: 20px 30px; 
              border-left: 4px solid #856404; 
              border-radius: 4px;
            }
            .button { 
              display: inline-block; 
              background: #e91e63; 
              color: white; 
              padding: 14px 32px; 
              text-decoration: none; 
              border-radius: 6px; 
              margin-top: 20px;
              font-weight: 600;
            }
            .button:hover {
              background: #c2185b;
            }
            .footer { 
              text-align: center; 
              padding: 30px;
              background: #f8f9fa;
              color: #666; 
              font-size: 13px;
              border-top: 1px solid #e0e0e0;
            }
            .footer p {
              margin: 5px 0;
            }
          </style>
        </head>
        <body>
          <div class="container">
            ${getTestBanner(counselorEmail)}
            <div class="header">
              <h1>Hinahon</h1>
              <p>Counselor Dashboard</p>
            </div>
            <div class="content">
              <h2 style="color: #333; margin-top: 0;">New Consultation Request 📋</h2>
              <p>Hello <strong>${counselorName}</strong>,</p>
              <p>You have received a new consultation booking request.</p>
              
              <div class="info-box">
                <h3>Request Details</h3>
                <p><strong>Student:</strong> ${studentName}</p>
                <p><strong>Email:</strong> ${studentEmail}</p>
                <p><strong>Requested Date:</strong> ${formattedDate}</p>
                <p><strong>Requested Time:</strong> ${formattedTime}</p>
              </div>

              <p><strong>Action Required:</strong> Please log in to your counselor dashboard to review and respond to this request.</p>

              <a href="${FRONTEND_URL}/counselor" class="button">
                View Dashboard →
              </a>

              <p style="margin-top: 30px; font-size: 14px; color: #666;">
                <strong>Note:</strong> Please respond to this request within 24 hours. The student is waiting for your confirmation.
              </p>
            </div>
            <div class="footer">
              <p><strong>Hinahon Mental Health Services</strong></p>
              <p>Need help? Email us at <a href="mailto:${REPLY_TO_EMAIL}" style="color:#e91e63">${REPLY_TO_EMAIL}</a></p>
              <p>&copy; 2025 Team Hinahon. All Rights Reserved.</p>
            </div>
          </div>
        </body>
        </html>
      `
    });

    if (error) {
      console.error('❌ Error sending counselor notification:', error);
      return { success: false, error };
    }

    console.log(`✅ Counselor notification sent to: ${recipientEmail}`);
    return { success: true, data };

  } catch (err) {
    console.error('❌ Exception in sendCounselorNotification:', err);
    return { success: false, error: err.message };
  }
}

/**
 * Send acceptance confirmation with video link to student
 */
async function sendAcceptanceNotification(studentEmail, studentName, counselorName, date, time, videoLink) {
  try {
    const formattedDate = new Date(date).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    const formattedTime = formatTime(time);
    const recipientEmail = getRecipientEmail(studentEmail);
    const subjectPrefix = getSubjectPrefix(studentEmail);

    const { data, error } = await resend.emails.send({
      from: `${SENDER_NAME} <${SENDER_EMAIL}>`,
      to: recipientEmail,
      reply_to: REPLY_TO_EMAIL, 
      subject: `${subjectPrefix}Consultation Approved - Video Link Included ✅`,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <style>
            body { 
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
              line-height: 1.6; 
              color: #333;
              margin: 0;
              padding: 0;
              background-color: #f5f5f5;
            }
            .container { 
              max-width: 600px; 
              margin: 20px auto; 
              background: white;
              border-radius: 8px;
              overflow: hidden;
              box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            }
            .header { 
              background: linear-gradient(135deg, #00bfa5, #00897b); 
              color: white; 
              padding: 40px 30px; 
              text-align: center;
            }
            .header h1 {
              margin: 0;
              font-size: 32px;
              font-weight: 600;
            }
            .content { 
              padding: 40px 30px;
            }
            .info-box { 
              background: #f8f9fa; 
              padding: 20px; 
              margin: 25px 0; 
              border-left: 4px solid #00bfa5; 
              border-radius: 4px;
            }
            .info-box h3 {
              margin-top: 0;
              color: #00bfa5;
              font-size: 18px;
            }
            .info-box p {
              margin: 8px 0;
            }
            .video-box { 
              background: linear-gradient(135deg, #e0f7f4, #b2ebf2); 
              padding: 30px; 
              margin: 25px 0; 
              border: 2px solid #00bfa5; 
              border-radius: 8px; 
              text-align: center;
            }
            .video-box h3 {
              color: #00897b;
              margin-top: 0;
              font-size: 20px;
            }
            .test-banner { 
              background: #fff3cd; 
              padding: 15px 20px; 
              margin: 20px 30px; 
              border-left: 4px solid #856404; 
              border-radius: 4px;
            }
            .button { 
              display: inline-block; 
              background: #00bfa5; 
              color: white; 
              padding: 16px 40px; 
              text-decoration: none; 
              border-radius: 6px; 
              font-size: 16px; 
              font-weight: 600;
              margin: 10px 0;
            }
            .button:hover {
              background: #00897b;
            }
            .warning { 
              background: #fff3e0; 
              padding: 20px; 
              border-left: 4px solid #ff9800; 
              margin: 20px 0; 
              border-radius: 4px;
            }
            .footer { 
              text-align: center; 
              padding: 30px;
              background: #f8f9fa;
              color: #666; 
              font-size: 13px;
              border-top: 1px solid #e0e0e0;
            }
            .footer p {
              margin: 5px 0;
            }
            code {
              background: white;
              padding: 8px 12px;
              border-radius: 4px;
              display: inline-block;
              margin-top: 10px;
              word-break: break-all;
              font-size: 12px;
              border: 1px solid #e0e0e0;
            }
            ul {
              padding-left: 20px;
            }
            li {
              margin: 8px 0;
            }
          </style>
        </head>
        <body>
          <div class="container">
            ${getTestBanner(studentEmail)}
            <div class="header">
              <h1>✅ Consultation Approved!</h1>
            </div>
            <div class="content">
              <p>Hello <strong>${studentName}</strong>,</p>
              <p>Great news! Your consultation has been approved by your counselor.</p>
              
              <div class="info-box">
                <h3>Consultation Details</h3>
                <p><strong>Counselor:</strong> ${counselorName}</p>
                <p><strong>Date:</strong> ${formattedDate}</p>
                <p><strong>Time:</strong> ${formattedTime}</p>
                <p><strong>Status:</strong> <span style="color: #2e7d32;">✓ Confirmed</span></p>
              </div>

              <div class="video-box">
                <h3>🎥 Your Video Call Link</h3>
                <p style="margin: 20px 0;">Click the button below to join your consultation:</p>
                <a href="${videoLink}" class="button">
                  Join Video Consultation
                </a>
                <p style="margin-top: 20px; font-size: 14px; color: #555;">
                  Or copy this link:
                </p>
                <code>${videoLink}</code>
              </div>

              <div class="warning">
                <strong>⏰ Important:</strong>
                <ul style="margin: 10px 0;">
                  <li>The video link will be <strong>active at your scheduled time</strong></li>
                  <li>The link remains active for <strong>1 hour</strong> after the start time</li>
                  <li>Please join on time to make the most of your session</li>
                </ul>
              </div>

              <h3 style="color: #333;">Before Your Session:</h3>
              <ul>
                <li>✓ Test your camera and microphone</li>
                <li>✓ Find a quiet, private space</li>
                <li>✓ Have a stable internet connection</li>
                <li>✓ Prepare any questions or concerns you want to discuss</li>
              </ul>

              <p>We're here to support you. If you have any technical issues or need to reschedule, please contact us immediately.</p>
            </div>
            <div class="footer">
              <p><strong>Hinahon Mental Health Services</strong></p>
              <p>Need help? Email us at <a href="mailto:${REPLY_TO_EMAIL}" style="color:#e91e63">${REPLY_TO_EMAIL}</a></p>
              <p>&copy; 2025 Team Hinahon. All Rights Reserved.</p>
            </div>
          </div>
        </body>
        </html>
      `
    });

    if (error) {
      console.error('❌ Error sending acceptance notification:', error);
      return { success: false, error };
    }

    console.log(`✅ Acceptance notification sent to: ${recipientEmail}`);
    return { success: true, data };

  } catch (err) {
    console.error('❌ Exception in sendAcceptanceNotification:', err);
    return { success: false, error: err.message };
  }
}

/**
 * Send acceptance confirmation to counselor with video link
 */
async function sendCounselorAcceptanceNotification(counselorEmail, counselorName, studentName, studentEmail, date, time, videoLink) {
  try {
    const formattedDate = new Date(date).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    const formattedTime = formatTime(time);
    const recipientEmail = getRecipientEmail(counselorEmail);
    const subjectPrefix = getSubjectPrefix(counselorEmail);

    const { data, error } = await resend.emails.send({
      from: `${SENDER_NAME} <${SENDER_EMAIL}>`,
      to: recipientEmail,
      reply_to: REPLY_TO_EMAIL, 
      subject: `${subjectPrefix}Consultation Accepted - Video Link & Student Details`,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <style>
            body { 
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
              line-height: 1.6; 
              color: #333;
              margin: 0;
              padding: 0;
              background-color: #f5f5f5;
            }
            .container { 
              max-width: 600px; 
              margin: 20px auto; 
              background: white;
              border-radius: 8px;
              overflow: hidden;
              box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            }
            .header { 
              background: linear-gradient(135deg, #00bfa5, #00897b); 
              color: white; 
              padding: 40px 30px; 
              text-align: center;
            }
            .header h1 {
              margin: 0 0 10px 0;
              font-size: 28px;
              font-weight: 600;
            }
            .header p {
              margin: 0;
              opacity: 0.9;
            }
            .content { 
              padding: 40px 30px;
            }
            .info-box { 
              background: #f8f9fa; 
              padding: 20px; 
              margin: 25px 0; 
              border-left: 4px solid #00bfa5; 
              border-radius: 4px;
            }
            .info-box h3 {
              margin-top: 0;
              color: #00bfa5;
              font-size: 18px;
            }
            .info-box p {
              margin: 8px 0;
            }
            .video-box { 
              background: linear-gradient(135deg, #e0f7f4, #b2ebf2); 
              padding: 30px; 
              margin: 25px 0; 
              border: 2px solid #00bfa5; 
              border-radius: 8px; 
              text-align: center;
            }
            .video-box h3 {
              color: #00897b;
              margin-top: 0;
              font-size: 20px;
            }
            .test-banner { 
              background: #fff3cd; 
              padding: 15px 20px; 
              margin: 20px 30px; 
              border-left: 4px solid #856404; 
              border-radius: 4px;
            }
            .button { 
              display: inline-block; 
              background: #00bfa5; 
              color: white; 
              padding: 16px 40px; 
              text-decoration: none; 
              border-radius: 6px; 
              font-size: 16px; 
              font-weight: 600;
              margin: 10px 0;
            }
            .button:hover {
              background: #00897b;
            }
            .warning { 
              background: #fff3e0; 
              padding: 20px; 
              border-left: 4px solid #ff9800; 
              margin: 20px 0; 
              border-radius: 4px;
            }
            .footer { 
              text-align: center; 
              padding: 30px;
              background: #f8f9fa;
              color: #666; 
              font-size: 13px;
              border-top: 1px solid #e0e0e0;
            }
            .footer p {
              margin: 5px 0;
            }
            code {
              background: white;
              padding: 8px 12px;
              border-radius: 4px;
              display: inline-block;
              margin-top: 10px;
              word-break: break-all;
              font-size: 12px;
              border: 1px solid #e0e0e0;
            }
            ul {
              padding-left: 20px;
            }
            li {
              margin: 8px 0;
            }
          </style>
        </head>
        <body>
          <div class="container">
            ${getTestBanner(counselorEmail)}
            <div class="header">
              <h1>✅ Consultation Confirmed!</h1>
              <p>Counselor Copy</p>
            </div>
            <div class="content">
              <p>Hello <strong>${counselorName}</strong>,</p>
              <p>This is your confirmation that you've accepted a consultation session. Below are the complete details.</p>
              
              <div class="info-box">
                <h3>Session Details</h3>
                <p><strong>Student Name:</strong> ${studentName}</p>
                <p><strong>Student Email:</strong> ${studentEmail}</p>
                <p><strong>Date:</strong> ${formattedDate}</p>
                <p><strong>Time:</strong> ${formattedTime}</p>
                <p><strong>Status:</strong> <span style="color: #2e7d32;">✓ Confirmed</span></p>
              </div>

              <div class="video-box">
                <h3>🎥 Your Video Call Link</h3>
                <p style="margin: 20px 0;">Click the button below to join the consultation:</p>
                <a href="${videoLink}" class="button">
                  Join Video Consultation
                </a>
                <p style="margin-top: 20px; font-size: 14px; color: #555;">
                  Or copy this link:
                </p>
                <code>${videoLink}</code>
              </div>

              <div class="warning">
                <strong>⏰ Important Session Information:</strong>
                <ul style="margin: 10px 0;">
                  <li>The video link will be <strong>active at the scheduled time</strong></li>
                  <li>The link remains active for <strong>1 hour</strong> after the start time</li>
                  <li>Please join a few minutes early to ensure everything is working</li>
                  <li>The student has also received this video link via email</li>
                </ul>
              </div>

              <h3 style="color: #333;">Session Preparation Checklist:</h3>
              <ul>
                <li>✓ Review student information before the session</li>
                <li>✓ Ensure your camera and microphone are working</li>
                <li>✓ Choose a quiet, private space for the consultation</li>
                <li>✓ Have stable internet connection</li>
                <li>✓ Prepare any relevant materials or notes</li>
              </ul>

              <p>If you need to cancel or reschedule this session, please contact the student as soon as possible and update the booking status in your dashboard.</p>
            </div>
            <div class="footer">
              <p><strong>Hinahon Mental Health Services</strong></p>
              <p>Need help? Email us at <a href="mailto:${REPLY_TO_EMAIL}" style="color:#e91e63">${REPLY_TO_EMAIL}</a></p>
              <p>&copy; 2025 Team Hinahon. All Rights Reserved.</p>
            </div>
          </div>
        </body>
        </html>
      `
    });

    if (error) {
      console.error('❌ Error sending counselor acceptance notification:', error);
      return { success: false, error };
    }

    console.log(`✅ Counselor acceptance notification sent to: ${recipientEmail}`);
    return { success: true, data };

  } catch (err) {
    console.error('❌ Exception in sendCounselorAcceptanceNotification:', err);
    return { success: false, error: err.message };
  }
}

/**
 * Send rejection notification
 */
async function sendRejectionNotification(studentEmail, studentName, counselorName, date, time, reason) {
  try {
    const formattedDate = new Date(date).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    const formattedTime = formatTime(time);
    const recipientEmail = getRecipientEmail(studentEmail);
    const subjectPrefix = getSubjectPrefix(studentEmail);

    const { data, error } = await resend.emails.send({
      from: `${SENDER_NAME} <${SENDER_EMAIL}>`,
      to: recipientEmail,
      reply_to: REPLY_TO_EMAIL, 
      subject: `${subjectPrefix}Consultation Request Update - Hinahon`,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <style>
            body { 
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
              line-height: 1.6; 
              color: #333;
              margin: 0;
              padding: 0;
              background-color: #f5f5f5;
            }
            .container { 
              max-width: 600px; 
              margin: 20px auto; 
              background: white;
              border-radius: 8px;
              overflow: hidden;
              box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            }
            .header { 
              background: #6c757d; 
              color: white; 
              padding: 40px 30px; 
              text-align: center;
            }
            .header h1 {
              margin: 0;
              font-size: 28px;
              font-weight: 600;
            }
            .content { 
              padding: 40px 30px;
            }
            .info-box { 
              background: #f8f9fa; 
              padding: 20px; 
              margin: 25px 0; 
              border-left: 4px solid #6c757d; 
              border-radius: 4px;
            }
            .info-box h3 {
              margin-top: 0;
              color: #495057;
              font-size: 18px;
            }
            .info-box p {
              margin: 8px 0;
            }
            .test-banner { 
              background: #fff3cd; 
              padding: 15px 20px; 
              margin: 20px 30px; 
              border-left: 4px solid #856404; 
              border-radius: 4px;
            }
            .button { 
              display: inline-block; 
              background: #00bfa5; 
              color: white; 
              padding: 14px 32px; 
              text-decoration: none; 
              border-radius: 6px; 
              margin-top: 20px;
              font-weight: 600;
            }
            .button:hover {
              background: #00897b;
            }
            .footer { 
              text-align: center; 
              padding: 30px;
              background: #f8f9fa;
              color: #666; 
              font-size: 13px;
              border-top: 1px solid #e0e0e0;
            }
            .footer p {
              margin: 5px 0;
            }
            ul {
              padding-left: 20px;
            }
            li {
              margin: 8px 0;
            }
          </style>
        </head>
        <body>
          <div class="container">
            ${getTestBanner(studentEmail)}
            <div class="header">
              <h1>Consultation Request Update</h1>
            </div>
            <div class="content">
              <p>Hello <strong>${studentName}</strong>,</p>
              <p>We wanted to update you about your consultation request.</p>
              
              <div class="info-box">
                <h3>Request Details</h3>
                <p><strong>Counselor:</strong> ${counselorName}</p>
                <p><strong>Date:</strong> ${formattedDate}</p>
                <p><strong>Time:</strong> ${formattedTime}</p>
                ${reason ? `<p><strong>Note:</strong> ${reason}</p>` : ''}
              </div>

              <p>Unfortunately, your counselor is unable to accommodate this particular time slot. Please don't be discouraged - this doesn't reflect on you or your needs.</p>

              <h3 style="color: #333;">What You Can Do:</h3>
              <ul>
                <li>Book another time slot that works better</li>
                <li>Choose a different counselor if available</li>
                <li>Contact us if you need assistance</li>
              </ul>

              <a href="${FRONTEND_URL}/booking" class="button">
                Book Another Time
              </a>

              <p style="margin-top: 30px;">Remember, seeking help is a sign of strength. We're here to support you on your mental health journey.</p>
            </div>
            <div class="footer">
              <p><strong>Hinahon Mental Health Services</strong></p>
              <p>Need help? Email us at <a href="mailto:${REPLY_TO_EMAIL}" style="color:#e91e63">${REPLY_TO_EMAIL}</a></p>
              <p>&copy; 2025 Team Hinahon. All Rights Reserved.</p>
            </div>
          </div>
        </body>
        </html>
      `
    });

    if (error) {
      console.error('❌ Error sending rejection notification:', error);
      return { success: false, error };
    }

    console.log(`✅ Rejection notification sent to: ${recipientEmail}`);
    return { success: true, data };

  } catch (err) {
    console.error('❌ Exception in sendRejectionNotification:', err);
    return { success: false, error: err.message };
  }
}

/**
 * Send auto-rejection notification when slot is taken by another student
 */
async function sendAutoRejectionNotification(studentEmail, studentName, counselorName, date, time) {
  try {
    const formattedDate = new Date(date).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    const formattedTime = formatTime(time);
    const recipientEmail = getRecipientEmail(studentEmail);
    const subjectPrefix = getSubjectPrefix(studentEmail);

    const { data, error } = await resend.emails.send({
      from: `${SENDER_NAME} <${SENDER_EMAIL}>`,
      to: recipientEmail,
      reply_to: REPLY_TO_EMAIL, 
      subject: `${subjectPrefix}Consultation Time Slot No Longer Available - Hinahon`,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <style>
            body { 
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
              line-height: 1.6; 
              color: #333;
              margin: 0;
              padding: 0;
              background-color: #f5f5f5;
            }
            .container { 
              max-width: 600px; 
              margin: 20px auto; 
              background: white;
              border-radius: 8px;
              overflow: hidden;
              box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            }
            .header { 
              background: #ff9800; 
              color: white; 
              padding: 40px 30px; 
              text-align: center;
            }
            .header h1 {
              margin: 0;
              font-size: 28px;
              font-weight: 600;
            }
            .content { 
              padding: 40px 30px;
            }
            .info-box { 
              background: #f8f9fa; 
              padding: 20px; 
              margin: 25px 0; 
              border-left: 4px solid #ff9800; 
              border-radius: 4px;
            }
            .info-box h3 {
              margin-top: 0;
              color: #f57c00;
              font-size: 18px;
            }
            .info-box p {
              margin: 8px 0;
            }
            .test-banner { 
              background: #fff3cd; 
              padding: 15px 20px; 
              margin: 20px 30px; 
              border-left: 4px solid #856404; 
              border-radius: 4px;
            }
            .button { 
              display: inline-block; 
              background: #00bfa5; 
              color: white; 
              padding: 14px 32px; 
              text-decoration: none; 
              border-radius: 6px; 
              margin-top: 20px;
              font-weight: 600;
            }
            .button:hover {
              background: #00897b;
            }
            .footer { 
              text-align: center; 
              padding: 30px;
              background: #f8f9fa;
              color: #666; 
              font-size: 13px;
              border-top: 1px solid #e0e0e0;
            }
            .footer p {
              margin: 5px 0;
            }
            ul {
              padding-left: 20px;
            }
            li {
              margin: 8px 0;
            }
          </style>
        </head>
        <body>
          <div class="container">
            ${getTestBanner(studentEmail)}
            <div class="header">
              <h1>⚠️ Time Slot Update</h1>
            </div>
            <div class="content">
              <p>Hello <strong>${studentName}</strong>,</p>
              <p>We wanted to inform you about a change to your consultation request.</p>
              
              <div class="info-box">
                <h3>Requested Time Slot</h3>
                <p><strong>Counselor:</strong> ${counselorName}</p>
                <p><strong>Date:</strong> ${formattedDate}</p>
                <p><strong>Time:</strong> ${formattedTime}</p>
              </div>

              <p><strong>What happened?</strong></p>
              <p>Unfortunately, this time slot was booked by another student while your request was pending. The counselor has accepted their consultation request for this specific time.</p>

              <p><strong>This is not a reflection of you or your needs.</strong> Time slots are handled on a first-accepted basis to ensure fair scheduling.</p>

              <h3 style="color: #333;">📅 What You Can Do Next:</h3>
              <ul>
                <li>Book a different time slot with the same counselor</li>
                <li>Choose a different counselor who may have availability</li>
                <li>Contact us if you need help finding available times</li>
              </ul>

              <a href="${FRONTEND_URL}/booking" class="button">
                View Available Time Slots
              </a>

              <p style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e0e0e0; font-size: 14px; color: #666;">
                <strong>Remember:</strong> Your mental health matters. We're here to help you find the right time to connect with a counselor. Don't hesitate to book another slot that works for you.
              </p>
            </div>
            <div class="footer">
              <p><strong>Hinahon Mental Health Services</strong></p>
              <p>If you have any questions, please contact our support team</p>
              <p>&copy; 2025 Team Hinahon. All Rights Reserved.</p>
            </div>
          </div>
        </body>
        </html>
      `
    });

    if (error) {
      console.error('❌ Error sending auto-rejection notification:', error);
      return { success: false, error };
    }

    console.log(`✅ Auto-rejection notification sent to: ${recipientEmail}`);
    return { success: true, data };

  } catch (err) {
    console.error('❌ Exception in sendAutoRejectionNotification:', err);
    return { success: false, error: err.message };
  }
}

module.exports = {
  sendBookingConfirmation,
  sendCounselorNotification,
  sendAcceptanceNotification,
  sendCounselorAcceptanceNotification,
  sendRejectionNotification,
  sendAutoRejectionNotification
};