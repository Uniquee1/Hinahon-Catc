import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "../supabaseClient";
import "../styles.css";

export default function BookingPage({ session }) {
  const navigate = useNavigate();
  const { emotion } = useParams();
  const [bookingFlow, setBookingFlow] = useState("");
  const [counselors, setCounselors] = useState([]);
  const [selectedCounselor, setSelectedCounselor] = useState("");
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedSlot, setSelectedSlot] = useState("");
  const [availableSlots, setAvailableSlots] = useState([]);
  const [availableCounselors, setAvailableCounselors] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const isGuest = session?.isGuest;
  const user = session?.user;

  useEffect(() => {
    fetchCounselors();
  }, []);

  useEffect(() => {
    if (bookingFlow === "date-first" && selectedDate) {
      fetchAvailableCounselorsForDate();
    }
  }, [selectedDate, bookingFlow]);

  useEffect(() => {
    if (bookingFlow === "counselor-first" && selectedCounselor) {
      fetchAvailableSlotsForCounselor();
    }
  }, [selectedCounselor, bookingFlow]);

  const fetchCounselors = async () => {
    try {
      const { data, error } = await supabase
        .from("users")
        .select("id, name, email")
        .eq("role", "counselor");

      if (error) throw error;
      setCounselors(data || []);
    } catch (err) {
      console.error("Error fetching counselors:", err);
      setError("Failed to load counselors");
    }
  };

  // ✅ FIXED: Only fetch unbooked slots
  const fetchAvailableCounselorsForDate = async () => {
    try {
      setLoading(true);
      setError("");
      console.log("=== FETCHING AVAILABLE COUNSELORS ===");
      console.log("Selected date:", selectedDate);
      
      const { data: availabilityData, error: availabilityError } = await supabase
        .from("availability")
        .select("id, start_time, end_time, counselor_id, is_booked, date")
        .eq("date", selectedDate)
        .eq("is_booked", false) // ✅ Only unbooked slots
        .order("start_time");

      console.log("Available (unbooked) slots:", availabilityData);

      if (availabilityError) throw availabilityError;

      if (!availabilityData || availabilityData.length === 0) {
        setAvailableCounselors([]);
        setError(`No available time slots for ${selectedDate}. All slots may be booked.`);
        return;
      }

      const counselorIds = [...new Set(availabilityData.map(slot => slot.counselor_id))];

      const { data: counselorsData, error: counselorsError } = await supabase
        .from("users")
        .select("id, name, email, role")
        .in("id", counselorIds)
        .eq("role", "counselor");

      if (counselorsError) throw counselorsError;

      if (!counselorsData || counselorsData.length === 0) {
        setAvailableCounselors([]);
        setError("Counselor data not found.");
        return;
      }

      const counselorMap = {};
      counselorsData.forEach(counselor => {
        counselorMap[counselor.id] = {
          counselor: counselor,
          slots: []
        };
      });

      availabilityData.forEach(slot => {
        if (counselorMap[slot.counselor_id]) {
          counselorMap[slot.counselor_id].slots.push(slot);
        }
      });

      const result = Object.values(counselorMap);
      console.log("✅ Final result (only unbooked slots):", result);
      setAvailableCounselors(result);

    } catch (err) {
      console.error("❌ Error fetching available counselors:", err);
      setError("Failed to load available counselors.");
    } finally {
      setLoading(false);
    }
  };

  // ✅ FIXED: Only fetch unbooked slots
  const fetchAvailableSlotsForCounselor = async () => {
    try {
      setLoading(true);
      setError("");
      
      const { data, error } = await supabase
        .from("availability")
        .select("id, date, start_time, end_time, is_booked")
        .eq("counselor_id", selectedCounselor)
        .eq("is_booked", false) // ✅ Only unbooked slots
        .gte("date", new Date().toISOString().split('T')[0])
        .order("date")
        .order("start_time");

      console.log("Fetched slots for counselor:", data);

      if (error) throw error;

      if (!data || data.length === 0) {
        setAvailableSlots({});
        setError("This counselor has no available time slots.");
        return;
      }

      const dateMap = {};
      data.forEach(slot => {
        const date = slot.date;
        if (!dateMap[date]) {
          dateMap[date] = [];
        }
        dateMap[date].push(slot);
      });

      setAvailableSlots(dateMap);
    } catch (err) {
      console.error("Error fetching available slots:", err);
      setError("Failed to load available slots");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (isGuest) {
      alert("Please sign in to book a consultation");
      navigate("/");
      return;
    }

    if (!selectedSlot) {
      setError("Please select a time slot");
      return;
    }

    setLoading(true);
    setError("");

    try {
      console.log("=== BOOKING PROCESS STARTED ===");
      console.log("Selected slot ID:", selectedSlot);

      // ✅ STEP 1: Check if slot is still available
      const { data: slotCheck, error: checkError } = await supabase
        .from("availability")
        .select("id, date, start_time, end_time, counselor_id, is_booked")
        .eq("id", selectedSlot)
        .single();

      console.log("Slot check result:", slotCheck);

      if (checkError) {
        console.error("Error checking slot:", checkError);
        throw new Error("Failed to verify slot availability");
      }

      if (!slotCheck) {
        throw new Error("Slot not found");
      }

      // ✅ STEP 2: Verify slot is not booked
      if (slotCheck.is_booked === true) {
        console.warn("Slot is already booked!");
        setError("Sorry, this slot was just booked by someone else. Please select another time.");
        setSelectedSlot("");
        
        // Refresh the available slots
        if (bookingFlow === "date-first") {
          await fetchAvailableCounselorsForDate();
        } else {
          await fetchAvailableSlotsForCounselor();
        }
        setLoading(false);
        return;
      }

      console.log("✅ Slot is available, proceeding with booking...");

      // ✅ STEP 3: Mark slot as booked FIRST (to prevent race conditions)
      const { error: updateError } = await supabase
        .from("availability")
        .update({ is_booked: true })
        .eq("id", selectedSlot)
        .eq("is_booked", false); // Only update if still false

      if (updateError) {
        console.error("Error marking slot as booked:", updateError);
        throw new Error("Failed to reserve time slot");
      }

      console.log("✅ Slot marked as booked");

      // ✅ STEP 4: Create consultation
      const { data: consultationData, error: consultationError } = await supabase
        .from("consultations")
        .insert({
          student_id: user.id,
          counselor_id: slotCheck.counselor_id,
          date: slotCheck.date,
          time: slotCheck.start_time,
          status: "pending",
          availability_id: selectedSlot
        })
        .select()
        .single();

      if (consultationError) {
        console.error("Error creating consultation:", consultationError);
        
        // Rollback: Unmark the slot if consultation creation failed
        await supabase
          .from("availability")
          .update({ is_booked: false })
          .eq("id", selectedSlot);
        
        throw new Error("Failed to create consultation");
      }

      console.log("✅ Consultation created:", consultationData);

      alert("✅ Consultation request submitted successfully!\n\nYou will receive an email notification once the counselor responds.");
      navigate("/landing");

    } catch (err) {
      console.error("❌ Error booking consultation:", err);
      setError(`Failed to book consultation: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const resetFlow = () => {
    setBookingFlow("");
    setSelectedCounselor("");
    setSelectedDate("");
    setSelectedSlot("");
    setAvailableSlots([]);
    setAvailableCounselors([]);
    setError("");
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric"
    });
  };

  const formatTime = (timeString) => {
    return new Date(`2000-01-01T${timeString}`).toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true
    });
  };

  const getMinDate = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  };

  const getMaxDate = () => {
    const maxDate = new Date();
    maxDate.setDate(maxDate.getDate() + 90);
    return maxDate.toISOString().split('T')[0];
  };

  // ✅ NEW: Render slot button with visual indicators
  const renderSlotButton = (slot) => {
    const isBooked = slot.is_booked;
    const isSelected = selectedSlot === slot.id;
    
    return (
      <button
        key={slot.id}
        onClick={() => !isBooked && setSelectedSlot(slot.id)}
        disabled={isBooked}
        style={{
          padding: "10px 16px",
          border: isSelected 
            ? "2px solid var(--teal)" 
            : isBooked 
              ? "1px solid #ffcdd2"
              : "1px solid #ccc",
          borderRadius: "6px",
          backgroundColor: isBooked 
            ? "#ffebee" 
            : (isSelected ? "var(--teal)" : "white"),
          color: isBooked 
            ? "#999" 
            : (isSelected ? "white" : "#333"),
          cursor: isBooked ? "not-allowed" : "pointer",
          fontSize: "14px",
          opacity: isBooked ? 0.6 : 1,
          position: "relative",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: "4px",
          transition: "all 0.2s ease",
          minWidth: "140px"
        }}
        title={isBooked ? "This slot is already booked by another student" : "Click to select this time"}
        onMouseEnter={(e) => {
          if (!isBooked) {
            e.currentTarget.style.transform = "translateY(-2px)";
            e.currentTarget.style.boxShadow = "0 4px 8px rgba(0,0,0,0.1)";
          }
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.transform = "translateY(0)";
          e.currentTarget.style.boxShadow = "none";
        }}
      >
        <span style={{ fontWeight: isSelected ? "600" : "500" }}>
          {formatTime(slot.start_time)} - {formatTime(slot.end_time)}
        </span>
        {isBooked && (
          <span style={{ 
            fontSize: "10px", 
            color: "#d32f2f",
            fontWeight: "600",
            textTransform: "uppercase"
          }}>
            ✕ Booked
          </span>
        )}
      </button>
    );
  };

  return (
    <div className="landing-root">
      <header className="landing-header">
        <div className="header-left">
          <div className="logo-top">Hinahon</div>
          <div className="tagline-mini">Book a Consultation</div>
        </div>
        <div className="header-right">
          <button 
            onClick={() => navigate("/landing")}
            style={{ 
              background: "none", 
              border: "none", 
              color: "#666", 
              cursor: "pointer",
              font: "inherit"
            }}
          >
            ← Back to Home
          </button>
        </div>
      </header>

      <main style={{ padding: "40px 24px", maxWidth: "900px", margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: "32px" }}>
          <h1 style={{ color: "var(--pink)", fontSize: "36px", margin: "0 0 12px 0" }}>
            Book Your Consultation
          </h1>
          {emotion && (
            <p style={{ color: "#666", fontSize: "16px" }}>
              We understand you're feeling <strong>{emotion}</strong>. 
              Let's connect you with a professional counselor.
            </p>
          )}
        </div>

        {isGuest ? (
          <div style={{ 
            textAlign: "center", 
            padding: "40px", 
            backgroundColor: "#f9f9f9", 
            borderRadius: "12px",
            margin: "20px 0"
          }}>
            <h3 style={{ color: "var(--pink)", marginBottom: "16px" }}>
              Sign In Required
            </h3>
            <p style={{ marginBottom: "20px", color: "#666" }}>
              You need to sign in to book a consultation with our counselors.
            </p>
            <button 
              onClick={() => navigate("/")}
              className="btn-action primary"
              style={{ padding: "12px 24px" }}
            >
              Sign In Now
            </button>
          </div>
        ) : (
          <div style={{ 
            backgroundColor: "white", 
            padding: "32px", 
            borderRadius: "12px", 
            boxShadow: "var(--card-shadow)" 
          }}>
            {!bookingFlow && (
              <div>
                <h3 style={{ marginBottom: "24px", textAlign: "center" }}>
                  How would you like to book your consultation?
                </h3>
                
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
                  <button
                    onClick={() => setBookingFlow("date-first")}
                    style={{
                      padding: "32px 24px",
                      border: "2px solid #e0e0e0",
                      borderRadius: "12px",
                      backgroundColor: "white",
                      cursor: "pointer",
                      textAlign: "center",
                      transition: "all 0.2s ease"
                    }}
                    onMouseEnter={(e) => {
                      e.target.style.borderColor = "var(--teal)";
                      e.target.style.backgroundColor = "rgba(0,191,165,0.05)";
                    }}
                    onMouseLeave={(e) => {
                      e.target.style.borderColor = "#e0e0e0";
                      e.target.style.backgroundColor = "white";
                    }}
                  >
                    <div style={{ fontSize: "48px", marginBottom: "16px" }}>📅</div>
                    <h4 style={{ margin: "0 0 12px 0", color: "var(--text)" }}>
                      Choose Date & Time First
                    </h4>
                    <p style={{ margin: "0", color: "#666", fontSize: "14px" }}>
                      Pick your preferred date and time, then see which counselors are available
                    </p>
                  </button>

                  <button
                    onClick={() => setBookingFlow("counselor-first")}
                    style={{
                      padding: "32px 24px",
                      border: "2px solid #e0e0e0",
                      borderRadius: "12px",
                      backgroundColor: "white",
                      cursor: "pointer",
                      textAlign: "center",
                      transition: "all 0.2s ease"
                    }}
                    onMouseEnter={(e) => {
                      e.target.style.borderColor = "var(--teal)";
                      e.target.style.backgroundColor = "rgba(0,191,165,0.05)";
                    }}
                    onMouseLeave={(e) => {
                      e.target.style.borderColor = "#e0e0e0";
                      e.target.style.backgroundColor = "white";
                    }}
                  >
                    <div style={{ fontSize: "48px", marginBottom: "16px" }}>👨‍⚕️</div>
                    <h4 style={{ margin: "0 0 12px 0", color: "var(--text)" }}>
                      Choose Counselor First
                    </h4>
                    <p style={{ margin: "0", color: "#666", fontSize: "14px" }}>
                      Pick your preferred counselor, then see their available times
                    </p>
                  </button>
                </div>
              </div>
            )}

            {bookingFlow === "date-first" && (
              <div>
                <div style={{ display: "flex", alignItems: "center", marginBottom: "24px" }}>
                  <button 
                    onClick={resetFlow}
                    style={{ 
                      background: "none", 
                      border: "none", 
                      color: "var(--teal)", 
                      cursor: "pointer",
                      marginRight: "16px"
                    }}
                  >
                    ← Change Booking Method
                  </button>
                  <h3 style={{ margin: "0" }}>Step 1: Choose Your Preferred Date</h3>
                </div>

                <div style={{ marginBottom: "24px" }}>
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => {
                      setSelectedDate(e.target.value);
                      setSelectedSlot("");
                    }}
                    min={getMinDate()}
                    max={getMaxDate()}
                    style={{
                      width: "100%",
                      padding: "12px",
                      borderRadius: "8px",
                      border: "1px solid #e0e0e0",
                      fontSize: "16px",
                      boxSizing: "border-box"
                    }}
                  />
                </div>

                {selectedDate && (
                  <div>
                    <h3>Available Counselors for {formatDate(selectedDate)}</h3>
                    {loading ? (
                      <p>Loading available counselors...</p>
                    ) : availableCounselors.length === 0 ? (
                      <div style={{
                        padding: "20px",
                        backgroundColor: "#fff3cd",
                        borderRadius: "8px",
                        border: "1px solid #ffc107"
                      }}>
                        <p style={{ color: "#856404", margin: "0 0 12px 0", fontWeight: "600" }}>
                          No counselors available on this date
                        </p>
                        <p style={{ color: "#666", fontSize: "14px", margin: "0" }}>
                          All slots may be booked. Please try another date.
                        </p>
                      </div>
                    ) : (
                      <>
                        <div style={{ display: "grid", gap: "16px", marginBottom: "20px" }}>
                          {availableCounselors.map(({ counselor, slots }) => {
                            if (!counselor) return null;
                            
                            return (
                              <div
                                key={counselor.id}
                                style={{
                                  border: "1px solid #e0e0e0",
                                  borderRadius: "8px",
                                  padding: "20px",
                                  backgroundColor: "#f8f9fa"
                                }}
                              >
                                <h4 style={{ margin: "0 0 16px 0" }}>
                                  {counselor.name || counselor.email || "Unknown Counselor"}
                                </h4>
                                <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
                                  {slots && slots.map((slot) => renderSlotButton(slot))}
                                </div>
                              </div>
                            );
                          }).filter(Boolean)}
                        </div>

                        {/* ✅ Legend */}
                        <div style={{
                          marginTop: "16px",
                          padding: "12px",
                          backgroundColor: "#f8f9fa",
                          borderRadius: "8px",
                          fontSize: "13px",
                          border: "1px solid #e0e0e0"
                        }}>
                          <strong style={{ marginBottom: "8px", display: "block" }}>Legend:</strong>
                          <div style={{ display: "flex", gap: "16px", flexWrap: "wrap" }}>
                            <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                              <div style={{
                                width: "16px",
                                height: "16px",
                                backgroundColor: "white",
                                border: "1px solid #ccc",
                                borderRadius: "4px"
                              }}></div>
                              <span>Available</span>
                            </div>
                            <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                              <div style={{
                                width: "16px",
                                height: "16px",
                                backgroundColor: "var(--teal)",
                                borderRadius: "4px"
                              }}></div>
                              <span>Selected</span>
                            </div>
                            <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                              <div style={{
                                width: "16px",
                                height: "16px",
                                backgroundColor: "#ffebee",
                                border: "1px solid #ffcdd2",
                                borderRadius: "4px",
                                opacity: 0.6
                              }}></div>
                              <span>Already Booked</span>
                            </div>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                )}
              </div>
            )}

            {bookingFlow === "counselor-first" && (
              <div>
                <div style={{ display: "flex", alignItems: "center", marginBottom: "24px" }}>
                  <button 
                    onClick={resetFlow}
                    style={{ 
                      background: "none", 
                      border: "none", 
                      color: "var(--teal)", 
                      cursor: "pointer",
                      marginRight: "16px"
                    }}
                  >
                    ← Change Booking Method
                  </button>
                  <h3 style={{ margin: "0" }}>Step 1: Choose Your Preferred Counselor</h3>
                </div>

                <div style={{ marginBottom: "24px" }}>
                  <select
                    value={selectedCounselor}
                    onChange={(e) => {
                      setSelectedCounselor(e.target.value);
                      setSelectedSlot("");
                    }}
                    style={{
                      width: "100%",
                      padding: "12px",
                      borderRadius: "8px",
                      border: "1px solid #e0e0e0",
                      fontSize: "16px"
                    }}
                  >
                    <option value="">Choose a counselor...</option>
                    {counselors.map((counselor) => (
                      <option key={counselor.id} value={counselor.id}>
                        {counselor.name || counselor.email}
                      </option>
                    ))}
                  </select>
                  {counselors.length === 0 && (
                    <p style={{ color: "#d32f2f", fontSize: "14px", marginTop: "8px", fontWeight: "600" }}>
                      ⚠️ No counselors found.
                    </p>
                  )}
                </div>

                {selectedCounselor && (
                  <div>
                    <h3>Available Times</h3>
                    {loading ? (
                      <p>Loading available times...</p>
                    ) : Object.keys(availableSlots).length === 0 ? (
                      <div style={{
                        padding: "20px",
                        backgroundColor: "#fff3cd",
                        borderRadius: "8px",
                        border: "1px solid #ffc107"
                      }}>
                        <p style={{ color: "#856404", fontWeight: "600" }}>
                          This counselor has no available slots.
                        </p>
                      </div>
                    ) : (
                      <>
                        <div style={{ display: "grid", gap: "16px", marginBottom: "20px" }}>
                          {Object.entries(availableSlots).map(([date, slots]) => (
                            <div
                              key={date}
                              style={{
                                border: "1px solid #e0e0e0",
                                borderRadius: "8px",
                                padding: "20px",
                                backgroundColor: "#f8f9fa"
                              }}
                            >
                              <h4 style={{ margin: "0 0 16px 0" }}>
                                {formatDate(date)}
                              </h4>
                              <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
                                {slots.map((slot) => renderSlotButton(slot))}
                              </div>
                            </div>
                          ))}
                        </div>

                        {/* ✅ Legend */}
                        <div style={{
                          marginTop: "16px",
                          padding: "12px",
                          backgroundColor: "#f8f9fa",
                          borderRadius: "8px",
                          fontSize: "13px",
                          border: "1px solid #e0e0e0"
                        }}>
                          <strong style={{ marginBottom: "8px", display: "block" }}>Legend:</strong>
                          <div style={{ display: "flex", gap: "16px", flexWrap: "wrap" }}>
                            <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                              <div style={{
                                width: "16px",
                                height: "16px",
                                backgroundColor: "white",
                                border: "1px solid #ccc",
                                borderRadius: "4px"
                              }}></div>
                              <span>Available</span>
                            </div>
                            <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                              <div style={{
                                width: "16px",
                                height: "16px",
                                backgroundColor: "var(--teal)",
                                borderRadius: "4px"
                              }}></div>
                              <span>Selected</span>
                            </div>
                            <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                              <div style={{
                                width: "16px",
                                height: "16px",
                                backgroundColor: "#ffebee",
                                border: "1px solid #ffcdd2",
                                borderRadius: "4px",
                                opacity: 0.6
                              }}></div>
                              <span>Already Booked</span>
                            </div>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                )}
              </div>
            )}

            {error && (
              <div style={{ 
                color: "#721c24", 
                backgroundColor: "#f8d7da", 
                padding: "16px", 
                borderRadius: "8px", 
                marginTop: "20px",
                border: "1px solid #f5c6cb"
              }}>
                <strong>Error:</strong> {error}
              </div>
            )}

            {selectedSlot && (
              <div style={{ marginTop: "32px", textAlign: "center" }}>
                <button
                  onClick={handleSubmit}
                  disabled={loading}
                  style={{
                    padding: "16px 32px",
                    backgroundColor: loading ? "#ccc" : "var(--teal)",
                    color: "white",
                    border: "none",
                    borderRadius: "8px",
                    fontSize: "16px",
                    fontWeight: "600",
                    cursor: loading ? "not-allowed" : "pointer"
                  }}
                >
                  {loading ? "Booking..." : "Book Consultation"}
                </button>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}