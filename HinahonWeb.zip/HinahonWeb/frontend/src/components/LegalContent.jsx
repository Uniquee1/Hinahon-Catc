// src/components/LegalContent.js
import React from 'react';

export const TermsAndConditions = () => (
  <div className="footer-modal-body">
    <h3>1. Acceptance of Terms</h3>
    <p>
      By accessing and using the Hinahon mental health consultation platform, you accept and agree to be bound by the terms and provisions of this agreement. If you do not agree to these terms, please do not use our services.
    </p>

    <h3>2. Description of Services</h3>
    <p>
      Hinahon provides an online platform connecting students with licensed mental health counselors. Our services include:
    </p>
    <ul>
      <li>Video consultation scheduling and booking</li>
      <li>Access to mental health articles and resources</li>
      <li>Secure communication between students and counselors</li>
      <li>Confidential mental health support services</li>
    </ul>

    <h3>3. User Responsibilities</h3>
    <p>As a user of Hinahon, you agree to:</p>
    <ul>
      <li>Provide accurate and complete information during registration</li>
      <li>Maintain the confidentiality of your account credentials</li>
      <li>Notify us immediately of any unauthorized access to your account</li>
      <li>Use the platform in compliance with all applicable laws</li>
      <li>Respect the professional boundaries with counselors</li>
      <li>Attend scheduled consultations or cancel with appropriate notice</li>
    </ul>

    <h3>4. Emergency Situations</h3>
    <div className="footer-warning-box">
      <strong>⚠️ Important:</strong> Our platform is NOT designed for emergency mental health crises. If you are experiencing a mental health emergency, please contact your local emergency services (911 in the Philippines) or visit the nearest emergency room immediately.
    </div>

    <h3>5. Confidentiality and Privacy</h3>
    <p>
      We take your privacy seriously. All consultations and personal information are kept confidential in accordance with professional ethics and applicable privacy laws. Please refer to our Privacy Policy for detailed information.
    </p>

    <h3>6. Booking and Cancellation Policy</h3>
    <ul>
      <li>Bookings are confirmed upon counselor acceptance</li>
      <li>Cancellations should be made at least 24 hours in advance when possible</li>
      <li>Repeated no-shows may result in booking restrictions</li>
      <li>Counselors reserve the right to decline consultation requests</li>
    </ul>

    <h3>7. Limitation of Liability</h3>
    <p>
      While we strive to provide quality mental health services, Hinahon and its counselors are not liable for any outcomes resulting from the use of our platform. Our services are provided "as is" without warranties of any kind.
    </p>

    <h3>8. Modifications to Terms</h3>
    <p>
      We reserve the right to modify these terms at any time. Users will be notified of significant changes, and continued use of the platform constitutes acceptance of modified terms.
    </p>

    <h3>9. Contact Information</h3>
    <p>
      For questions about these Terms & Conditions, please contact us at support@hinahon.ph
    </p>
  </div>
);

export const PrivacyPolicy = () => (
  <div className="footer-modal-body">
    <p className="footer-last-updated">
      Last Updated: {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
    </p>

    <h3>1. Introduction</h3>
    <p>
      Hinahon ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our mental health consultation platform.
    </p>

    <h3>2. Information We Collect</h3>
    <p>We collect the following types of information:</p>
    <ul>
      <li><strong>Personal Information:</strong> Name, email address, student ID, birthday, department, program, and year level</li>
      <li><strong>Account Information:</strong> Login credentials and authentication data</li>
      <li><strong>Consultation Data:</strong> Booking details, session notes, emotional state selections, and communication with counselors</li>
      <li><strong>Technical Data:</strong> IP address, browser type, device information, and usage patterns</li>
    </ul>

    <h3>3. How We Use Your Information</h3>
    <p>We use your information to:</p>
    <ul>
      <li>Provide and maintain our mental health consultation services</li>
      <li>Connect you with appropriate counselors</li>
      <li>Send booking confirmations and notifications</li>
      <li>Improve our platform and user experience</li>
      <li>Ensure platform security and prevent fraud</li>
      <li>Comply with legal obligations</li>
      <li>Provide customer support</li>
    </ul>

    <h3>4. Information Sharing and Disclosure</h3>
    <p>We do NOT sell your personal information. We may share your information only in the following circumstances:</p>
    <ul>
      <li><strong>With Counselors:</strong> Your basic information and consultation details are shared with assigned counselors</li>
      <li><strong>With Your Consent:</strong> When you explicitly authorize us to share information</li>
      <li><strong>Legal Requirements:</strong> When required by law or to protect rights and safety</li>
      <li><strong>Service Providers:</strong> With trusted third-party services that help us operate our platform</li>
    </ul>

    <h3>5. Data Security</h3>
    <p>We implement appropriate technical and organizational security measures to protect your information, including:</p>
    <ul>
      <li>Encrypted data transmission (SSL/TLS)</li>
      <li>Secure database storage with access controls</li>
      <li>Regular security audits and updates</li>
      <li>Authentication and authorization protocols</li>
      <li>Confidentiality agreements with staff and counselors</li>
    </ul>

    <h3>6. Your Rights and Choices</h3>
    <p>You have the right to:</p>
    <ul>
      <li>Access and review your personal information</li>
      <li>Update or correct your information through your profile</li>
      <li>Request deletion of your account and associated data</li>
      <li>Opt-out of non-essential communications</li>
      <li>Request a copy of your data</li>
    </ul>

    <h3>7. Data Retention</h3>
    <p>
      We retain your information for as long as necessary to provide our services and comply with legal obligations. Consultation records may be retained longer for professional and legal requirements.
    </p>

    <h3>8. Children's Privacy</h3>
    <p>
      Our services are intended for users aged 13 and above. We do not knowingly collect information from children under 13. If we become aware of such collection, we will promptly delete the information.
    </p>

    <h3>9. Changes to Privacy Policy</h3>
    <p>
      We may update this Privacy Policy periodically. We will notify users of significant changes via email or platform notification. Your continued use after changes constitutes acceptance.
    </p>

    <h3>10. Contact Us</h3>
    <p>
      For privacy-related questions or to exercise your rights, please contact us at privacy@hinahon.ph or call 0919-587-1553
    </p>
  </div>
);

export const ContactInfo = ({ logomark }) => (
  <div className="footer-contact-body" style={{
    padding: '0 0 24px 0',
    maxWidth: '100%'
  }}>
    <div style={{
      textAlign: 'center',
      marginBottom: '24px'
    }}>
      <img
        src={logomark}
        alt="Hinahon Logo"
        style={{
          height: "auto",
          width: "150px",
          maxWidth: '80%',
          objectFit: "contain",
          display: "inline-block",
          verticalAlign: "middle",
        }}
      />
    </div>

    <h2 className="footer-contact-title" style={{
      fontSize: "clamp(24px, 5vw, 35px)",
      textAlign: 'center',
      marginBottom: '12px',
      lineHeight: '1.3'
    }}>
      Get in Touch With Us!
    </h2>

    <p className="footer-contact-subtitle" style={{
      textAlign: 'center',
      marginBottom: '24px',
      fontSize: 'clamp(13px, 2.5vw, 15px)',
      lineHeight: '1.5',
      color: '#666'
    }}>
      We're here to help! Reach out to us through any of the following channels:
    </p>

    <div className="footer-contact-methods" style={{
      display: 'flex',
      flexDirection: 'column',
      gap: '16px',
      marginBottom: '20px'
    }}>
      <div className="footer-contact-item" style={{
        display: 'flex',
        alignItems: 'flex-start',
        gap: '12px',
        padding: '12px',
        backgroundColor: '#f8f9fa',
        borderRadius: '8px',
        transition: 'all 0.2s'
      }}>
        <span className="footer-contact-emoji" style={{
          fontSize: 'clamp(20px, 4vw, 24px)',
          flexShrink: 0,
          width: '32px',
          textAlign: 'center'
        }}>
          📧
        </span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="footer-contact-label" style={{
            fontSize: 'clamp(10px, 2vw, 11px)',
            fontWeight: '700',
            color: '#999',
            letterSpacing: '0.5px',
            marginBottom: '4px'
          }}>
            EMAIL
          </div>
          <a 
            href="mailto:support@hinahon.ph"
            className="footer-contact-link"
            style={{
              color: 'var(--pink)',
              textDecoration: 'none',
              fontSize: 'clamp(13px, 2.5vw, 15px)',
              fontWeight: '500',
              wordBreak: 'break-all',
              display: 'block'
            }}
          >
            support@hinahon.ph
          </a>
        </div>
      </div>

      <div className="footer-contact-item" style={{
        display: 'flex',
        alignItems: 'flex-start',
        gap: '12px',
        padding: '12px',
        backgroundColor: '#f8f9fa',
        borderRadius: '8px',
        transition: 'all 0.2s'
      }}>
        <span className="footer-contact-emoji" style={{
          fontSize: 'clamp(20px, 4vw, 24px)',
          flexShrink: 0,
          width: '32px',
          textAlign: 'center'
        }}>
          📲
        </span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="footer-contact-label" style={{
            fontSize: 'clamp(10px, 2vw, 11px)',
            fontWeight: '700',
            color: '#999',
            letterSpacing: '0.5px',
            marginBottom: '4px'
          }}>
            CRISIS HOTLINE
          </div>
          <a 
            href="tel:09195871553"
            className="footer-contact-link"
            style={{
              color: 'var(--pink)',
              textDecoration: 'none',
              fontSize: 'clamp(13px, 2.5vw, 15px)',
              fontWeight: '500',
              display: 'block'
            }}
          >
            0919-587-1553
          </a>
        </div>
      </div>

      <div className="footer-contact-item" style={{
        display: 'flex',
        alignItems: 'flex-start',
        gap: '12px',
        padding: '12px',
        backgroundColor: '#f8f9fa',
        borderRadius: '8px',
        transition: 'all 0.2s'
      }}>
        <span className="footer-contact-emoji" style={{
          fontSize: 'clamp(20px, 4vw, 24px)',
          flexShrink: 0,
          width: '32px',
          textAlign: 'center'
        }}>
          🌐
        </span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="footer-contact-label" style={{
            fontSize: 'clamp(10px, 2vw, 11px)',
            fontWeight: '700',
            color: '#999',
            letterSpacing: '0.5px',
            marginBottom: '4px'
          }}>
            WEBSITE
          </div>
          <a 
            href="https://lpubatangas.edu.ph/counseling-and-testing-center/"
            target="_blank"
            rel="noopener noreferrer"
            className="footer-contact-link"
            style={{
              color: 'var(--pink)',
              textDecoration: 'none',
              fontSize: 'clamp(13px, 2.5vw, 15px)',
              fontWeight: '500',
              wordBreak: 'break-word',
              display: 'block',
              overflow: 'hidden',
              textOverflow: 'ellipsis'
            }}
          >
            LPU Counseling Center
          </a>
        </div>
      </div>

      <div className="footer-contact-item" style={{
        display: 'flex',
        alignItems: 'flex-start',
        gap: '12px',
        padding: '12px',
        backgroundColor: '#f8f9fa',
        borderRadius: '8px',
        transition: 'all 0.2s'
      }}>
        <span className="footer-contact-emoji" style={{
          fontSize: 'clamp(20px, 4vw, 24px)',
          flexShrink: 0,
          width: '32px',
          textAlign: 'center'
        }}>
          👩🏻‍⚕️
        </span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="footer-contact-label" style={{
            fontSize: 'clamp(10px, 2vw, 11px)',
            fontWeight: '700',
            color: '#999',
            letterSpacing: '0.5px',
            marginBottom: '4px'
          }}>
            FACEBOOK
          </div>
          <a 
            href="https://www.facebook.com/LPUCATC"
            target="_blank"
            rel="noopener noreferrer"
            className="footer-contact-link"
            style={{
              color: 'var(--pink)',
              textDecoration: 'none',
              fontSize: 'clamp(13px, 2.5vw, 15px)',
              fontWeight: '500',
              display: 'block'
            }}
          >
            @LPUCATC
          </a>
        </div>
      </div>
    </div>

    <div className="footer-contact-note" style={{
      backgroundColor: '#fff3e0',
      padding: '16px',
      borderRadius: '8px',
      borderLeft: '4px solid #ff9800',
      fontSize: 'clamp(12px, 2.5vw, 14px)',
      lineHeight: '1.6',
      marginBottom: '16px'
    }}>
      <strong style={{ 
        display: 'block', 
        marginBottom: '8px',
        color: '#e65100',
        fontSize: 'clamp(13px, 2.5vw, 15px)'
      }}>
        💡 Need immediate help?
      </strong>
      <p style={{ 
        margin: 0, 
        color: '#666' 
      }}>
        If you're experiencing a mental health emergency, please call 911 or visit your nearest emergency room.
      </p>
    </div>

    <style>{`
      .footer-contact-item:hover {
        background-color: #f0f0f0 !important;
        transform: translateX(4px);
      }

      .footer-contact-link:hover {
        text-decoration: underline !important;
        color: var(--teal) !important;
      }

      @media (max-width: 480px) {
        .footer-contact-item {
          padding: 10px !important;
          gap: 10px !important;
        }
        
        .footer-contact-emoji {
          width: 28px !important;
        }
      }
    `}</style>
  </div>
);