import { useState } from 'react';
import { supabase } from '../supabaseClient';
import './FeedbackModal.css';

const API_URL = import.meta.env.VITE_API_URL;

const FeedbackModal = ({ isOpen, onClose }) => {
    const [rating, setRating] = useState(0);
    const [hoveredRating, setHoveredRating] = useState(0);
    const [feedbackText, setFeedbackText] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        if (rating === 0) {
            alert('Please select a rating');
            return;
        }

        if (feedbackText.trim().length === 0) {
            alert('Please provide your feedback');
            return;
        }

        setIsSubmitting(true);

        try {
            // Get the current session token from Supabase
            const { data: { session } } = await supabase.auth.getSession();
            
            if (!session) {
                alert('You must be logged in to submit feedback');
                setIsSubmitting(false);
                return;
            }

            // Send request to your backend API
            const response = await fetch(`${API_URL}/api/feedback/submit`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${session.access_token}`
                },
                body: JSON.stringify({
                    rating,
                    feedback_text: feedbackText
                })
            });

            const data = await response.json();

            if (data.success) {
                alert('Thank you for your feedback!');
                handleClose();
            } else {
                alert(data.error || 'Failed to submit feedback');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('An error occurred while submitting feedback');
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleClose = () => {
        setRating(0);
        setHoveredRating(0);
        setFeedbackText('');
        onClose();
    };

    if (!isOpen) return null;

    return (
        <div className="feedback-modal-overlay" onClick={handleClose}>
            <div className="feedback-modal-content" onClick={(e) => e.stopPropagation()}>
                <button className="feedback-close-btn" onClick={handleClose}>
                    &times;
                </button>
                
                <h2>Share Your Feedback</h2>
                <p className="feedback-modal-subtitle">Help us improve your experience</p>

                <form onSubmit={handleSubmit}>
                    <div className="feedback-star-rating">
                        {[1, 2, 3, 4, 5].map((star) => (
                            <span
                                key={star}
                                className={`feedback-star ${star <= (hoveredRating || rating) ? 'active' : ''}`}
                                onClick={() => setRating(star)}
                                onMouseEnter={() => setHoveredRating(star)}
                                onMouseLeave={() => setHoveredRating(0)}
                            >
                                ★
                            </span>
                        ))}
                    </div>

                    <textarea
                        value={feedbackText}
                        onChange={(e) => setFeedbackText(e.target.value)}
                        placeholder="Tell us about your experience with the system..."
                        rows="5"
                        required
                        className="feedback-textarea"
                    />

                    <button 
                        type="submit" 
                        className="feedback-submit-btn"
                        disabled={isSubmitting}
                    >
                        {isSubmitting ? 'Submitting...' : 'Submit Feedback'}
                    </button>
                </form>
            </div>
        </div>
    );
};
export default FeedbackModal;
