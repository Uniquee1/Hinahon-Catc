// backend/routes/feedback.js
const express = require('express');
const { createClient } = require('@supabase/supabase-js');
const { authenticateUser } = require('../middleware/auth');

const router = express.Router();

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

/**
 * POST /api/feedback/submit
 * Submit feedback (Student only)
 */
router.post('/submit', authenticateUser, async (req, res) => {
    try {
        const { rating, feedback_text } = req.body;
        const student_id = req.user.id;

        // Validate input
        if (!rating || rating < 1 || rating > 5) {
            return res.status(400).json({ 
                success: false, 
                error: 'Rating must be between 1 and 5' 
            });
        }

        if (!feedback_text || feedback_text.trim().length === 0) {
            return res.status(400).json({ 
                success: false, 
                error: 'Feedback text is required' 
            });
        }

        // Get student information
        const { data: student, error: studentError } = await supabase
            .from('users')
            .select('name, email')
            .eq('id', student_id)
            .single();

        if (studentError) {
            throw studentError;
        }

        const student_name = student.name || student.email;

        // Insert feedback
        const { data, error } = await supabase
            .from('feedbacks')
            .insert([{
                student_id,
                student_name,
                rating: parseInt(rating),
                feedback_text: feedback_text.trim()
            }])
            .select()
            .single();

        if (error) throw error;

        console.log('✅ Feedback submitted by:', student_name);

        res.json({ 
            success: true, 
            message: 'Feedback submitted successfully',
            data 
        });
    } catch (error) {
        console.error('❌ Error submitting feedback:', error);
        res.status(500).json({ 
            success: false, 
            error: error.message || 'Failed to submit feedback'
        });
    }
});

/**
 * GET /api/feedback/all
 * Get all feedbacks (Admin and Counselor only)
 */
router.get('/all', authenticateUser, async (req, res) => {
    try {
        // Check if user is admin or counselor
        const { data: user, error: userError } = await supabase
            .from('users')
            .select('role')
            .eq('id', req.user.id)
            .single();

        if (userError) throw userError;

        if (user.role !== 'admin' && user.role !== 'counselor') {
            return res.status(403).json({ 
                success: false,
                error: 'Access denied. Only admins and counselors can view all feedback.' 
            });
        }

        // Get all feedbacks
        const { data, error } = await supabase
            .from('feedbacks')
            .select('*')
            .order('created_at', { ascending: false });

        if (error) throw error;

        // Calculate statistics
        const stats = {
            total: data.length,
            averageRating: data.length > 0 
                ? (data.reduce((sum, f) => sum + f.rating, 0) / data.length).toFixed(1)
                : 0,
            ratingDistribution: {
                5: data.filter(f => f.rating === 5).length,
                4: data.filter(f => f.rating === 4).length,
                3: data.filter(f => f.rating === 3).length,
                2: data.filter(f => f.rating === 2).length,
                1: data.filter(f => f.rating === 1).length,
            }
        };

        console.log(`✅ Fetched ${data.length} feedbacks for ${user.role}`);

        res.json({ 
            success: true, 
            data,
            stats
        });
    } catch (error) {
        console.error('❌ Error fetching feedbacks:', error);
        res.status(500).json({ 
            success: false, 
            error: error.message || 'Failed to fetch feedbacks'
        });
    }
});

/**
 * GET /api/feedback/my-feedbacks
 * Get student's own feedbacks
 */
router.get('/my-feedbacks', authenticateUser, async (req, res) => {
    try {
        const student_id = req.user.id;

        const { data, error } = await supabase
            .from('feedbacks')
            .select('*')
            .eq('student_id', student_id)
            .order('created_at', { ascending: false });

        if (error) throw error;

        console.log(`✅ Fetched ${data.length} feedbacks for student:`, student_id);

        res.json({ 
            success: true, 
            data 
        });
    } catch (error) {
        console.error('❌ Error fetching student feedbacks:', error);
        res.status(500).json({ 
            success: false, 
            error: error.message || 'Failed to fetch feedbacks'
        });
    }
});

module.exports = router;