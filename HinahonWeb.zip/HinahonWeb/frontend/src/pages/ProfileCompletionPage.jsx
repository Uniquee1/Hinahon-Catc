import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "../supabaseClient";
import "../styles3.css";
import logo from "../assets/hinahon3.png";
import logomark from "../assets/hinahon2.png";
import {PrivacyPolicy, ContactInfo } from '../components/LegalContent';

export default function ProfileCompletionPage({ user, onComplete }) {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showHelpModal, setShowHelpModal] = useState(false);
    const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  

  const [formData, setFormData] = useState({
    name: "",
    student_id: "",
    birthday: "",
    department: "",
    program: "",
    year_level: ""
  });

  const departments = [
    { value: "CCAS", label: "CCAS - College of Computing, Arts and Sciences" },
    { value: "DENT", label: "DENT - College of Dentistry" },
    { value: "CON", label: "CON - College of Nursing" },
    { value: "CITHM", label: "CITHM - College of International Tourism and Hospitality Management" },
    { value: "CBA", label: "CBA - College of Business Administration" },
    { value: "LIMA", label: "LIMA - Lyceum International Maritime Academy" },
    { value: "CAMP", label: "CAMP - College of Allied Medical Professions" },
    { value: "CCJE", label: "CCJE - College of Criminal Justice Education" },
    { value: "SHS", label: "SHS - Senior High School" }
  ];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    setError("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!formData.name || !formData.student_id || !formData.birthday ||
        !formData.department || !formData.program || !formData.year_level) {
      setError("Please fill in all required fields");
      return;
    }

    if (!/^\d{8}$/.test(formData.student_id)) {
      setError("Student ID must be exactly 8 digits");
      return;
    }

    const birthDate = new Date(formData.birthday);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }

    if (age < 13) {
      setError("You must be at least 13 years old to use this service");
      return;
    }

    setLoading(true);

    try {
      const { error: updateError } = await supabase
        .from("users")
        .update({
          name: formData.name,
          student_id: formData.student_id,
          birthday: formData.birthday,
          department: formData.department,
          program: formData.program,
          year_level: parseInt(formData.year_level),
          profile_completed: true
        })
        .eq("id", user.id);

      if (updateError) throw updateError;

      if (onComplete) {
        await onComplete();
      }

      navigate("/landing");
    } catch (err) {
      console.error("Error updating profile:", err);
      setError(err.message || "Failed to update profile");
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    if (window.confirm("Are you sure you want to log out? Your profile information won't be saved.")) {
      try {
        await supabase.auth.signOut();
        navigate("/");
      } catch (err) {
        console.error("Error signing out:", err);
        navigate("/");
      }
    }
  };

  const handleSkipForNow = () => {
    if (window.confirm("Skip profile completion? You can complete it later, but some features may be limited.")) {
      handleSignOut();
    }
  };

  const Modal = ({ isOpen, onClose, title, children }) => {
    if (!isOpen) return null;

    return (
      <div
        className="footer-modal-overlay"
        onClick={onClose}
        style={{
          position: "fixed",
          inset: 0,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          zIndex: 2000,
          backgroundColor: "rgba(0,0,0,0.5)",
          // ensure overlay itself never scrolls (prevents outer scrollbar)
          overflow: "hidden"
        }}
      >
        <div
          className="footer-modal-container"
          onClick={(e) => e.stopPropagation()}
          style={{
            background: "white",
            borderRadius: 12,
            maxWidth: 820,
            width: "92%",
            // keep the modal inside the viewport and let the content area scroll
            maxHeight: "calc(100dvh - 40px)",
            boxSizing: "border-box",
            display: "flex",
            flexDirection: "column",
            overflow: "hidden",
            WebkitOverflowScrolling: "touch",
            boxShadow: "0 8px 30px rgba(0,0,0,0.2)",
          }}
        >
          <div className="footer-modal-header" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: 20 }}>
            <h2 style={{ margin: 0 }}>{title}</h2>
            <button
              className="footer-modal-close"
              onClick={onClose}
              aria-label="Close modal"
              style={{ fontSize: 22, background: "none", border: "none", cursor: "pointer" }}
            >
              ×
            </button>
          </div>

          {/* Content area: this is the single scrollable region */}
          <div className="footer-modal-content" style={{ marginTop: 0, padding: 20, overflowY: "auto", flex: 1 }}>
            {children}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="auth-page-profile">
      <div className="signout-container">
        <button className="signout-btn" onClick={handleSignOut} aria-label="log out">← log Out</button>
      </div>

      <div className="auth-hero-profile" aria-hidden={false}>
        <div className="hero-inner-profile">
          <img src={logo} alt="Hinahon logo" className="hero-logo" />

          <div className="hero-content-profile">
            <div className="nav-slim-profile">
              <span className="nav-title">Tell Us More About Yourself</span>
            </div>

            <h1 className="brand-big-profile">Welcome!</h1>

            <p className="hero-sub-profile">
              Let's set up your profile so we can provide you with personalized mental health support.
            </p>

            <p className="hero-sub-profile signed-as">
              Signed in as: &nbsp;<strong className="usersign">{user?.email}</strong>
            </p>
          </div>
        </div>
      </div>

      <div className="auth-card-profile" role="region" aria-label="Profile completion card">
        <div className="card-header-profile">
          <div className="logo-small-profile">Complete Your Profile</div>
          <div className="small-tag-profile">Tell us a bit about yourself</div>
        </div>

        {error && (
          <div className="error-box">{error}</div>
        )}

        <form onSubmit={handleSubmit} className="login-form-profile" noValidate>
          <div className="field">
            <label className="field-label">Full Name *</label>
            <input type="text" name="name" value={formData.name} onChange={handleChange} placeholder="Juan Dela Cruz" disabled={loading} required />
          </div>

          <div className="field">
            <label className="field-label">Student ID *</label>
            <input type="text" name="student_id" value={formData.student_id} onChange={handleChange} placeholder="12345678" disabled={loading} required maxLength="8" />
            <small className="field-note">8-digit student ID number</small>
          </div>

          <div className="field">
            <label className="field-label">Birthday *</label>
            <input type="date" name="birthday" value={formData.birthday} onChange={handleChange} disabled={loading} required max={new Date().toISOString().split('T')[0]} />
          </div>

          <div className="field">
            <label className="field-label">Department *</label>
            <select name="department" value={formData.department} onChange={handleChange} disabled={loading} required className="select-field">
              <option value="">Select your department</option>
              {departments.map(dept => (
                <option key={dept.value} value={dept.value}>{dept.label}</option>
              ))}
            </select>
          </div>

          <div className="field">
            <label className="field-label">Program *</label>
            <input type="text" name="program" value={formData.program} onChange={handleChange} placeholder="e.g., BSIT" disabled={loading} required />
            <small className="field-note">Your course or program of study</small>
          </div>

          <div className="field small-field-row">
            <label className="field-label">Year Level *</label>
            <select name="year_level" value={formData.year_level} onChange={handleChange} disabled={loading} required className="select-field">
              <option value="">Select your year level</option>
              <option value="1">1st Year</option>
              <option value="2">2nd Year</option>
              <option value="3">3rd Year</option>
              <option value="4">4th Year</option>
              <option value="5">5th Year</option>
              <option value="6">Graduate Level</option>
            </select>
          </div>

          <button type="submit" className="btn-primary-profile" disabled={loading} aria-disabled={loading}>{loading ? "Saving..." : "Finish Account Setup"}</button>
        </form>

        <div className="later-row">
          <button onClick={handleSkipForNow} disabled={loading} className="link-later">I'll complete this later</button>
        </div>

        <div className="card-footer-profile">
          <a className="link-muted-profile" href="#" onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            if (!loading) setShowPrivacyModal(true);
                          }}>Privacy</a>
          <a className="link-muted-profile" href="#" onClick={(e) => {
                      e.preventDefault();
                      setShowHelpModal(true);
                    }}>Help</a>
        </div>
      </div>
      
      <Modal
        isOpen={showHelpModal}
        onClose={() => setShowHelpModal(false)}
        title="Contact Us"
      >
        <ContactInfo logomark={logomark} />
      </Modal>

      <Modal
        isOpen={showPrivacyModal}
        onClose={() => setShowPrivacyModal(false)}
        title="Privacy Policy"
      >
        <PrivacyPolicy />
      </Modal>
    </div>
  );
}



