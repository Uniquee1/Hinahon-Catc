import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { supabase } from "../supabaseClient";
import { filterExpiredSlots, isSlotExpired } from "../utils/availabilityUtils";
import "../styles.css";

export default function BookingPage({ session }) {
  const navigate = useNavigate();
  const location = useLocation();
  
  const emotion = location.state?.emotion || 'general';
  
  const [bookingFlow, setBookingFlow] = useState("");
  const [counselors, setCounselors] = useState([]);
  const [selectedCounselor, setSelectedCounselor] = useState("");
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedSlot, setSelectedSlot] = useState("");
  const [availableSlots, setAvailableSlots] = useState([]);
  const [availableCounselors, setAvailableCounselors] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const isGuest = session?.isGuest;
  const user = session?.user;

  const emotionDisplay = {
    happy: { label: "Happy", icon: "🙂" },
    sad: { label: "Sad", icon: "😢" },
    angry: { label: "Angry", icon: "😡" },
    scared: { label: "Scared", icon: "😨" },
    worried: { label: "Worried", icon: "😟" },
    tired: { label: "Tired", icon: "😴" },
    disgusted: { label: "Disgusted", icon: "🤢" },
    overwhelmed: { label: "Overwhelmed", icon: "😵" },
    general: { label: "General Concern", icon: "💬" }
  };

  const currentEmotion = emotionDisplay[emotion] || emotionDisplay.general;

  useEffect(() => {
    console.log("BookingPage loaded with emotion:", emotion);
    fetchCounselors();
  }, []);

  useEffect(() => {
    if (bookingFlow === "date-first" && selectedDate) {
      fetchAvailableCounselorsForDate();
    }
  }, [selectedDate, bookingFlow]);

  useEffect(() => {
    if (bookingFlow === "counselor-first" && selectedCounselor) {
      fetchAvailableSlotsForCounselor();
    }
  }, [selectedCounselor, bookingFlow]);

  // Auto-refresh for date-first flow
  useEffect(() => {
    if (bookingFlow === "date-first" && selectedDate) {
      const interval = setInterval(() => {
        console.log("Auto-refreshing slots (date-first)...");
        fetchAvailableCounselorsForDate();
      }, 30000);
      
      return () => clearInterval(interval);
    }
  }, [bookingFlow, selectedDate]);

  // Auto-refresh for counselor-first flow
  useEffect(() => {
    if (bookingFlow === "counselor-first" && selectedCounselor) {
      const interval = setInterval(() => {
        console.log("Auto-refreshing slots (counselor-first)...");
        fetchAvailableSlotsForCounselor();
      }, 30000);
      
      return () => clearInterval(interval);
    }
  }, [bookingFlow, selectedCounselor]);

  const fetchCounselors = async () => {
    try {
      const { data, error } = await supabase
        .from("users")
        .select("id, name, email")
        .eq("role", "counselor");

      if (error) throw error;
      setCounselors(data || []);
    } catch (err) {
      console.error("Error fetching counselors:", err);
      setError("Failed to load counselors");
    }
  };

  const fetchAvailableCounselorsForDate = async () => {
    try {
      setLoading(true);
      setError("");
      console.log("=== FETCHING AVAILABLE COUNSELORS ===");
      console.log("Selected date:", selectedDate);
      
      const { data: availabilityData, error: availabilityError } = await supabase
        .from("availability")
        .select("id, start_time, end_time, counselor_id, is_booked, date")
        .eq("date", selectedDate)
        .eq("is_booked", false)
        .order("start_time");

      console.log("Available (unbooked) slots:", availabilityData);

      if (availabilityError) throw availabilityError;

      if (!availabilityData || availabilityData.length === 0) {
        setAvailableCounselors([]);
        setError(`No available time slots for ${selectedDate}. Please try another date.`);
        return;
      }

      // Filter out expired slots
      const activeSlots = filterExpiredSlots(availabilityData);
      console.log("Active (non-expired) slots:", activeSlots);

      if (activeSlots.length === 0) {
        setAvailableCounselors([]);
        setError(`All time slots for ${selectedDate} have already passed. Please select a different date.`);
        return;
      }

      const counselorIds = [...new Set(activeSlots.map(slot => slot.counselor_id))];
      console.log("Unique counselor IDs:", counselorIds);

      const { data: counselorData, error: counselorError } = await supabase
        .from("users")
        .select("id, name, email")
        .in("id", counselorIds)
        .eq("role", "counselor");

      if (counselorError) throw counselorError;

      const counselorWithSlots = counselorData.map(counselor => {
        const slots = activeSlots.filter(slot => slot.counselor_id === counselor.id);
        return { ...counselor, availableSlots: slots };
      });

      console.log("Counselors with active slots:", counselorWithSlots);
      setAvailableCounselors(counselorWithSlots);

    } catch (err) {
      console.error("Error fetching available counselors:", err);
      setError("Failed to load available counselors");
    } finally {
      setLoading(false);
    }
  };

  const fetchAvailableSlotsForCounselor = async () => {
    try {
      setLoading(true);
      setError("");

      const { data, error } = await supabase
        .from("availability")
        .select("*")
        .eq("counselor_id", selectedCounselor)
        .eq("is_booked", false)
        .gte("date", new Date().toISOString().split('T')[0])
        .order("date")
        .order("start_time");

      if (error) throw error;

      if (!data || data.length === 0) {
        setAvailableSlots({});
        setError("This counselor has no available slots at the moment. Please try another counselor.");
        return;
      }

      // Filter out expired slots
      const activeSlots = filterExpiredSlots(data);
      console.log("Active slots for counselor:", activeSlots);

      if (activeSlots.length === 0) {
        setAvailableSlots({});
        setError("This counselor has no available slots at the moment. Please try another counselor.");
        return;
      }

      const dateMap = {};
      activeSlots.forEach(slot => {
        const date = slot.date;
        if (!dateMap[date]) {
          dateMap[date] = [];
        }
        dateMap[date].push(slot);
      });

      setAvailableSlots(dateMap);
    } catch (err) {
      console.error("Error fetching available slots:", err);
      setError("Failed to load available slots");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (isGuest) {
      alert("Please sign in to book a consultation");
      navigate("/");
      return;
    }

    if (!selectedSlot) {
      setError("Please select a time slot");
      return;
    }

    setLoading(true);
    setError("");

    try {
      console.log("=== BOOKING PROCESS STARTED ===");
      console.log("Selected slot ID:", selectedSlot);
      console.log("Emotion for consultation:", emotion);

      const { data: slotCheck, error: checkError } = await supabase
        .from("availability")
        .select("id, date, start_time, end_time, counselor_id, is_booked")
        .eq("id", selectedSlot)
        .single();

      console.log("Slot check result:", slotCheck);

      if (checkError) {
        console.error("Error checking slot:", checkError);
        throw new Error("Failed to verify slot availability");
      }

      if (!slotCheck) {
        throw new Error("Slot not found");
      }

      // Check if slot has expired
      if (isSlotExpired(slotCheck.date, slotCheck.start_time)) {
        console.warn("⚠️ Slot has expired!");
        setError("Sorry, this time slot has already passed. Please select another time.");
        setSelectedSlot("");
        
        if (bookingFlow === "date-first") {
          await fetchAvailableCounselorsForDate();
        } else {
          await fetchAvailableSlotsForCounselor();
        }
        setLoading(false);
        return;
      }

      if (slotCheck.is_booked === true) {
        console.warn("⚠️ Slot is already booked!");
        setError("Sorry, this slot was just booked by someone else. Please select another time.");
        setSelectedSlot("");
        
        if (bookingFlow === "date-first") {
          await fetchAvailableCounselorsForDate();
        } else {
          await fetchAvailableSlotsForCounselor();
        }
        setLoading(false);
        return;
      }

      console.log("✅ Slot is available and not expired, proceeding with booking...");

      const { error: updateError } = await supabase
        .from("availability")
        .update({ is_booked: true })
        .eq("id", selectedSlot)
        .eq("is_booked", false);

      if (updateError) {
        console.error("Error marking slot as booked:", updateError);
        throw new Error("Failed to reserve time slot");
      }

      console.log("✅ Slot marked as booked");

      const { data: consultationData, error: consultationError } = await supabase
        .from("consultations")
        .insert({
          student_id: user.id,
          counselor_id: slotCheck.counselor_id,
          date: slotCheck.date,
          time: slotCheck.start_time,
          status: "pending",
          availability_id: selectedSlot,
          reason: emotion
        })
        .select()
        .single();

      if (consultationError) {
        console.error("Error creating consultation:", consultationError);
        
        await supabase
          .from("availability")
          .update({ is_booked: false })
          .eq("id", selectedSlot);
        
        throw new Error("Failed to create consultation");
      }

      console.log("✅ Consultation created with emotion:", consultationData);

      try {
        const response = await fetch(`${import.meta.env.VITE_BACKEND_URL}/api/bookings/notify`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session.access_token}`
          },
          body: JSON.stringify({
            consultationId: consultationData.id
          })
        });

        if (!response.ok) {
          console.warn('⚠️ Email notifications may have failed, but booking was successful');
        } else {
          console.log('✅ Email notifications sent successfully');
        }
      } catch (emailErr) {
        console.warn('⚠️ Email notification error (booking still successful):', emailErr);
      }

      alert(`✅ Consultation request submitted successfully!\n\nReason: ${currentEmotion.icon} ${currentEmotion.label}\n\nYou will receive an email notification once the counselor responds.`);
      navigate("/landing");

    } catch (err) {
      console.error("❌ Error booking consultation:", err);
      setError(`Failed to book consultation: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const resetFlow = () => {
    setBookingFlow("");
    setSelectedCounselor("");
    setSelectedDate("");
    setSelectedSlot("");
    setAvailableSlots([]);
    setAvailableCounselors([]);
    setError("");
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric"
    });
  };

  const formatTime = (timeString) => {
    return new Date(`2000-01-01T${timeString}`).toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true
    });
  };

  const getMinDate = () => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  };

  const getMaxDate = () => {
    const maxDate = new Date();
    maxDate.setDate(maxDate.getDate() + 90);
    return maxDate.toISOString().split('T')[0];
  };

  const renderSlotButton = (slot) => {
    const isBooked = slot.is_booked;
    const isSelected = selectedSlot === slot.id;
    const expired = isSlotExpired(slot.date, slot.start_time);
    
    // Don't render expired slots
    if (expired) {
      return null;
    }
    
    return (
      <button
        key={slot.id}
        onClick={() => !isBooked && setSelectedSlot(slot.id)}
        disabled={isBooked}
        style={{
          padding: "10px 16px",
          border: isSelected 
            ? "2px solid var(--teal)" 
            : isBooked 
              ? "1px solid #ffcdd2"
              : "1px solid #ccc",
          borderRadius: "6px",
          backgroundColor: isBooked 
            ? "#ffebee" 
            : (isSelected ? "var(--teal)" : "white"),
          color: isBooked 
            ? "#999" 
            : (isSelected ? "white" : "#333"),
          cursor: isBooked ? "not-allowed" : "pointer",
          fontSize: "14px",
          opacity: isBooked ? 0.6 : 1,
          position: "relative",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: "4px",
          transition: "all 0.2s ease",
          minWidth: "140px"
        }}
        title={isBooked ? "This slot is already booked by another student" : "Click to select this time"}
        onMouseEnter={(e) => {
          if (!isBooked) {
            e.currentTarget.style.transform = "translateY(-2px)";
            e.currentTarget.style.boxShadow = "0 4px 8px rgba(0,0,0,0.1)";
          }
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.transform = "translateY(0)";
          e.currentTarget.style.boxShadow = "none";
        }}
      >
        <span style={{ fontWeight: isSelected ? "600" : "500" }}>
          {formatTime(slot.start_time)} - {formatTime(slot.end_time)}
        </span>
        {isBooked && (
          <span style={{ 
            fontSize: "10px", 
            color: "#d32f2f",
            fontWeight: "600",
            textTransform: "uppercase"
          }}>
            ✕ Booked
          </span>
        )}
      </button>
    );
  };

  return (
    <div className="landing-root">
      <header className="landing-header">
        <div className="header-left">
          <div className="logo-top">Hinahon</div>
          <div className="tagline-mini">Book a Consultation</div>
        </div>
        <div className="header-right">
          <button 
            onClick={() => navigate("/landing")}
            style={{ 
              background: "none", 
              border: "none", 
              color: "#666", 
              cursor: "pointer",
              font: "inherit"
            }}
          >
            ← Back to Home
          </button>
        </div>
      </header>

      <main style={{ padding: "40px 24px", maxWidth: "900px", margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: "32px" }}>
          <h1 style={{ color: "var(--pink)", fontSize: "36px", margin: "0 0 12px 0" }}>
            Book Your Consultation
          </h1>
          <div style={{ 
            display: "inline-flex", 
            alignItems: "center", 
            gap: "12px",
            backgroundColor: "#f0f9ff",
            padding: "12px 24px",
            borderRadius: "12px",
            marginTop: "16px"
          }}>
            <span style={{ fontSize: "32px" }}>{currentEmotion.icon}</span>
            <div style={{ textAlign: "left" }}>
              <div style={{ fontSize: "12px", color: "#666", fontWeight: "600" }}>
                CONSULTATION REASON
              </div>
              <div style={{ fontSize: "18px", color: "#333", fontWeight: "700" }}>
                {currentEmotion.label}
              </div>
            </div>
          </div>
        </div>

        {isGuest ? (
          <div style={{ 
            textAlign: "center", 
            padding: "40px", 
            backgroundColor: "#f9f9f9", 
            borderRadius: "12px",
            margin: "20px 0"
          }}>
            <h3 style={{ color: "var(--pink)", marginBottom: "16px" }}>
              Sign In Required
            </h3>
            <p style={{ marginBottom: "20px", color: "#666" }}>
              You need to sign in to book a consultation with our counselors.
            </p>
            <button
              onClick={() => navigate("/")}
              style={{
                padding: "12px 32px",
                backgroundColor: "var(--teal)",
                color: "white",
                border: "none",
                borderRadius: "8px",
                fontSize: "16px",
                fontWeight: "600",
                cursor: "pointer"
              }}
            >
              Go to Login
            </button>
          </div>
        ) : !bookingFlow ? (
          <div style={{ textAlign: "center" }}>
            <h2 style={{ marginBottom: "24px", color: "#333" }}>
              How would you like to book?
            </h2>
            <div style={{ 
              display: "flex", 
              gap: "20px", 
              justifyContent: "center",
              flexWrap: "wrap"
            }}>
              <button
                onClick={() => setBookingFlow("date-first")}
                style={{
                  flex: "1 1 300px",
                  maxWidth: "400px",
                  padding: "30px",
                  backgroundColor: "white",
                  border: "2px solid #e0e0e0",
                  borderRadius: "12px",
                  cursor: "pointer",
                  transition: "all 0.3s"
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = "var(--teal)";
                  e.currentTarget.style.transform = "translateY(-4px)";
                  e.currentTarget.style.boxShadow = "0 8px 16px rgba(0,0,0,0.1)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = "#e0e0e0";
                  e.currentTarget.style.transform = "translateY(0)";
                  e.currentTarget.style.boxShadow = "none";
                }}
              >
                <div style={{ fontSize: "48px", marginBottom: "16px" }}>📅</div>
                <h3 style={{ margin: "0 0 12px 0", color: "var(--pink)" }}>
                  Choose Date First
                </h3>
                <p style={{ margin: 0, color: "#666", fontSize: "14px" }}>
                  Select your preferred date and see available counselors
                </p>
              </button>

              <button
                onClick={() => setBookingFlow("counselor-first")}
                style={{
                  flex: "1 1 300px",
                  maxWidth: "400px",
                  padding: "30px",
                  backgroundColor: "white",
                  border: "2px solid #e0e0e0",
                  borderRadius: "12px",
                  cursor: "pointer",
                  transition: "all 0.3s"
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = "var(--teal)";
                  e.currentTarget.style.transform = "translateY(-4px)";
                  e.currentTarget.style.boxShadow = "0 8px 16px rgba(0,0,0,0.1)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = "#e0e0e0";
                  e.currentTarget.style.transform = "translateY(0)";
                  e.currentTarget.style.boxShadow = "none";
                }}
              >
                <div style={{ fontSize: "48px", marginBottom: "16px" }}>👤</div>
                <h3 style={{ margin: "0 0 12px 0", color: "var(--pink)" }}>
                  Choose Counselor First
                </h3>
                <p style={{ margin: 0, color: "#666", fontSize: "14px" }}>
                  Select a specific counselor and see their availability
                </p>
              </button>
            </div>
          </div>
        ) : bookingFlow === "date-first" ? (
          <form onSubmit={handleSubmit}>
            <div style={{ marginBottom: "24px" }}>
              <button
                type="button"
                onClick={resetFlow}
                style={{
                  padding: "8px 16px",
                  backgroundColor: "#f5f5f5",
                  border: "1px solid #ddd",
                  borderRadius: "6px",
                  cursor: "pointer",
                  marginBottom: "20px"
                }}
              >
                ← Change Booking Method
              </button>

              <label style={{ display: "block", marginBottom: "8px", fontWeight: "600" }}>
                1. Select a Date
              </label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => {
                  setSelectedDate(e.target.value);
                  setSelectedCounselor("");
                  setSelectedSlot("");
                }}
                min={getMinDate()}
                max={getMaxDate()}
                style={{
                  width: "100%",
                  padding: "12px",
                  border: "1px solid #ccc",
                  borderRadius: "8px",
                  fontSize: "16px"
                }}
                required
              />
            </div>

            {loading && <p style={{ textAlign: "center", color: "#666" }}>Loading available counselors...</p>}
            
            {error && (
              <div style={{ 
                padding: "12px", 
                backgroundColor: "#ffebee", 
                color: "#c62828",
                borderRadius: "8px",
                marginBottom: "20px"
              }}>
                {error}
              </div>
            )}

            {selectedDate && !loading && availableCounselors.length > 0 && (
              <div style={{ marginBottom: "24px" }}>
                <label style={{ display: "block", marginBottom: "12px", fontWeight: "600" }}>
                  2. Select a Counselor and Time Slot
                </label>
                {availableCounselors.map(counselor => (
                  <div 
                    key={counselor.id}
                    style={{
                      marginBottom: "20px",
                      padding: "16px",
                      border: "1px solid #e0e0e0",
                      borderRadius: "8px",
                      backgroundColor: "white"
                    }}
                  >
                    <h4 style={{ margin: "0 0 12px 0", color: "var(--pink)" }}>
                      {counselor.name || counselor.email}
                    </h4>
                    <div style={{ 
                      display: "flex", 
                      gap: "10px", 
                      flexWrap: "wrap" 
                    }}>
                      {counselor.availableSlots.map(slot => renderSlotButton(slot))}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {selectedSlot && (
              <button
                type="submit"
                disabled={loading}
                style={{
                  width: "100%",
                  padding: "14px",
                  backgroundColor: loading ? "#ccc" : "var(--teal)",
                  color: "white",
                  border: "none",
                  borderRadius: "8px",
                  fontSize: "16px",
                  fontWeight: "600",
                  cursor: loading ? "not-allowed" : "pointer"
                }}
              >
                {loading ? "Booking..." : "Confirm Booking"}
              </button>
            )}
          </form>
        ) : (
          <form onSubmit={handleSubmit}>
            <div style={{ marginBottom: "24px" }}>
              <button
                type="button"
                onClick={resetFlow}
                style={{
                  padding: "8px 16px",
                  backgroundColor: "#f5f5f5",
                  border: "1px solid #ddd",
                  borderRadius: "6px",
                  cursor: "pointer",
                  marginBottom: "20px"
                }}
              >
                ← Change Booking Method
              </button>

              <label style={{ display: "block", marginBottom: "8px", fontWeight: "600" }}>
                1. Select a Counselor
              </label>
              <select
                value={selectedCounselor}
                onChange={(e) => {
                  setSelectedCounselor(e.target.value);
                  setSelectedDate("");
                  setSelectedSlot("");
                }}
                style={{
                  width: "100%",
                  padding: "12px",
                  border: "1px solid #ccc",
                  borderRadius: "8px",
                  fontSize: "16px"
                }}
                required
              >
                <option value="">-- Choose a counselor --</option>
                {counselors.map(c => (
                  <option key={c.id} value={c.id}>
                    {c.name || c.email}
                  </option>
                ))}
              </select>
            </div>

            {loading && <p style={{ textAlign: "center", color: "#666" }}>Loading available slots...</p>}
            
            {error && (
              <div style={{ 
                padding: "12px", 
                backgroundColor: "#ffebee", 
                color: "#c62828",
                borderRadius: "8px",
                marginBottom: "20px"
              }}>
                {error}
              </div>
            )}

            {selectedCounselor && !loading && Object.keys(availableSlots).length > 0 && (
              <div style={{ marginBottom: "24px" }}>
                <label style={{ display: "block", marginBottom: "12px", fontWeight: "600" }}>
                  2. Select Date and Time
                </label>
                {Object.entries(availableSlots).map(([date, slots]) => (
                  <div 
                    key={date}
                    style={{
                      marginBottom: "20px",
                      padding: "16px",
                      border: "1px solid #e0e0e0",
                      borderRadius: "8px",
                      backgroundColor: "white"
                    }}
                  >
                    <h4 style={{ margin: "0 0 12px 0", color: "var(--pink)" }}>
                      {formatDate(date)}
                    </h4>
                    <div style={{ 
                      display: "flex", 
                      gap: "10px", 
                      flexWrap: "wrap" 
                    }}>
                      {slots.map(slot => renderSlotButton(slot))}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {selectedSlot && (
              <button
                type="submit"
                disabled={loading}
                style={{
                  width: "100%",
                  padding: "14px",
                  backgroundColor: loading ? "#ccc" : "var(--teal)",
                  color: "white",
                  border: "none",
                  borderRadius: "8px",
                  fontSize: "16px",
                  fontWeight: "600",
                  cursor: loading ? "not-allowed" : "pointer"
                }}
              >
                {loading ? "Booking..." : "Confirm Booking"}
              </button>
            )}
          </form>
        )}
      </main>
    </div>
  );
}