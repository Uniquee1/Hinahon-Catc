// backend/utils/emailService.js
const { Resend } = require('resend');

const resend = new Resend(process.env.RESEND_API_KEY);
const SENDER_EMAIL = process.env.SENDER_EMAIL || 'onboarding@resend.dev';

/**
 * Send booking confirmation to student
 */
async function sendBookingConfirmation(studentEmail, studentName, counselorName, date, time) {
  try {
    const formattedDate = new Date(date).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    const formattedTime = formatTime(time);

    const { data, error } = await resend.emails.send({
      from: SENDER_EMAIL,
      to: studentEmail,
      subject: 'Consultation Booking Confirmed - Hinahon',
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(90deg, #e91e63, #00bfa5); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 8px 8px; }
            .info-box { background: white; padding: 20px; margin: 20px 0; border-left: 4px solid #00bfa5; border-radius: 4px; }
            .button { display: inline-block; background: #00bfa5; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; margin-top: 20px; }
            .footer { text-align: center; margin-top: 30px; color: #666; font-size: 12px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1 style="margin: 0;">Hinahon</h1>
              <p style="margin: 10px 0 0 0;">Mental Health Consultation</p>
            </div>
            <div class="content">
              <h2>Booking Confirmed!</h2>
              <p>Hello ${studentName},</p>
              <p>Your consultation booking has been successfully submitted. We're here to support your mental health journey.</p>
              
              <div class="info-box">
                <h3 style="margin-top: 0; color: #e91e63;">Consultation Details</h3>
                <p><strong>Counselor:</strong> ${counselorName}</p>
                <p><strong>Date:</strong> ${formattedDate}</p>
                <p><strong>Time:</strong> ${formattedTime}</p>
                <p><strong>Status:</strong> <span style="color: #856404;">Pending Approval</span></p>
              </div>

              <h3>What Happens Next?</h3>
              <ol>
                <li>Your counselor will review your booking request</li>
                <li>You'll receive a confirmation email once approved</li>
                <li>A video call link will be provided in the confirmation</li>
                <li>Join the call at your scheduled time</li>
              </ol>

              <p><strong>Note:</strong> The video link will be accessible starting at your scheduled time and will remain active for 3 hours.</p>

              <p>If you have any questions or need to reschedule, please contact us as soon as possible.</p>

              <div class="footer">
                <p>This is an automated message from Hinahon Mental Health Services</p>
                <p>&copy; 2025 Team Hinahon. All Rights Reserved.</p>
              </div>
            </div>
          </div>
        </body>
        </html>
      `
    });

    if (error) {
      console.error('Error sending booking confirmation:', error);
      return { success: false, error };
    }

    console.log('Booking confirmation sent to:', studentEmail);
    return { success: true, data };

  } catch (err) {
    console.error('Error in sendBookingConfirmation:', err);
    return { success: false, error: err.message };
  }
}

/**
 * Send new booking notification to counselor
 */
async function sendCounselorNotification(counselorEmail, counselorName, studentName, studentEmail, date, time) {
  try {
    const formattedDate = new Date(date).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    const formattedTime = formatTime(time);

    const { data, error } = await resend.emails.send({
      from: SENDER_EMAIL,
      to: counselorEmail,
      subject: 'New Consultation Request - Hinahon',
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(90deg, #e91e63, #00bfa5); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 8px 8px; }
            .info-box { background: white; padding: 20px; margin: 20px 0; border-left: 4px solid #e91e63; border-radius: 4px; }
            .button { display: inline-block; background: #e91e63; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; margin-top: 20px; }
            .footer { text-align: center; margin-top: 30px; color: #666; font-size: 12px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1 style="margin: 0;">Hinahon</h1>
              <p style="margin: 10px 0 0 0;">Counselor Dashboard</p>
            </div>
            <div class="content">
              <h2>New Consultation Request</h2>
              <p>Hello ${counselorName},</p>
              <p>You have received a new consultation booking request.</p>
              
              <div class="info-box">
                <h3 style="margin-top: 0; color: #e91e63;">Request Details</h3>
                <p><strong>Student:</strong> ${studentName}</p>
                <p><strong>Email:</strong> ${studentEmail}</p>
                <p><strong>Requested Date:</strong> ${formattedDate}</p>
                <p><strong>Requested Time:</strong> ${formattedTime}</p>
              </div>

              <p><strong>Action Required:</strong> Please log in to your counselor dashboard to review and respond to this request.</p>

              <a href="${process.env.FRONTEND_URL || 'http://localhost:5173'}/counselor" class="button">
                View Dashboard
              </a>

              <p style="margin-top: 30px; font-size: 14px; color: #666;">
                <strong>Note:</strong> Please respond to this request within 24 hours. The student is waiting for your confirmation.
              </p>

              <div class="footer">
                <p>This is an automated message from Hinahon Mental Health Services</p>
                <p>&copy; 2025 Team Hinahon. All Rights Reserved.</p>
              </div>
            </div>
          </div>
        </body>
        </html>
      `
    });

    if (error) {
      console.error('Error sending counselor notification:', error);
      return { success: false, error };
    }

    console.log('Counselor notification sent to:', counselorEmail);
    return { success: true, data };

  } catch (err) {
    console.error('Error in sendCounselorNotification:', err);
    return { success: false, error: err.message };
  }
}

/**
 * Send acceptance confirmation with video link
 */
async function sendAcceptanceNotification(studentEmail, studentName, counselorName, date, time, videoLink) {
  try {
    const formattedDate = new Date(date).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    const formattedTime = formatTime(time);

    const { data, error } = await resend.emails.send({
      from: SENDER_EMAIL,
      to: studentEmail,
      subject: 'Consultation Approved - Video Link Included',
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(90deg, #00bfa5, #00a88c); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 8px 8px; }
            .info-box { background: white; padding: 20px; margin: 20px 0; border-left: 4px solid #00bfa5; border-radius: 4px; }
            .video-box { background: #e6fff9; padding: 20px; margin: 20px 0; border: 2px solid #00bfa5; border-radius: 8px; text-align: center; }
            .button { display: inline-block; background: #00bfa5; color: white; padding: 15px 40px; text-decoration: none; border-radius: 6px; font-size: 16px; font-weight: bold; }
            .footer { text-align: center; margin-top: 30px; color: #666; font-size: 12px; }
            .warning { background: #fff3cd; padding: 15px; border-left: 4px solid #856404; margin: 20px 0; border-radius: 4px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1 style="margin: 0;">✅ Consultation Approved!</h1>
            </div>
            <div class="content">
              <p>Hello ${studentName},</p>
              <p>Great news! Your consultation has been approved by your counselor.</p>
              
              <div class="info-box">
                <h3 style="margin-top: 0; color: #00bfa5;">Consultation Details</h3>
                <p><strong>Counselor:</strong> ${counselorName}</p>
                <p><strong>Date:</strong> ${formattedDate}</p>
                <p><strong>Time:</strong> ${formattedTime}</p>
                <p><strong>Status:</strong> <span style="color: #155724;">✓ Confirmed</span></p>
              </div>

              <div class="video-box">
                <h3 style="color: #00bfa5; margin-top: 0;">Your Video Call Link</h3>
                <p style="margin: 20px 0;">Click the button below to join your consultation:</p>
                <a href="${videoLink}" class="button">
                  🎥 Join Video Consultation
                </a>
                <p style="margin-top: 20px; font-size: 14px; color: #666;">
                  Or copy this link: <br>
                  <code style="background: white; padding: 5px 10px; border-radius: 4px; display: inline-block; margin-top: 10px;">${videoLink}</code>
                </p>
              </div>

              <div class="warning">
                <strong>⏰ Important:</strong>
                <ul style="margin: 10px 0;">
                  <li>The video link will be <strong>active at your scheduled time</strong></li>
                  <li>The link remains active for <strong>3 hours</strong> after the start time</li>
                  <li>Please join on time to make the most of your session</li>
                </ul>
              </div>

              <h3>Before Your Session:</h3>
              <ul>
                <li>✓ Test your camera and microphone</li>
                <li>✓ Find a quiet, private space</li>
                <li>✓ Have a stable internet connection</li>
                <li>✓ Prepare any questions or concerns you want to discuss</li>
              </ul>

              <p>We're here to support you. If you have any technical issues or need to reschedule, please contact us immediately.</p>

              <div class="footer">
                <p>This is an automated message from Hinahon Mental Health Services</p>
                <p>&copy; 2025 Team Hinahon. All Rights Reserved.</p>
              </div>
            </div>
          </div>
        </body>
        </html>
      `
    });

    if (error) {
      console.error('Error sending acceptance notification:', error);
      return { success: false, error };
    }

    console.log('Acceptance notification sent to:', studentEmail);
    return { success: true, data };

  } catch (err) {
    console.error('Error in sendAcceptanceNotification:', err);
    return { success: false, error: err.message };
  }
}

/**
 * Send rejection notification
 */
async function sendRejectionNotification(studentEmail, studentName, counselorName, date, time, reason) {
  try {
    const formattedDate = new Date(date).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    const formattedTime = formatTime(time);

    const { data, error } = await resend.emails.send({
      from: SENDER_EMAIL,
      to: studentEmail,
      subject: 'Consultation Request Update - Hinahon',
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #6c757d; color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 8px 8px; }
            .info-box { background: white; padding: 20px; margin: 20px 0; border-left: 4px solid #6c757d; border-radius: 4px; }
            .button { display: inline-block; background: #00bfa5; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; margin-top: 20px; }
            .footer { text-align: center; margin-top: 30px; color: #666; font-size: 12px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1 style="margin: 0;">Consultation Request Update</h1>
            </div>
            <div class="content">
              <p>Hello ${studentName},</p>
              <p>We wanted to update you about your consultation request.</p>
              
              <div class="info-box">
                <h3 style="margin-top: 0;">Request Details</h3>
                <p><strong>Counselor:</strong> ${counselorName}</p>
                <p><strong>Date:</strong> ${formattedDate}</p>
                <p><strong>Time:</strong> ${formattedTime}</p>
                ${reason ? `<p><strong>Note:</strong> ${reason}</p>` : ''}
              </div>

              <p>Unfortunately, your counselor is unable to accommodate this particular time slot. Please don't be discouraged - this doesn't reflect on you or your needs.</p>

              <h3>What You Can Do:</h3>
              <ul>
                <li>Book another time slot that works better</li>
                <li>Choose a different counselor if available</li>
                <li>Contact us if you need assistance</li>
              </ul>

              <a href="${process.env.FRONTEND_URL || 'http://localhost:5173'}/booking" class="button">
                Book Another Time
              </a>

              <p style="margin-top: 30px;">Remember, seeking help is a sign of strength. We're here to support you on your mental health journey.</p>

              <div class="footer">
                <p>This is an automated message from Hinahon Mental Health Services</p>
                <p>&copy; 2025 Team Hinahon. All Rights Reserved.</p>
              </div>
            </div>
          </div>
        </body>
        </html>
      `
    });

    if (error) {
      console.error('Error sending rejection notification:', error);
      return { success: false, error };
    }

    console.log('Rejection notification sent to:', studentEmail);
    return { success: true, data };

  } catch (err) {
    console.error('Error in sendRejectionNotification:', err);
    return { success: false, error: err.message };
  }
}

/**
 * Helper function to format time
 */
function formatTime(timeString) {
  const [hours, minutes] = timeString.split(':');
  const hour = parseInt(hours);
  const ampm = hour >= 12 ? 'PM' : 'AM';
  const displayHour = hour % 12 || 12;
  return `${displayHour}:${minutes} ${ampm}`;
}

module.exports = {
  sendBookingConfirmation,
  sendCounselorNotification,
  sendAcceptanceNotification,
  sendRejectionNotification
};