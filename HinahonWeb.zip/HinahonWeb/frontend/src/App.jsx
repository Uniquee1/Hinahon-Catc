import React, { useEffect, useState, useRef } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import LoginPage from "./pages/LoginPage";
import ProfileCompletionPage from "./pages/ProfileCompletionPage";
import ResetPasswordPage from "./pages/ResetPasswordPage";
import LandingPage from "./pages/LandingPage";
import AdminPage from "./pages/AdminPage";
import CounselorPage from "./pages/CounselorPage";
import ArticlesPage from "./pages/ArticlesPage";
import BookingPage from "./pages/BookingPage";
import { supabase } from "./supabaseClient";

export default function App() {
  const [session, setSession] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const timeoutRef = useRef(null);

  // Fetch user profile with timeout
  const fetchUserProfile = async (user) => {
    try {
      console.log("Fetching profile for user:", user.id, user.email);

      // Create a timeout promise
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('Fetch timeout')), 5000);
      });

      // Race between fetch and timeout
      const fetchPromise = supabase
        .from("users")
        .select("*")
        .eq("id", user.id)
        .maybeSingle();

      const { data, error } = await Promise.race([fetchPromise, timeoutPromise]);

      if (error) {
        console.error("Error fetching profile:", error);
        // Set default profile if fetch fails
        setUserProfile({ id: user.id, profile_completed: false, role: 'student' });
        return;
      }

      if (!data) {
        console.log("Profile not found, creating default");
        setUserProfile({ id: user.id, profile_completed: false, role: 'student' });
        return;
      }

      console.log("Profile data fetched successfully:", data);
      console.log("Role:", data.role, "Profile Completed:", data.profile_completed);
      
      // ✅ KEY FIX: Auto-mark counselors and admins as profile_completed
      if ((data.role === 'counselor' || data.role === 'admin') && !data.profile_completed) {
        console.log("Auto-completing profile for counselor/admin");
        
        // Update database to mark profile as completed
        const { error: updateError } = await supabase
          .from('users')
          .update({ profile_completed: true })
          .eq('id', user.id);
        
        if (updateError) {
          console.error("Error auto-completing profile:", updateError);
        }
        
        // Update local state
        setUserProfile({ ...data, profile_completed: true });
      } else {
        setUserProfile(data);
      }
    } catch (err) {
      console.error("Error in fetchUserProfile:", err.message);
      // Always set a default profile to prevent infinite loading
      setUserProfile({ id: user.id, profile_completed: false, role: 'student' });
    }
  };

  // Refresh user profile (called after profile completion)
  const refreshUserProfile = async () => {
    console.log("Refreshing user profile...");
    if (session?.user) {
      await fetchUserProfile(session.user);
    }
  };

  useEffect(() => {
    let mounted = true;
    let authSubscription = null;

    const initializeAuth = async () => {
      try {
        console.log("Initializing auth...");
        
        // Get current session
        const { data: { session: currentSession }, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error("Error getting session:", error);
          if (mounted) {
            setLoading(false);
            // Clear timeout since we're done loading
            if (timeoutRef.current) {
              clearTimeout(timeoutRef.current);
              timeoutRef.current = null;
            }
          }
          return;
        }

        if (!mounted) return;

        if (currentSession?.user) {
          console.log("Session found:", currentSession.user.email);
          setSession(currentSession);
          await fetchUserProfile(currentSession.user);
        } else {
          console.log("No session found");
        }

        if (mounted) {
          setLoading(false);
          // Clear timeout since we're done loading
          if (timeoutRef.current) {
            clearTimeout(timeoutRef.current);
            timeoutRef.current = null;
            console.log("Cleared safety timeout - loading complete");
          }
        }
      } catch (err) {
        console.error("Error in initializeAuth:", err);
        if (mounted) {
          setLoading(false);
          // Clear timeout since we're done loading
          if (timeoutRef.current) {
            clearTimeout(timeoutRef.current);
            timeoutRef.current = null;
          }
        }
      }
    };

    // Set up auth state listener
    const setupAuthListener = () => {
      const { data: { subscription } } = supabase.auth.onAuthStateChange(
        async (event, newSession) => {
          if (!mounted) return;
          
          console.log("Auth state changed:", event);

          // Only handle specific events, ignore INITIAL_SESSION
          if (event === 'SIGNED_IN') {
            console.log("User signed in:", newSession?.user?.email);
            if (newSession?.user) {
              setSession(newSession);
              setLoading(true);
              await fetchUserProfile(newSession.user);
              if (mounted) {
                setLoading(false);
                // Clear timeout after successful sign in
                if (timeoutRef.current) {
                  clearTimeout(timeoutRef.current);
                  timeoutRef.current = null;
                }
              }
            }
          } else if (event === 'SIGNED_OUT') {
            console.log("User signed out");
            setSession(null);
            setUserProfile(null);
            if (mounted) {
              setLoading(false);
              // Clear timeout on sign out
              if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
                timeoutRef.current = null;
              }
            }
          } else if (event === 'USER_UPDATED' && newSession?.user) {
            console.log("User updated");
            await fetchUserProfile(newSession.user);
          }
        }
      );
      
      authSubscription = subscription;
    };

    // Initialize
    initializeAuth();
    setupAuthListener();

    // Safety timeout - force stop loading and redirect to login
    timeoutRef.current = setTimeout(() => {
      if (mounted && loading) {
        console.warn("Safety timeout reached - redirecting to login");
        setLoading(false);
        // Sign out the user and clear session
        supabase.auth.signOut();
        setSession(null);
        setUserProfile(null);
        timeoutRef.current = null;
      }
    }, 8000);

    return () => {
      mounted = false;
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
      authSubscription?.unsubscribe();
    };
  }, []); // Empty dependency array

  if (loading) {
    return (
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh',
        flexDirection: 'column',
        gap: '16px'
      }}>
        <div style={{
          width: '48px',
          height: '48px',
          border: '4px solid #f3f3f3',
          borderTop: '4px solid #e91e63',
          borderRadius: '50%',
          animation: 'spin 1s linear infinite'
        }}></div>
        <p style={{ color: '#666' }}>Loading...</p>
        <style>{`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    );
  }

  // ✅ Helper function to check if profile completion is needed
  const needsProfileCompletion = (profile) => {
    if (!profile) return false;
    // Only students need to complete profile
    if (profile.role !== 'student') return false;
    return !profile.profile_completed;
  };

  console.log("Rendering with profile:", userProfile);

  return (
    <Router>
      <Routes>
        {/* Login/Signup Page */}
        <Route
          path="/"
          element={
            !session ? (
              <LoginPage setSession={setSession} />
            ) : needsProfileCompletion(userProfile) ? (
              <Navigate to="/profile-completion" replace />
            ) : userProfile?.role === "admin" ? (
              <Navigate to="/admin" replace />
            ) : userProfile?.role === "counselor" ? (
              <Navigate to="/counselor" replace />
            ) : (
              <Navigate to="/landing" replace />
            )
          }
        />

        {/* Reset Password Page - Accessible without full session */}
        <Route
          path="/reset-password"
          element={<ResetPasswordPage />}
        />

        {/* Profile Completion Page - ONLY for students */}
        <Route
          path="/profile-completion"
          element={
            session && userProfile && needsProfileCompletion(userProfile) ? (
              <ProfileCompletionPage 
                user={session.user} 
                onComplete={refreshUserProfile}
              />
            ) : !session ? (
              <Navigate to="/" replace />
            ) : userProfile?.role === "admin" ? (
              <Navigate to="/admin" replace />
            ) : userProfile?.role === "counselor" ? (
              <Navigate to="/counselor" replace />
            ) : userProfile?.profile_completed ? (
              <Navigate to="/landing" replace />
            ) : (
              <div>Loading profile...</div>
            )
          }
        />

        {/* Landing Page (Students only) */}
        <Route
          path="/landing"
          element={
            session && userProfile?.profile_completed && userProfile.role === "student" ? (
              <LandingPage session={session} setSession={setSession} />
            ) : !session ? (
              <Navigate to="/" replace />
            ) : needsProfileCompletion(userProfile) ? (
              <Navigate to="/profile-completion" replace />
            ) : (
              <Navigate to="/" replace />
            )
          }
        />

        {/* Articles Page - All authenticated users */}
        <Route
          path="/articles"
          element={
            session && userProfile ? (
              <ArticlesPage session={session} />
            ) : (
              <Navigate to="/" replace />
            )
          }
        />

        <Route
          path="/articles/:emotion"
          element={
            session && userProfile ? (
              <ArticlesPage session={session} />
            ) : (
              <Navigate to="/" replace />
            )
          }
        />

        {/* Booking Page - Students only */}
        <Route
          path="/booking"
          element={
            session && userProfile?.profile_completed && userProfile.role === "student" ? (
              <BookingPage session={session} />
            ) : (
              <Navigate to="/" replace />
            )
          }
        />

        {/* Counselor Page - Counselors only */}
        <Route
          path="/counselor"
          element={
            session && userProfile?.role === "counselor" ? (
              <CounselorPage />
            ) : (
              <Navigate to="/" replace />
            )
          }
        />

        {/* Admin Page - Admins only */}
        <Route
          path="/admin"
          element={
            session && userProfile?.role === "admin" ? (
              <AdminPage />
            ) : (
              <Navigate to="/" replace />
            )
          }
        />

        {/* Catch all - redirect to home */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}