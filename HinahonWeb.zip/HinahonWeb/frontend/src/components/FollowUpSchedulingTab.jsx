// Improved Follow-Up Scheduling Tab Component
// Features: Student filters, custom date/time selection, better UI/UX, infinite scroll

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { supabase } from '../supabaseClient';

const FollowUpSchedulingTab = () => {
  const [eligibleStudents, setEligibleStudents] = useState([]);
  const [filteredStudents, setFilteredStudents] = useState([]);
  const [displayedStudents, setDisplayedStudents] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [duration, setDuration] = useState(60); // Default 60 minutes
  const [loading, setLoading] = useState(true);
  const [scheduling, setScheduling] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });
  const [user, setUser] = useState(null);

  // Filter states
  const [searchName, setSearchName] = useState('');
  const [filterDepartment, setFilterDepartment] = useState('all');
  const [filterYearLevel, setFilterYearLevel] = useState('all');
  const [showStudentCard, setShowStudentCard] = useState(false);

  // Infinite scroll states
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const observerTarget = useRef(null);
  const studentsPerPage = 10;

  useEffect(() => {
    fetchCurrentUser();
  }, []);

  useEffect(() => {
    if (user) {
      fetchEligibleStudents();
    }
  }, [user]);

  // Filter students whenever filters change
  useEffect(() => {
    filterStudentsList();
  }, [eligibleStudents, searchName, filterDepartment, filterYearLevel]);

  // Reset pagination when filters change
  useEffect(() => {
    setPage(1);
    setDisplayedStudents([]);
    loadMoreStudents(1);
  }, [filteredStudents]);

  // Infinite scroll observer
  useEffect(() => {
    const observer = new IntersectionObserver(
      entries => {
        if (entries[0].isIntersecting && hasMore && !loading) {
          loadMoreStudents(page + 1);
        }
      },
      { threshold: 0.1 }
    );

    if (observerTarget.current) {
      observer.observe(observerTarget.current);
    }

    return () => {
      if (observerTarget.current) {
        observer.unobserve(observerTarget.current);
      }
    };
  }, [hasMore, loading, page, filteredStudents]);

  const loadMoreStudents = useCallback((pageNum) => {
    const startIndex = (pageNum - 1) * studentsPerPage;
    const endIndex = startIndex + studentsPerPage;
    const newStudents = filteredStudents.slice(startIndex, endIndex);

    if (newStudents.length > 0) {
      setDisplayedStudents(prev => 
        pageNum === 1 ? newStudents : [...prev, ...newStudents]
      );
      setPage(pageNum);
      setHasMore(endIndex < filteredStudents.length);
    } else {
      setHasMore(false);
    }
  }, [filteredStudents, studentsPerPage]);

  const fetchCurrentUser = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    setUser(user);
  };

  const fetchEligibleStudents = async () => {
    try {
      setLoading(true);
      const { data: { session } } = await supabase.auth.getSession();
      
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/followup/eligible-students/${user.id}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${session.access_token}`
        }
      });

      const data = await response.json();
      
      if (response.ok) {
        setEligibleStudents(data.students || []);
      } else {
        setMessage({ type: 'error', text: data.error || 'Failed to load students' });
      }
    } catch (err) {
      console.error('Error fetching eligible students:', err);
      setMessage({ type: 'error', text: 'Failed to load students' });
    } finally {
      setLoading(false);
    }
  };

  const filterStudentsList = () => {
    let filtered = [...eligibleStudents];

    // Filter by name search
    if (searchName.trim()) {
      filtered = filtered.filter(student =>
        student.name?.toLowerCase().includes(searchName.toLowerCase()) ||
        student.email?.toLowerCase().includes(searchName.toLowerCase())
      );
    }

    // Filter by department
    if (filterDepartment !== 'all') {
      filtered = filtered.filter(student => student.department === filterDepartment);
    }

    // Filter by year level - Fixed to handle string/number comparison
    if (filterYearLevel !== 'all') {
      filtered = filtered.filter(student => {
        // Convert both to strings for comparison
        const studentYear = String(student.year_level);
        const filterYear = String(filterYearLevel);
        return studentYear === filterYear;
      });
    }

    setFilteredStudents(filtered);
  };

  // Handle student selection/deselection
  const handleStudentSelect = (student) => {
    if (selectedStudent?.id === student.id) {
      // Deselect if clicking the same student
      setSelectedStudent(null);
      setShowStudentCard(false);
    } else {
      // Select new student
      setSelectedStudent(student);
      setShowStudentCard(true);
    }
  };

  // Clear selected student
  const clearSelectedStudent = () => {
    setSelectedStudent(null);
    setShowStudentCard(false);
  };

  const handleScheduleFollowUp = async () => {
    if (!selectedStudent || !selectedDate || !selectedTime) {
      setMessage({ type: 'error', text: 'Please fill in all fields' });
      return;
    }

    // Validate date is in the future
    const selectedDateTime = new Date(`${selectedDate}T${selectedTime}`);
    const now = new Date();
    if (selectedDateTime <= now) {
      setMessage({ type: 'error', text: 'Please select a future date and time' });
      return;
    }

    try {
      setScheduling(true);
      setMessage({ type: '', text: '' });

      const { data: { session } } = await supabase.auth.getSession();

      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/followup/schedule`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`
        },
        body: JSON.stringify({
          studentId: selectedStudent.id,
          date: selectedDate,
          time: selectedTime,
          duration: duration
        })
      });

      const data = await response.json();

      if (response.ok) {
        setMessage({ 
          type: 'success', 
          text: `✅ Follow-up consultation scheduled successfully with ${selectedStudent.name}! Confirmation emails have been sent to both of you. The video room will be created on ${formatDate(selectedDate)}.` 
        });
        
        // Reset form
        clearSelectedStudent();
        setSelectedDate('');
        setSelectedTime('');
        setDuration(60);
        
        // Refresh data
        fetchEligibleStudents();
      } else {
        setMessage({ type: 'error', text: data.error || 'Failed to schedule follow-up' });
      }
    } catch (err) {
      console.error('Error scheduling follow-up:', err);
      setMessage({ type: 'error', text: 'Failed to schedule follow-up' });
    } finally {
      setScheduling(false);
    }
  };

  const formatTime = (time) => {
    if (!time) return '';
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  const formatDate = (date) => {
    if (!date) return '';
    return new Date(date).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const calculateEndTime = (startTime, durationMinutes) => {
    if (!startTime) return '';
    const [hours, minutes] = startTime.split(':');
    const totalMinutes = parseInt(hours) * 60 + parseInt(minutes) + durationMinutes;
    const endHours = Math.floor(totalMinutes / 60) % 24;
    const endMinutes = totalMinutes % 60;
    return `${String(endHours).padStart(2, '0')}:${String(endMinutes).padStart(2, '0')}`;
  };

  // Get unique departments and year levels for filters
  const departments = [...new Set(eligibleStudents.map(s => s.department).filter(Boolean))];
  const yearLevels = [...new Set(eligibleStudents.map(s => s.year_level).filter(Boolean))].sort();

  // Generate time options (8 AM to 8 PM, 30-minute intervals)
  const timeOptions = [];
const startHour = 8;
const endHour = 20;

for (let hour = startHour; hour <= endHour; hour++) {
  for (let minute = 0; minute < 60; minute += 30) {
    // Only include times <= 20:00
    if (hour < endHour || (hour === endHour && minute === 0)) {
      const time = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
      timeOptions.push(time);
    }
  }
}


  // Get minimum date (tomorrow)
  const getMinDate = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  };

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '60px 20px' }}>
        <div style={{
          width: '60px',
          height: '60px',
          border: '4px solid #f3f3f3',
          borderTop: '4px solid var(--teal)',
          borderRadius: '50%',
          animation: 'spin 1s linear infinite',
          margin: '0 auto 20px'
        }}></div>
        <p style={{ color: '#666', fontSize: '16px' }}>Loading students...</p>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '1000px', margin: '0 auto', padding: '20px' }}>
      {/* Header Section */}
      <div style={{
        backgroundColor: 'white',
        padding: '32px',
        borderRadius: '16px',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
        marginBottom: '24px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '16px' }}>
          <div style={{
            width: '48px',
            height: '48px',
            borderRadius: '12px',
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '24px'
          }}>
            🔄
          </div>
          <div>
            <h2 style={{ 
              margin: '0 0 4px 0', 
              color: '#1a202c',
              fontSize: '28px',
              fontWeight: '700'
            }}>
              Schedule Follow-Up Consultation
            </h2>
            <p style={{ 
              margin: 0, 
              color: '#718096',
              fontSize: '14px'
            }}>
              Select a previous student and choose a convenient time for your follow-up session
            </p>
          </div>
        </div>
      </div>

      {/* Message Display */}
      {message.text && (
        <div style={{
          padding: '16px 20px',
          borderRadius: '12px',
          marginBottom: '24px',
          backgroundColor: message.type === 'success' ? '#d4edda' : '#f8d7da',
          border: `2px solid ${message.type === 'success' ? '#28a745' : '#dc3545'}`,
          color: message.type === 'success' ? '#155724' : '#721c24',
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
        }}>
          <span style={{ fontSize: '24px' }}>
            {message.type === 'success' ? '✅' : '⚠️'}
          </span>
          <span style={{ flex: 1 }}>{message.text}</span>
          <button
            onClick={() => setMessage({ type: '', text: '' })}
            style={{
              background: 'none',
              border: 'none',
              fontSize: '20px',
              cursor: 'pointer',
              padding: '4px 8px',
              opacity: 0.7
            }}
          >
            ×
          </button>
        </div>
      )}

      {eligibleStudents.length === 0 ? (
        <div style={{
          backgroundColor: 'white',
          textAlign: 'center',
          padding: '80px 40px',
          borderRadius: '16px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <div style={{ fontSize: '64px', marginBottom: '16px' }}>📋</div>
          <h3 style={{ margin: '0 0 12px 0', color: '#1a202c', fontSize: '24px' }}>
            No Students Available Yet
          </h3>
          <p style={{color: '#718096', fontSize: '16px', maxWidth: '400px', margin: '0 auto' }}>
            Students will appear here after you've completed accepted consultations with them.
            Start consulting to build your student list!
          </p>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
          {/* Left Column - Student Selection */}
          <div style={{
            backgroundColor: 'white',
            padding: '28px',
            borderRadius: '16px',
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
            height: 'fit-content'
          }}>
            <h3 style={{ 
              margin: '0 0 20px 0', 
              color: '#1a202c',
              fontSize: '20px',
              fontWeight: '600',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}>
              <span>👥</span> Select Student
              <span style={{
                marginLeft: 'auto',
                fontSize: '14px',
                fontWeight: '500',
                color: '#718096',
                backgroundColor: '#e2e8f0',
                padding: '4px 12px',
                borderRadius: '20px'
              }}>
                {filteredStudents.length} of {eligibleStudents.length}
              </span>
            </h3>

            {/* Search Box */}
            <div style={{ marginBottom: '16px' }}>
              <input
                type="text"
                placeholder="🔍 Search by name or email..."
                value={searchName}
                onChange={(e) => setSearchName(e.target.value)}
                style={{
                  width: '100%',
                  padding: '12px 16px',
                  border: '2px solid #e2e8f0',
                  borderRadius: '10px',
                  fontSize: '14px',
                  outline: 'none',
                  transition: 'all 0.2s',
                  boxSizing: 'border-box'
                }}
                onFocus={(e) => e.target.style.borderColor = 'var(--teal)'}
                onBlur={(e) => e.target.style.borderColor = '#e2e8f0'}
              />
            </div>

            {/* Filter Section */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: '12px',
              marginBottom: '24px'
            }}>
              <div>
                <label style={{
                  display: 'block',
                  marginBottom: '6px',
                  fontSize: '12px',
                  fontWeight: '600',
                  color: '#4a5568',
                  textTransform: 'uppercase',
                  letterSpacing: '0.5px'
                }}>
                  Department
                </label>
                <select
                  value={filterDepartment}
                  onChange={(e) => setFilterDepartment(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '10px 12px',
                    border: '2px solid #e2e8f0',
                    borderRadius: '8px',
                    fontSize: '14px',
                    cursor: 'pointer',
                    backgroundColor: 'white',
                    outline: 'none'
                  }}
                >
                  <option value="all">All Departments</option>
                  {departments.map(dept => (
                    <option key={dept} value={dept}>{dept}</option>
                  ))}
                </select>
              </div>

              <div>
                <label style={{
                  display: 'block',
                  marginBottom: '6px',
                  fontSize: '12px',
                  fontWeight: '600',
                  color: '#4a5568',
                  textTransform: 'uppercase',
                  letterSpacing: '0.5px'
                }}>
                  Year Level
                </label>
                <select
                  value={filterYearLevel}
                  onChange={(e) => setFilterYearLevel(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '10px 12px',
                    border: '2px solid #e2e8f0',
                    borderRadius: '8px',
                    fontSize: '14px',
                    cursor: 'pointer',
                    backgroundColor: 'white',
                    outline: 'none'
                  }}
                >
                  <option value="all">All Years</option>
                  {yearLevels.map(year => (
                    <option key={year} value={year}>Year {year}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Students List with Infinite Scroll */}
            <div style={{
              maxHeight: '320px', // Shows ~3 students (3 * ~100px + gaps)
              overflowY: 'auto',
              marginTop: '16px',
              paddingRight: '8px'
            }}>
              {filteredStudents.length === 0 ? (
                <div style={{
                  textAlign: 'center',
                  padding: '40px 20px',
                  color: '#a0aec0',
                  fontSize: '14px'
                }}>
                  <div style={{ fontSize: '36px', marginBottom: '8px' }}>🔍</div>
                  No students match your filters
                </div>
              ) : (
                <>
                  {displayedStudents.map(student => (
                    <div
                      key={student.id}
                      onClick={() => handleStudentSelect(student)}
                      style={{
                        padding: '16px',
                        marginBottom: '12px',
                        marginTop: '6px',
                        border: selectedStudent?.id === student.id 
                          ? '2px solid var(--teal)' 
                          : '2px solid #e2e8f0',
                        borderRadius: '12px',
                        cursor: 'pointer',
                        transition: 'all 0.2s',
                        backgroundColor: selectedStudent?.id === student.id 
                          ? '#f0fdfa' 
                          : 'white',
                        position: 'relative'
                      }}
                      onMouseEnter={(e) => {
                        if (selectedStudent?.id !== student.id) {
                          e.currentTarget.style.borderColor = '#cbd5e0';
                          e.currentTarget.style.transform = 'translateY(-2px)';
                          e.currentTarget.style.boxShadow = '0 4px 6px rgba(0,0,0,0.1)';
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (selectedStudent?.id !== student.id) {
                          e.currentTarget.style.borderColor = '#e2e8f0';
                          e.currentTarget.style.transform = 'translateY(0)';
                          e.currentTarget.style.boxShadow = 'none';
                        }
                      }}
                    >
                      <div style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '12px'
                      }}>
                        <div style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: '50%',
                          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          color: 'white',
                          fontWeight: '600',
                          fontSize: '16px',
                          flexShrink: 0
                        }}>
                          {student.name?.charAt(0).toUpperCase() || '?'}
                        </div>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{
                            fontWeight: '600',
                            color: '#1a202c',
                            fontSize: '15px',
                            marginBottom: '4px',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap'
                          }}>
                            {student.name || 'Unknown'}
                          </div>
                          <div style={{
                            fontSize: '12px',
                            color: '#718096',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap'
                          }}>
                            {student.email}
                          </div>
                          {(student.department || student.year_level) && (
                            <div style={{
                              fontSize: '11px',
                              color: '#a0aec0',
                              marginTop: '4px'
                            }}>
                              {student.department && student.department}
                              {student.department && student.year_level && ' • '}
                              {student.year_level && `Year ${student.year_level}`}
                            </div>
                          )}
                        </div>
                        {selectedStudent?.id === student.id && (
                          <div style={{
                            color: 'var(--teal)',
                            fontSize: '20px',
                            flexShrink: 0
                          }}>
                            ✓
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                  
                  {/* Loading indicator for infinite scroll */}
                  {hasMore && (
                    <div 
                      ref={observerTarget}
                      style={{
                        padding: '16px',
                        textAlign: 'center',
                        color: '#a0aec0',
                        fontSize: '13px'
                      }}
                    >
                      Loading more...
                    </div>
                  )}

                  {/* End of list indicator */}
                  {!hasMore && displayedStudents.length > 0 && (
                    <div style={{
                      padding: '12px',
                      textAlign: 'center',
                      color: '#cbd5e0',
                      fontSize: '12px',
                      fontStyle: 'italic'
                    }}>
                      End of list
                    </div>
                  )}
                </>
              )}
            </div>
          </div>

          {/* Right Column - Date/Time Selection */}
          <div style={{
            backgroundColor: 'white',
            padding: '28px',
            borderRadius: '16px',
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
            height: 'fit-content'
          }}>
            <h3 style={{ 
              margin: '0 0 24px 0', 
              color: '#1a202c',
              fontSize: '20px',
              fontWeight: '600',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}>
              <span>📅</span> Schedule Details
            </h3>

            {!selectedStudent ? (
              <div style={{
                textAlign: 'center',
                padding: '60px 20px',
                color: '#a0aec0',
                fontSize: '14px'
              }}>
                <div style={{ fontSize: '48px', marginBottom: '12px' }}>👈</div>
                Select a student to continue
              </div>
            ) : (
              <>
                {/* Selected Student Card */}
                <div style={{
                  padding: '16px',
                  backgroundColor: '#f7fafc',
                  border: '2px solid #e2e8f0',
                  borderRadius: '12px',
                  marginBottom: '24px',
                  position: 'relative'
                }}>
                  {/* X button to clear selection */}
                  <button
                    onClick={clearSelectedStudent}
                    style={{
                      position: 'absolute',
                      top: '12px',
                      right: '12px',
                      width: '28px',
                      height: '28px',
                      borderRadius: '50%',
                      border: 'none',
                      backgroundColor: '#fee',
                      color: '#c53030',
                      fontSize: '16px',
                      fontWeight: 'bold',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      transition: 'all 0.2s',
                      zIndex: 1
                    }}
                    onMouseEnter={(e) => {
                      e.target.style.backgroundColor = '#fc8181';
                      e.target.style.color = 'white';
                      e.target.style.transform = 'scale(1.1)';
                    }}
                    onMouseLeave={(e) => {
                      e.target.style.backgroundColor = '#fee';
                      e.target.style.color = '#c53030';
                      e.target.style.transform = 'scale(1)';
                    }}
                    title="Clear selection"
                  >
                    ×
                  </button>

                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    marginBottom: '8px',
                    paddingRight: '32px' // Space for X button
                  }}>
                    <div style={{
                      width: '48px',
                      height: '48px',
                      borderRadius: '50%',
                      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: 'white',
                      fontWeight: '600',
                      fontSize: '20px'
                    }}>
                      {selectedStudent.name?.charAt(0).toUpperCase() || '?'}
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{
                        fontWeight: '600',
                        color: '#1a202c',
                        fontSize: '16px'
                      }}>
                        {selectedStudent.name}
                      </div>
                      <div style={{
                        fontSize: '13px',
                        color: '#718096'
                      }}>
                        {selectedStudent.email}
                      </div>
                    </div>
                  </div>
                  {(selectedStudent.department || selectedStudent.year_level) && (
                    <div style={{
                      display: 'flex',
                      gap: '8px',
                      marginTop: '12px',
                      flexWrap: 'wrap'
                    }}>
                      {selectedStudent.department && (
                        <span style={{
                          padding: '4px 12px',
                          backgroundColor: '#e6fffa',
                          color: '#234e52',
                          borderRadius: '6px',
                          fontSize: '12px',
                          fontWeight: '500'
                        }}>
                          {selectedStudent.department}
                        </span>
                      )}
                      {selectedStudent.year_level && (
                        <span style={{
                          padding: '4px 12px',
                          backgroundColor: '#ebf8ff',
                          color: '#2c5282',
                          borderRadius: '6px',
                          fontSize: '12px',
                          fontWeight: '500'
                        }}>
                          Year {selectedStudent.year_level}
                        </span>
                      )}
                    </div>
                  )}
                </div>

                {/* Date Selection */}
                <div style={{ marginBottom: '20px' }}>
                  <label style={{
                    display: 'block',
                    marginBottom: '8px',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: '#2d3748'
                  }}>
                    📆 Select Date
                  </label>
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    min={getMinDate()}
                    style={{
                      width: '100%',
                      padding: '12px 16px',
                      border: '2px solid #e2e8f0',
                      borderRadius: '10px',
                      fontSize: '14px',
                      outline: 'none',
                      cursor: 'pointer',
                      boxSizing: 'border-box'
                    }}
                  />
                </div>

                {/* Time Selection */}
                <div style={{ marginBottom: '20px' }}>
                  <label style={{
                    display: 'block',
                    marginBottom: '8px',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: '#2d3748'
                  }}>
                    ⏰ Select Time
                  </label>
                  <select
                    value={selectedTime}
                    onChange={(e) => setSelectedTime(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '12px 16px',
                      border: '2px solid #e2e8f0',
                      borderRadius: '10px',
                      fontSize: '14px',
                      cursor: 'pointer',
                      backgroundColor: 'white',
                      outline: 'none',
                      boxSizing: 'border-box'
                    }}
                  >
                    <option value="">-- Select time --</option>
                    {timeOptions.map(time => (
                      <option key={time} value={time}>
                        {formatTime(time)}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Duration Selection */}
                <div style={{ marginBottom: '24px' }}>
                  <label style={{
                    display: 'block',
                    marginBottom: '8px',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: '#2d3748'
                  }}>
                    ⏱️ Duration
                  </label>
                  <select
                    value={duration}
                    onChange={(e) => setDuration(parseInt(e.target.value))}
                    style={{
                      width: '100%',
                      padding: '12px 16px',
                      border: '2px solid #e2e8f0',
                      borderRadius: '10px',
                      fontSize: '14px',
                      cursor: 'pointer',
                      backgroundColor: 'white',
                      outline: 'none',
                      boxSizing: 'border-box'
                    }}
                  >
                    <option value={30}>30 minutes</option>
                    <option value={60}>1 hour</option>
                  </select>
                </div>

                {/* Summary */}
                {selectedDate && selectedTime && (
                  <div style={{
                    padding: '20px',
                    backgroundColor: '#f0fdf4',
                    border: '2px solid #86efac',
                    borderRadius: '12px',
                    marginBottom: '24px'
                  }}>
                    <h4 style={{
                      margin: '0 0 16px 0',
                      color: '#166534',
                      fontSize: '16px',
                      fontWeight: '600'
                    }}>
                      📋 Consultation Summary
                    </h4>
                    <div style={{
                      display: 'grid',
                      gap: '12px',
                      fontSize: '14px'
                    }}>
                      <div style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        paddingBottom: '8px',
                        borderBottom: '1px solid #bbf7d0'
                      }}>
                        <span style={{ color: '#15803d', fontWeight: '500' }}>Student:</span>
                        <span style={{ color: '#166534', fontWeight: '600' }}>{selectedStudent.name}</span>
                      </div>
                      <div style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        paddingBottom: '8px',
                        borderBottom: '1px solid #bbf7d0'
                      }}>
                        <span style={{ color: '#15803d', fontWeight: '500' }}>Date:</span>
                        <span style={{ color: '#166534', fontWeight: '600' }}>{formatDate(selectedDate)}</span>
                      </div>
                      <div style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        paddingBottom: '8px',
                        borderBottom: '1px solid #bbf7d0'
                      }}>
                        <span style={{ color: '#15803d', fontWeight: '500' }}>Time:</span>
                        <span style={{ color: '#166534', fontWeight: '600' }}>
                          {formatTime(selectedTime)} - {formatTime(calculateEndTime(selectedTime, duration))}
                        </span>
                      </div>
                      <div style={{
                        display: 'flex',
                        justifyContent: 'space-between'
                      }}>
                        <span style={{ color: '#15803d', fontWeight: '500' }}>Duration:</span>
                        <span style={{ color: '#166534', fontWeight: '600' }}>
                          {duration} minutes
                        </span>
                      </div>
                    </div>
                    <div style={{
                      marginTop: '16px',
                      padding: '12px',
                      backgroundColor: '#fef3c7',
                      borderLeft: '3px solid #fbbf24',
                      borderRadius: '6px',
                      fontSize: '12px',
                      color: '#78350f'
                    }}>
                      <strong>📹 Video Room:</strong> Will be created automatically on {formatDate(selectedDate)}
                    </div>
                  </div>
                )}

                {/* Schedule Button */}
                <button
                  onClick={handleScheduleFollowUp}
                  disabled={!selectedStudent || !selectedDate || !selectedTime || scheduling}
                  style={{
                    width: '100%',
                    padding: '16px',
                    backgroundColor: (!selectedStudent || !selectedDate || !selectedTime || scheduling)
                      ? '#cbd5e0'
                      : 'var(--teal)',
                    color: 'white',
                    border: 'none',
                    borderRadius: '12px',
                    fontSize: '16px',
                    fontWeight: '600',
                    cursor: (!selectedStudent || !selectedDate || !selectedTime || scheduling)
                      ? 'not-allowed'
                      : 'pointer',
                    transition: 'all 0.2s',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '10px',
                    boxShadow: (!selectedStudent || !selectedDate || !selectedTime || scheduling)
                      ? 'none'
                      : '0 4px 6px rgba(0,0,0,0.1)'
                  }}
                  onMouseEnter={(e) => {
                    if (!(!selectedStudent || !selectedDate || !selectedTime || scheduling)) {
                      e.target.style.transform = 'translateY(-2px)';
                      e.target.style.boxShadow = '0 6px 12px rgba(0,0,0,0.15)';
                    }
                  }}
                  onMouseLeave={(e) => {
                    e.target.style.transform = 'translateY(0)';
                    e.target.style.boxShadow = '0 4px 6px rgba(0,0,0,0.1)';
                  }}
                >
                  {scheduling ? (
                    <>
                      <div style={{
                        width: '20px',
                        height: '20px',
                        border: '3px solid white',
                        borderTop: '3px solid transparent',
                        borderRadius: '50%',
                        animation: 'spin 0.8s linear infinite'
                      }}></div>
                      Scheduling...
                    </>
                  ) : (
                    <>
                      <span style={{ fontSize: '20px' }}>📅</span>
                      Schedule Follow-Up Consultation
                    </>
                  )}
                </button>
              </>
            )}
          </div>
        </div>
      )}

      <style>{`
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }

        /* Custom scrollbar */
        ::-webkit-scrollbar {
          width: 8px;
        }

        ::-webkit-scrollbar-track {
          background: #f1f1f1;
          border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb {
          background: #cbd5e0;
          border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb:hover {
          background: #a0aec0;
        }
      `}</style>
    </div>
  );
};

export default FollowUpSchedulingTab;