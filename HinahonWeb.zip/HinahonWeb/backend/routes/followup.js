// backend/routes/followup.js
const express = require('express');
const { createClient } = require('@supabase/supabase-js');
const { authenticateUser, requireRole } = require('../middleware/auth');
const { sendFollowUpNotification } = require('../utils/emailService');

const router = express.Router();

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

/**
 * GET /api/followup/eligible-students/:counselorId
 * Get list of students who are eligible for follow-up scheduling
 * (students who had accepted consultations with this counselor in the past)
 */
router.get('/eligible-students/:counselorId', authenticateUser, requireRole('counselor', 'admin'), async (req, res) => {
  try {
    const { counselorId } = req.params;

    // Verify the counselor is requesting their own data or is admin
    if (req.user.id !== counselorId && req.userRole !== 'admin') {
      return res.status(403).json({ error: 'Not authorized' });
    }

    // Get all students who had accepted consultations with this counselor
    const { data: consultations, error } = await supabase
      .from('consultations')
      .select(`
        student_id,
        student:student_id(id, name, email, department, year_level)
      `)
      .eq('counselor_id', counselorId)
      .in('status', ['accepted', 'completed'])
      .order('date', { ascending: false });

    if (error) {
      console.error('Error fetching eligible students:', error);
      return res.status(500).json({ error: 'Failed to fetch eligible students' });
    }

    // Remove duplicates and return unique students
    const uniqueStudents = [];
    const seenStudentIds = new Set();

    for (const consultation of consultations) {
      if (consultation.student && !seenStudentIds.has(consultation.student.id)) {
        seenStudentIds.add(consultation.student.id);
        uniqueStudents.push(consultation.student);
      }
    }

    return res.json({
      success: true,
      students: uniqueStudents
    });

  } catch (err) {
    console.error('Error fetching eligible students:', err);
    return res.status(500).json({ 
      error: 'Failed to fetch eligible students',
      message: err.message 
    });
  }
});

/**
 * POST /api/followup/schedule
 * Schedule a follow-up consultation
 * Room will be created on the day of consultation, not immediately
 * Now supports flexible scheduling - creates availability automatically if needed
 */
router.post('/schedule', authenticateUser, requireRole('counselor', 'admin'), async (req, res) => {
  try {
    const { studentId, date, time, duration = 60 } = req.body;
    const counselorId = req.user.id;

    if (!studentId || !date || !time) {
      return res.status(400).json({ 
        error: 'Student ID, date, and time are required' 
      });
    }

    // Validate date is in the future
    const selectedDateTime = new Date(`${date}T${time}`);
    const now = new Date();
    if (selectedDateTime <= now) {
      return res.status(400).json({
        error: 'Cannot schedule consultations in the past'
      });
    }

    // Check for conflicting consultations at the same time
    const { data: conflicts, error: conflictError } = await supabase
      .from('consultations')
      .select('id')
      .eq('counselor_id', counselorId)
      .eq('date', date)
      .eq('time', time)
      .in('status', ['pending', 'accepted']);

    if (conflictError) {
      console.error('Error checking conflicts:', conflictError);
    }

    if (conflicts && conflicts.length > 0) {
      return res.status(400).json({
        error: 'You already have a consultation scheduled at this time'
      });
    }

    // Calculate end time based on duration
    const [hours, minutes] = time.split(':').map(Number);
    const totalMinutes = hours * 60 + minutes + duration;
    const endHours = Math.floor(totalMinutes / 60) % 24;
    const endMinutes = totalMinutes % 60;
    const endTime = `${String(endHours).padStart(2, '0')}:${String(endMinutes).padStart(2, '0')}:00`;

    // Check if there's existing availability at this time
    let availability = null;
    const { data: existingAvail, error: availCheckError } = await supabase
      .from('availability')
      .select('*')
      .eq('counselor_id', counselorId)
      .eq('date', date)
      .eq('start_time', time)
      .eq('is_booked', false)
      .maybeSingle();

    if (existingAvail) {
      availability = existingAvail;
      console.log('✅ Using existing availability slot');
    } else {
      // Create new availability slot for this follow-up
      const { data: newAvail, error: createAvailError } = await supabase
        .from('availability')
        .insert({
          counselor_id: counselorId,
          date: date,
          start_time: time,
          end_time: endTime,
          is_booked: false
        })
        .select()
        .single();

      if (createAvailError) {
        console.error('Error creating availability:', createAvailError);
        return res.status(500).json({
          error: 'Failed to create availability slot',
          message: createAvailError.message
        });
      }

      availability = newAvail;
      console.log('✅ Created new availability slot for follow-up');
    }

    // Get student and counselor details for email
    const { data: student, error: studentError } = await supabase
      .from('users')
      .select('name, email')
      .eq('id', studentId)
      .single();

    const { data: counselor, error: counselorError } = await supabase
      .from('users')
      .select('name, email')
      .eq('id', counselorId)
      .single();

    if (studentError || counselorError) {
      return res.status(500).json({ error: 'Failed to fetch user details' });
    }

    // Create the follow-up consultation record
    // Status is 'accepted' since counselor is initiating it
    // video_link will be null initially and created on the day of consultation
    const { data: consultation, error: insertError } = await supabase
      .from('consultations')
      .insert({
        student_id: studentId,
        counselor_id: counselorId,
        date: date,
        time: time,
        status: 'accepted',
        is_followup: true,
        availability_id: availability.id,
        video_link: null // Will be created on consultation day
      })
      .select()
      .single();

    if (insertError) {
      console.error('Error creating follow-up consultation:', insertError);
      // Rollback: delete the created availability if consultation creation fails
      if (availability && !existingAvail) {
        await supabase.from('availability').delete().eq('id', availability.id);
      }
      return res.status(500).json({ 
        error: 'Failed to schedule follow-up',
        message: insertError.message 
      });
    }

    // Mark the availability slot as booked
    const { error: updateAvailError } = await supabase
      .from('availability')
      .update({ is_booked: true })
      .eq('id', availability.id);

    if (updateAvailError) {
      console.error('Error updating availability:', updateAvailError);
      // Don't fail the request, but log it
    }

    console.log(`✅ Follow-up consultation scheduled: ${consultation.id}`);

    // Send notification emails to both student and counselor
    try {
      const studentName = student.name || student.email.split('@')[0];
      const counselorName = counselor.name || counselor.email.split('@')[0];

      await sendFollowUpNotification(
        student.email,
        counselor.email,
        studentName,
        counselorName,
        date,
        time
      );

      console.log('✅ Follow-up notification emails sent');
    } catch (emailErr) {
      console.error('⚠️ Failed to send follow-up emails (non-critical):', emailErr);
      // Don't fail the request if email fails
    }

    return res.json({
      success: true,
      consultation: consultation,
      message: 'Follow-up consultation scheduled successfully'
    });

  } catch (err) {
    console.error('Error scheduling follow-up:', err);
    return res.status(500).json({ 
      error: 'Failed to schedule follow-up',
      message: err.message 
    });
  }
});

/**
 * POST /api/followup/create-rooms
 * Create rooms for follow-up consultations scheduled for today
 * This should be called by a scheduled job (cron) or manually
 */
router.post('/create-rooms', authenticateUser, requireRole('admin'), async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];

    // Get all follow-up consultations for today that don't have a room yet
    const { data: consultations, error } = await supabase
      .from('consultations')
      .select(`
        *,
        counselor:counselor_id(name, email),
        student:student_id(name, email)
      `)
      .eq('date', today)
      .eq('is_followup', true)
      .eq('status', 'accepted')
      .is('video_link', null);

    if (error) {
      console.error('Error fetching follow-up consultations:', error);
      return res.status(500).json({ error: 'Failed to fetch consultations' });
    }

    if (!consultations || consultations.length === 0) {
      return res.json({
        success: true,
        message: 'No follow-up consultations need rooms today',
        created: 0
      });
    }

    const results = [];
    const DAILY_API_KEY = process.env.DAILY_API_KEY;

    for (const consultation of consultations) {
      try {
        // Create unique room name
        const roomName = `hinahon-followup-${consultation.id.slice(0, 8)}-${Date.now()}`;

        // Call Daily.co API to create room
        const dailyResponse = await fetch('https://api.daily.co/v1/rooms', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${DAILY_API_KEY}`
          },
          body: JSON.stringify({
            name: roomName,
            properties: {
              enable_screenshare: true,
              enable_chat: true,
              start_video_off: false,
              start_audio_off: false,
              max_participants: 2,
              // Room expires 24 hours from now
              exp: Math.floor(Date.now() / 1000) + (24 * 60 * 60),
              enable_prejoin_ui: true,
            }
          })
        });

        if (!dailyResponse.ok) {
          const errorText = await dailyResponse.text();
          console.error(`Daily.co API error for consultation ${consultation.id}:`, errorText);
          results.push({
            consultationId: consultation.id,
            success: false,
            error: `Daily.co API error: ${dailyResponse.status}`
          });
          continue;
        }

        const roomData = await dailyResponse.json();

        // Update consultation with video link
        const { error: updateError } = await supabase
          .from('consultations')
          .update({ video_link: roomData.url })
          .eq('id', consultation.id);

        if (updateError) {
          console.error(`Error updating consultation ${consultation.id}:`, updateError);
          results.push({
            consultationId: consultation.id,
            success: false,
            error: 'Failed to save video link'
          });
          continue;
        }

        console.log(`✅ Created room for follow-up consultation: ${consultation.id}`);

        // Send room link emails to both parties
        const { sendAcceptanceNotification, sendCounselorAcceptanceNotification } = require('../utils/emailService');
        
        const studentName = consultation.student?.name || consultation.student?.email?.split('@')[0] || 'Student';
        const counselorName = consultation.counselor?.name || consultation.counselor?.email?.split('@')[0] || 'Counselor';

        try {
          await sendAcceptanceNotification(
            consultation.student.email,
            studentName,
            counselorName,
            consultation.date,
            consultation.time,
            roomData.url
          );

          // Wait 2 seconds before sending counselor email
          await new Promise(resolve => setTimeout(resolve, 2000));

          await sendCounselorAcceptanceNotification(
            consultation.counselor.email,
            counselorName,
            studentName,
            consultation.student.email,
            consultation.date,
            consultation.time,
            roomData.url
          );

          console.log('✅ Room link emails sent for follow-up consultation');
        } catch (emailErr) {
          console.error('⚠️ Failed to send room link emails:', emailErr);
        }

        results.push({
          consultationId: consultation.id,
          success: true,
          roomUrl: roomData.url
        });

      } catch (err) {
        console.error(`Error processing consultation ${consultation.id}:`, err);
        results.push({
          consultationId: consultation.id,
          success: false,
          error: err.message
        });
      }
    }

    const successCount = results.filter(r => r.success).length;

    return res.json({
      success: true,
      message: `Created ${successCount} out of ${results.length} rooms`,
      created: successCount,
      total: results.length,
      results: results
    });

  } catch (err) {
    console.error('Error creating follow-up rooms:', err);
    return res.status(500).json({ 
      error: 'Failed to create rooms',
      message: err.message 
    });
  }
});

module.exports = router;