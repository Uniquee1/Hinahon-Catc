import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "../supabaseClient";
import { acceptConsultationWithRoom, rejectConsultation } from "../utils/dailyApi";
import { checkVideoLinkAccess, getConsultationStatusBadge } from "../utils/consultationTimeUtils";
import "../styles.css";

export default function CounselorPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("requests");
  const [consultations, setConsultations] = useState([]);
  const [history, setHistory] = useState([]);
  const [availability, setAvailability] = useState([]);
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState(null);
  const [user, setUser] = useState(null);
  const [showNotesModal, setShowNotesModal] = useState(false);
  const [selectedConsultation, setSelectedConsultation] = useState(null);
  const [counselorNotes, setCounselorNotes] = useState("");

  // Filter states for history table
  const [departmentFilter, setDepartmentFilter] = useState("all");
  const [yearLevelFilter, setYearLevelFilter] = useState("all");
  const [studentNameSearch, setStudentNameSearch] = useState("");

  // Calendar and availability state
  const [selectedDate, setSelectedDate] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");

  useEffect(() => {
    getCurrentUser();
    fetchConsultations();
    fetchHistory();
    fetchAvailability();
  }, []);

  const getCurrentUser = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    setUser(user);
    setLoading(false);
  };

  const fetchConsultations = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from("consultations")
        .select(`
          id,
          date,
          time,
          status,
          video_link,
          student_id,
          availability_id,
          reason,
          counselor_notes,
          meeting_ended
        `)
        .eq("counselor_id", user.id)
        .eq("status", "pending")
        .order("date", { ascending: true });

      if (error) throw error;

      const studentIds = [...new Set((data || []).map(c => c.student_id))];

      const { data: studentsData, error: studentsError } = await supabase
        .from("users")
        .select("id, name, email, department, program, year_level")
        .in("id", studentIds);

      if (studentsError) {
        console.error("Error fetching students (RLS policy issue?):", studentsError);
      }

      const studentMap = {};
      (studentsData || []).forEach(student => {
        studentMap[student.id] = {
          name: student.name || student.email?.split('@')[0] || 'Student',
          email: student.email || 'No email',
          department: student.department,
          program: student.program,
          year_level: student.year_level
        };
      });

      const consultationsWithStudents = (data || []).map(consultation => ({
        ...consultation,
        student: studentMap[consultation.student_id] || {
          name: 'Student',
          email: 'Email hidden',
          department: null,
          program: null,
          year_level: null
        }
      }));
      
      setConsultations(consultationsWithStudents);
    } catch (err) {
      console.error("Error fetching consultations:", err);
    }
  };

  const fetchHistory = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from("consultations")
        .select(`
          id,
          date,
          time,
          status,
          video_link,
          student_id,
          availability_id,
          reason,
          rejection_reason,
          counselor_notes,
          meeting_ended
        `)
        .eq("counselor_id", user.id)
        .in("status", ["accepted", "rejected", "completed"])
        .order("date", { ascending: false });

      if (error) throw error;

      const studentIds = [...new Set((data || []).map(c => c.student_id))];

      const { data: studentsData, error: studentsError } = await supabase
        .from("users")
        .select("id, name, email, department, program, year_level")
        .in("id", studentIds);

      if (studentsError) {
        console.error("Error fetching students:", studentsError);
      }

      const studentMap = {};
      (studentsData || []).forEach(student => {
        studentMap[student.id] = {
          name: student.name || student.email?.split('@')[0] || 'Student',
          email: student.email || 'No email',
          department: student.department,
          program: student.program,
          year_level: student.year_level
        };
      });

      const historyWithStudents = (data || []).map(consultation => ({
        ...consultation,
        student: studentMap[consultation.student_id] || {
          name: 'Student',
          email: 'Email hidden',
          department: null,
          program: null,
          year_level: null
        }
      }));
      
      setHistory(historyWithStudents);
    } catch (err) {
      console.error("Error fetching history:", err);
    }
  };

  const fetchAvailability = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from("availability")
        .select("*")
        .eq("counselor_id", user.id)
        .gte("date", new Date().toISOString().split('T')[0])
        .order("date", { ascending: true })
        .order("start_time", { ascending: true });

      if (error) throw error;
      setAvailability(data || []);
    } catch (err) {
      console.error("Error fetching availability:", err);
    }
  };

  const addAvailability = async (e) => {
    e.preventDefault();
    
    if (!selectedDate || !startTime || !endTime) {
      alert("Please fill in all fields");
      return;
    }

    if (startTime >= endTime) {
      alert("End time must be after start time");
      return;
    }

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from("availability")
        .insert({
          counselor_id: user.id,
          date: selectedDate,
          start_time: startTime,
          end_time: endTime,
          is_booked: false
        });

      if (error) {
        if (error.code === '23505') {
          alert("This time slot already exists.");
          return;
        }
        throw error;
      }

      setSelectedDate("");
      setStartTime("");
      setEndTime("");
      fetchAvailability();
      alert("Time slot added successfully!");
      
    } catch (err) {
      console.error("Error adding availability:", err);
      alert("Failed to add availability: " + err.message);
    }
  };

  const deleteAvailabilitySlot = async (slotId) => {
    if (!window.confirm("Are you sure you want to delete this time slot?")) {
      return;
    }

    try {
      const { error } = await supabase
        .from("availability")
        .delete()
        .eq("id", slotId);

      if (error) throw error;
      fetchAvailability();
      alert("Time slot deleted successfully!");
    } catch (err) {
      console.error("Error deleting availability:", err);
      alert("Failed to delete time slot.");
    }
  };

  const handleAccept = async (consultationId) => {
    if (!window.confirm('Accept this consultation and create video room?')) {
      return;
    }

    setProcessingId(consultationId);
    
    try {
      const { data: currentConsultation, error: fetchError } = await supabase
        .from('consultations')
        .select('id, date, time, counselor_id, availability_id')
        .eq('id', consultationId)
        .single();

      if (fetchError || !currentConsultation) {
        throw new Error('Failed to fetch consultation details');
      }

      console.log('📅 Accepting consultation:', currentConsultation);

      const { data: overlappingConsultations, error: overlapError } = await supabase
        .from('consultations')
        .select('id, student_id, student:student_id(name, email)')
        .eq('counselor_id', currentConsultation.counselor_id)
        .eq('date', currentConsultation.date)
        .eq('time', currentConsultation.time)
        .eq('status', 'pending')
        .neq('id', consultationId);

      if (overlapError) {
        console.error('Error finding overlapping consultations:', overlapError);
      }

      console.log(`Found ${overlappingConsultations?.length || 0} overlapping consultations to reject`);

      const result = await acceptConsultationWithRoom(consultationId);
      
      if (!result.success) {
        alert(`❌ Error: ${result.error}`);
        setProcessingId(null);
        return;
      }

      console.log('✅ Consultation accepted and room created');

      if (currentConsultation.availability_id) {
        const { error: availabilityError } = await supabase
          .from('availability')
          .update({ is_booked: true })
          .eq('id', currentConsultation.availability_id);

        if (availabilityError) {
          console.error('⚠️ Warning: Failed to mark slot as booked:', availabilityError);
        } else {
          console.log('✅ Availability slot marked as booked');
        }
      }

      if (overlappingConsultations && overlappingConsultations.length > 0) {
        console.log(`🔄 Rejecting ${overlappingConsultations.length} overlapping bookings...`);

        const rejectionReason = `This time slot has been booked by another student. The counselor has already accepted a consultation for ${currentConsultation.date} at ${currentConsultation.time}.`;

        const { error: bulkRejectError } = await supabase
          .from('consultations')
          .update({ 
            status: 'rejected',
            rejection_reason: rejectionReason,
            video_link: null
          })
          .in('id', overlappingConsultations.map(c => c.id));

        if (bulkRejectError) {
          console.error('⚠️ Warning: Failed to auto-reject overlapping consultations:', bulkRejectError);
        } else {
          console.log(`✅ Successfully rejected ${overlappingConsultations.length} overlapping consultations`);
        }
      }

      await fetchConsultations();
      await fetchHistory();
      await fetchAvailability();

      alert(`✅ Consultation accepted!\n\nVideo room created: ${result.roomUrl}\n\nThe student will receive this link via email.${overlappingConsultations?.length > 0 ? `\n\n${overlappingConsultations.length} overlapping booking(s) have been automatically rejected.` : ''}`);

    } catch (err) {
      console.error('❌ Error accepting consultation:', err);
      alert('Failed to accept consultation: ' + err.message);
    } finally {
      setProcessingId(null);
    }
  };

  const handleReject = async (consultationId) => {
    const reason = window.prompt('Enter rejection reason (optional):');
    
    if (reason === null) return;

    setProcessingId(consultationId);
    
    try {
      const result = await rejectConsultation(consultationId, reason);
      
      if (result.success) {
        alert('✅ Consultation rejected');
        await fetchConsultations();
        await fetchHistory();
      } else {
        alert(`❌ Error: ${result.error}`);
      }
    } catch (err) {
      console.error('Error rejecting consultation:', err);
      alert('Failed to reject consultation');
    } finally {
      setProcessingId(null);
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate("/");
  };

  const handleEndMeeting = async (consultationId) => {
    if (!window.confirm('Are you sure you want to end this meeting? This will close the video room for both you and the student.')) {
      return;
    }

    setProcessingId(consultationId);
    
    try {
      const { error: updateError } = await supabase
        .from('consultations')
        .update({ 
          status: 'completed',
          meeting_ended: true,
          video_link: null
        })
        .eq('id', consultationId);

      if (updateError) {
        throw updateError;
      }

      alert('✅ Meeting ended successfully!');
      await fetchConsultations();
      await fetchHistory();
    } catch (err) {
      console.error('❌ Error ending meeting:', err);
      alert('Failed to end meeting: ' + err.message);
    } finally {
      setProcessingId(null);
    }
  };

  const openNotesModal = (consultation) => {
    setSelectedConsultation(consultation);
    setCounselorNotes(consultation.counselor_notes || '');
    setShowNotesModal(true);
  };

  const closeNotesModal = () => {
    setShowNotesModal(false);
    setSelectedConsultation(null);
    setCounselorNotes('');
  };

  const handleSaveNotes = async () => {
    if (!selectedConsultation) return;

    try {
      const { error } = await supabase
        .from('consultations')
        .update({ 
          counselor_notes: counselorNotes
        })
        .eq('id', selectedConsultation.id);

      if (error) throw error;

      alert('✅ Notes saved successfully!');
      closeNotesModal();
      await fetchConsultations();
      await fetchHistory();
    } catch (err) {
      console.error('Error saving notes:', err);
      alert('Failed to save notes: ' + err.message);
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric"
    });
  };

  const formatTime = (timeString) => {
    return new Date(`2000-01-01T${timeString}`).toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true
    });
  };

  const getStatusBadgeStyle = (status, date, time) => {
    const badgeInfo = getConsultationStatusBadge(status, date, time);
    return {
      padding: "4px 12px",
      borderRadius: "12px",
      fontSize: "12px",
      fontWeight: "600",
      textTransform: "uppercase",
      backgroundColor: badgeInfo.bg,
      color: badgeInfo.color
    };
  };

  const getMinDate = () => {
    return new Date().toISOString().split('T')[0];
  };

  const getMaxDate = () => {
    const maxDate = new Date();
    maxDate.setMonth(maxDate.getMonth() + 3);
    return maxDate.toISOString().split('T')[0];
  };

  const groupedAvailability = availability.reduce((acc, slot) => {
    const date = slot.date;
    if (!acc[date]) {
      acc[date] = [];
    }
    acc[date].push(slot);
    return acc;
  }, {});

  // Filter and separate history
  const filteredHistory = history.filter(consultation => {
    const matchesDepartment = departmentFilter === 'all' || consultation.student?.department === departmentFilter;
    const matchesYearLevel = yearLevelFilter === 'all' || consultation.student?.year_level === parseInt(yearLevelFilter);
    const matchesName = studentNameSearch === '' || 
      (consultation.student?.name && consultation.student.name.toLowerCase().includes(studentNameSearch.toLowerCase())) ||
      (consultation.student?.email && consultation.student.email.toLowerCase().includes(studentNameSearch.toLowerCase()));
    return matchesDepartment && matchesYearLevel && matchesName;
  });

  // Helper function to check if consultation is still active (can access video)
  const isConsultationActive = (consultation) => {
    if (consultation.meeting_ended) return false;
    if (!consultation.video_link) return false;
    
    // Check if the consultation is in the future or currently happening
    const consultationDateTime = new Date(`${consultation.date}T${consultation.time}`);
    const now = new Date();
    
    // Add 1 hour buffer after the scheduled time for the session to be considered "ongoing"
    const endTime = new Date(consultationDateTime.getTime() + (1 * 60 * 60 * 1000));
    
    // Consider it active if we're within 10 minutes before to 1 hour after
    const startBuffer = new Date(consultationDateTime.getTime() - (10 * 60 * 1000));
    
    return now >= startBuffer && now <= endTime;
  };

  // Helper function to check if consultation is scheduled (future)
  const isConsultationScheduled = (consultation) => {
    if (consultation.meeting_ended) return false;
    if (!consultation.video_link) return false;
    
    const consultationDateTime = new Date(`${consultation.date}T${consultation.time}`);
    const now = new Date();
    
    // Scheduled means it's in the future (more than 10 minutes away)
    const startBuffer = new Date(consultationDateTime.getTime() - (10 * 60 * 1000));
    
    return now < startBuffer;
  };

  // Helper function to check if consultation has expired
  const isConsultationExpired = (consultation) => {
    if (consultation.meeting_ended) return true;
    if (!consultation.video_link) return true;
    
    const consultationDateTime = new Date(`${consultation.date}T${consultation.time}`);
    const now = new Date();
    
    // Expired means it's more than 1 hour past the scheduled time
    const endTime = new Date(consultationDateTime.getTime() + (1 * 60 * 60 * 1000));
    
    return now > endTime;
  };

  // Separate ongoing from completed/rejected
  // Ongoing/Scheduled: accepted consultations that are scheduled or active (not expired)
  // Completed: completed status, rejected status, or accepted but expired
  const ongoingConsultations = filteredHistory.filter(c => {
    if (c.status !== 'accepted') return false;
    return !isConsultationExpired(c);
  });
  
  const completedRejectedConsultations = filteredHistory.filter(c => {
    if (c.status === 'completed' || c.status === 'rejected') return true;
    if (c.status === 'accepted') {
      return isConsultationExpired(c);
    }
    return false;
  });

  // Get unique departments and year levels for filters
  const departments = [...new Set(history.map(c => c.student?.department).filter(Boolean))];
  const yearLevels = [...new Set(history.map(c => c.student?.year_level).filter(Boolean))];

  if (loading) {
    return (
      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        height: '100vh' 
      }}>
        <div className="text-center">
          <div style={{
            width: '48px',
            height: '48px',
            border: '4px solid #f3f3f3',
            borderTop: '4px solid var(--pink)',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite',
            margin: '0 auto 16px'
          }}></div>
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="landing-root">
      <header className="landing-header">
        <div className="header-left">
          <div className="logo-top">Hinahon</div>
          <div className="tagline-mini">Counselor Dashboard</div>
        </div>
        <div className="header-right">
          <span style={{ color: "#666", fontSize: "14px", marginRight: "16px" }}>
            {user?.email}
          </span>
          <button className="btn-logout" onClick={handleSignOut}>
            Sign Out
          </button>
        </div>
      </header>

      <main style={{ padding: "40px 24px", maxWidth: "1200px", margin: "0 auto" }}>
        <div style={{ 
          display: "flex", 
          marginBottom: "32px", 
          borderBottom: "1px solid #e0e0e0" 
        }}>
          <button
            onClick={() => setActiveTab("requests")}
            style={{
              padding: "12px 24px",
              border: "none",
              background: "none",
              cursor: "pointer",
              borderBottom: activeTab === "requests" ? "3px solid var(--teal)" : "none",
              color: activeTab === "requests" ? "var(--teal)" : "#666",
              fontWeight: activeTab === "requests" ? "600" : "400",
              fontSize: "16px"
            }}
          >
            Consultation Requests
            {consultations.length > 0 && (
              <span style={{
                marginLeft: "8px",
                backgroundColor: "var(--pink)",
                color: "white",
                padding: "2px 8px",
                borderRadius: "12px",
                fontSize: "12px",
                fontWeight: "700"
              }}>
                {consultations.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab("history")}
            style={{
              padding: "12px 24px",
              border: "none",
              background: "none",
              cursor: "pointer",
              borderBottom: activeTab === "history" ? "3px solid var(--teal)" : "none",
              color: activeTab === "history" ? "var(--teal)" : "#666",
              fontWeight: activeTab === "history" ? "600" : "400",
              fontSize: "16px"
            }}
          >
            Consultation History
          </button>
          <button
            onClick={() => setActiveTab("calendar")}
            style={{
              padding: "12px 24px",
              border: "none",
              background: "none",
              cursor: "pointer",
              borderBottom: activeTab === "calendar" ? "3px solid var(--teal)" : "none",
              color: activeTab === "calendar" ? "var(--teal)" : "#666",
              fontWeight: activeTab === "calendar" ? "600" : "400",
              fontSize: "16px"
            }}
          >
            Calendar & Availability
          </button>
        </div>

        {/* REQUESTS TAB */}
        {activeTab === "requests" && (
          <div>
            <h2 style={{ color: "var(--pink)", marginBottom: "24px" }}>
              Pending Consultation Requests
            </h2>
            
            {consultations.length === 0 ? (
              <div style={{ 
                textAlign: "center", 
                padding: "40px", 
                backgroundColor: "#f9f9f9", 
                borderRadius: "12px" 
              }}>
                <p style={{ color: "#666", fontSize: "16px" }}>
                  No pending consultation requests.
                </p>
              </div>
            ) : (
              <div style={{ display: "grid", gap: "16px" }}>
                {consultations.map((consultation) => (
                  <div
                    key={consultation.id}
                    style={{
                      backgroundColor: "white",
                      padding: "24px",
                      borderRadius: "12px",
                      boxShadow: "var(--card-shadow)",
                      border: "1px solid #f0f0f0",
                      borderLeft: "4px solid var(--teal)"
                    }}
                  >
                    <div style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "flex-start",
                      marginBottom: "16px"
                    }}>
                      <div style={{ flex: 1 }}>
                        <h3 style={{ margin: "0 0 8px 0", color: "var(--text)" }}>
                          👤 {consultation.student?.name || "Student"}
                        </h3>
                        <p style={{ margin: "0 0 12px 0", color: "#888", fontSize: "13px" }}>
                          {consultation.student?.email}
                        </p>

                        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px", marginBottom: "16px" }}>
                          <p style={{ margin: "0", color: "#666" }}>
                            📅 {formatDate(consultation.date)}
                          </p>
                          <p style={{ margin: "0", color: "#666" }}>
                            🕐 {formatTime(consultation.time)}
                          </p>
                        </div>

                        <div style={{
                          backgroundColor: "#f8f9fa",
                          padding: "12px",
                          borderRadius: "8px",
                          marginBottom: "12px"
                        }}>
                          <h4 style={{ margin: "0 0 8px 0", fontSize: "13px", fontWeight: "600", color: "#555" }}>
                            Student Information
                          </h4>
                          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "12px" }}>
                            <div>
                              <p style={{ margin: "0 0 4px 0", fontSize: "11px", color: "#888" }}>Department</p>
                              <p style={{ margin: "0", fontSize: "14px", fontWeight: "600", color: "#333" }}>
                                {consultation.student?.department || 'Not specified'}
                              </p>
                            </div>
                            <div>
                              <p style={{ margin: "0 0 4px 0", fontSize: "11px", color: "#888" }}>Program</p>
                              <p style={{ margin: "0", fontSize: "14px", fontWeight: "600", color: "#333" }}>
                                {consultation.student?.program || 'Not specified'}
                              </p>
                            </div>
                            <div>
                              <p style={{ margin: "0 0 4px 0", fontSize: "11px", color: "#888" }}>Year Level</p>
                              <p style={{ margin: "0", fontSize: "14px", fontWeight: "600", color: "#333" }}>
                                {consultation.student?.year_level || 'Not specified'}
                              </p>
                            </div>
                          </div>
                        </div>

                        {consultation.reason && (
                          <div style={{
                            backgroundColor: "#fff9e6",
                            padding: "12px",
                            borderRadius: "8px",
                            marginBottom: "12px"
                          }}>
                            <p style={{ margin: "0 0 4px 0", fontSize: "13px", fontWeight: "600", color: "#555" }}>
                              Reason for Consultation:
                            </p>
                            <p style={{ margin: "0", fontSize: "14px", color: "#666" }}>
                              {consultation.reason}
                            </p>
                          </div>
                        )}
                      </div>
                      <div style={getStatusBadgeStyle(consultation.status, consultation.date, consultation.time)}>
                        {getConsultationStatusBadge(consultation.status, consultation.date, consultation.time).text}
                      </div>
                    </div>

                    <div style={{ display: "flex", gap: "12px", marginTop: "16px" }}>
                      <button
                        onClick={() => handleAccept(consultation.id)}
                        disabled={processingId === consultation.id}
                        className="btn-action primary"
                        style={{
                          opacity: processingId === consultation.id ? 0.6 : 1,
                          cursor: processingId === consultation.id ? 'not-allowed' : 'pointer'
                        }}
                      >
                        {processingId === consultation.id ? '⏳ Processing...' : '✓ Accept'}
                      </button>
                      <button
                        onClick={() => handleReject(consultation.id)}
                        disabled={processingId === consultation.id}
                        style={{
                          padding: "8px 16px",
                          backgroundColor: "#dc3545",
                          color: "white",
                          border: "none",
                          borderRadius: "6px",
                          cursor: processingId === consultation.id ? 'not-allowed' : 'pointer',
                          fontWeight: "600",
                          opacity: processingId === consultation.id ? 0.6 : 1
                        }}
                      >
                        ✕ Reject
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* HISTORY TAB - REFACTORED */}
        {activeTab === "history" && (
          <div>
            <h2 style={{ color: "var(--pink)", marginBottom: "24px" }}>
              Consultation History
            </h2>

            {/* Filters */}
            {history.length > 0 && (
              <div style={{
                backgroundColor: "white",
                padding: "20px",
                borderRadius: "12px",
                boxShadow: "var(--card-shadow)",
                marginBottom: "24px"
              }}>
                <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr", gap: "16px", marginBottom: "16px" }}>
                  <div>
                    <label style={{ display: "block", marginBottom: "8px", fontWeight: "600", fontSize: "14px" }}>
                      Search by Student Name
                    </label>
                    <input
                      type="text"
                      value={studentNameSearch}
                      onChange={(e) => setStudentNameSearch(e.target.value)}
                      placeholder="Type student name or email..."
                      style={{
                        width: "100%",
                        padding: "10px 12px",
                        borderRadius: "8px",
                        border: "1px solid #e0e0e0",
                        fontSize: "14px"
                      }}
                    />
                  </div>
                  <div>
                    <label style={{ display: "block", marginBottom: "8px", fontWeight: "600", fontSize: "14px" }}>
                      Filter by Department
                    </label>
                    <select
                      value={departmentFilter}
                      onChange={(e) => setDepartmentFilter(e.target.value)}
                      style={{
                        width: "100%",
                        padding: "10px",
                        borderRadius: "8px",
                        border: "1px solid #e0e0e0",
                        fontSize: "14px"
                      }}
                    >
                      <option value="all">All Departments</option>
                      {departments.map(dept => (
                        <option key={dept} value={dept}>{dept}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label style={{ display: "block", marginBottom: "8px", fontWeight: "600", fontSize: "14px" }}>
                      Filter by Year Level
                    </label>
                    <select
                      value={yearLevelFilter}
                      onChange={(e) => setYearLevelFilter(e.target.value)}
                      style={{
                        width: "100%",
                        padding: "10px",
                        borderRadius: "8px",
                        border: "1px solid #e0e0e0",
                        fontSize: "14px"
                      }}
                    >
                      <option value="all">All Year Levels</option>
                      {yearLevels.map(year => (
                        <option key={year} value={year}>
                          {year === 1 ? '1st Year' : 
                           year === 2 ? '2nd Year' : 
                           year === 3 ? '3rd Year' : 
                           year === 4 ? '4th Year' : 
                           year === 5 ? '5th Year' : 
                           'Graduate Level'}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                {(studentNameSearch || departmentFilter !== 'all' || yearLevelFilter !== 'all') && (
                  <button
                    onClick={() => {
                      setStudentNameSearch('');
                      setDepartmentFilter('all');
                      setYearLevelFilter('all');
                    }}
                    style={{
                      padding: "8px 16px",
                      backgroundColor: "#f0f0f0",
                      color: "#666",
                      border: "none",
                      borderRadius: "6px",
                      cursor: "pointer",
                      fontSize: "13px",
                      fontWeight: "600"
                    }}
                  >
                    Clear All Filters
                  </button>
                )}
              </div>
            )}

            {filteredHistory.length === 0 ? (
              <div style={{ 
                textAlign: "center", 
                padding: "40px", 
                backgroundColor: "#f9f9f9", 
                borderRadius: "12px" 
              }}>
                <p style={{ color: "#666", fontSize: "16px" }}>
                  No consultation history matching your filters.
                </p>
              </div>
            ) : (
              <>
                {/* Ongoing/Scheduled Consultations - Detailed Cards */}
                {ongoingConsultations.length > 0 && (
                  <div style={{ marginBottom: "40px" }}>
                    <h3 style={{ marginBottom: "16px", color: "var(--text)", fontSize: "20px", fontWeight: "600" }}>
                      🟢 Ongoing / Scheduled Consultations
                    </h3>
                    <div style={{ display: "grid", gap: "16px" }}>
                      {ongoingConsultations.map((consultation) => (
                        <div
                          key={consultation.id}
                          style={{
                            backgroundColor: "white",
                            padding: "24px",
                            borderRadius: "12px",
                            boxShadow: "var(--card-shadow)",
                            border: "1px solid #f0f0f0",
                            borderLeft: "4px solid #28a745"
                          }}
                        >
                          <div style={{ 
                            display: "flex", 
                            justifyContent: "space-between", 
                            alignItems: "flex-start",
                            marginBottom: "16px"
                          }}>
                            <div style={{ flex: 1 }}>
                              <h3 style={{ margin: "0 0 8px 0", color: "var(--text)" }}>
                                👤 {consultation.student?.name || "Student"}
                              </h3>
                              <p style={{ margin: "0 0 12px 0", color: "#888", fontSize: "13px" }}>
                                {consultation.student?.email}
                              </p>
                              
                              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px", marginBottom: "16px" }}>
                                <p style={{ margin: "0", color: "#666" }}>
                                  📅 {formatDate(consultation.date)}
                                </p>
                                <p style={{ margin: "0", color: "#666" }}>
                                  🕐 {formatTime(consultation.time)}
                                </p>
                              </div>

                              <div style={{
                                backgroundColor: "#f8f9fa",
                                padding: "12px",
                                borderRadius: "8px",
                                marginBottom: "12px"
                              }}>
                                <h4 style={{ margin: "0 0 8px 0", fontSize: "13px", fontWeight: "600", color: "#555" }}>
                                  Student Information
                                </h4>
                                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "12px" }}>
                                  <div>
                                    <p style={{ margin: "0 0 4px 0", fontSize: "11px", color: "#888" }}>Department</p>
                                    <p style={{ margin: "0", fontSize: "14px", fontWeight: "600", color: "#333" }}>
                                      {consultation.student?.department || 'Not specified'}
                                    </p>
                                  </div>
                                  <div>
                                    <p style={{ margin: "0 0 4px 0", fontSize: "11px", color: "#888" }}>Program</p>
                                    <p style={{ margin: "0", fontSize: "14px", fontWeight: "600", color: "#333" }}>
                                      {consultation.student?.program || 'Not specified'}
                                    </p>
                                  </div>
                                  <div>
                                    <p style={{ margin: "0 0 4px 0", fontSize: "11px", color: "#888" }}>Year Level</p>
                                    <p style={{ margin: "0", fontSize: "14px", fontWeight: "600", color: "#333" }}>
                                      {consultation.student?.year_level || 'Not specified'}
                                    </p>
                                  </div>
                                </div>
                              </div>

                              {consultation.reason && (
                                <div style={{
                                  backgroundColor: "#fff9e6",
                                  padding: "12px",
                                  borderRadius: "8px",
                                  marginBottom: "12px"
                                }}>
                                  <p style={{ margin: "0 0 4px 0", fontSize: "13px", fontWeight: "600", color: "#555" }}>
                                    Reason for Consultation:
                                  </p>
                                  <p style={{ margin: "0", fontSize: "14px", color: "#666" }}>
                                    {consultation.reason}
                                  </p>
                                </div>
                              )}

                              {consultation.counselor_notes && (
                                <div style={{
                                  backgroundColor: "#e8f5e9",
                                  padding: "12px",
                                  borderRadius: "8px",
                                  marginBottom: "12px"
                                }}>
                                  <p style={{ margin: "0 0 4px 0", fontSize: "13px", fontWeight: "600", color: "#2e7d32" }}>
                                    📝 Counselor Notes:
                                  </p>
                                  <p style={{ margin: "0", fontSize: "14px", color: "#666", whiteSpace: "pre-wrap" }}>
                                    {consultation.counselor_notes}
                                  </p>
                                </div>
                              )}
                              
                              {consultation.video_link && !consultation.meeting_ended && (
                                <div style={{ marginTop: "12px" }}>
                                  {isConsultationActive(consultation) ? (
                                    <>
                                      <a 
                                        href={consultation.video_link} 
                                        target="_blank" 
                                        rel="noopener noreferrer"
                                        style={{ 
                                          color: "var(--teal)", 
                                          textDecoration: "underline",
                                          fontWeight: "600",
                                          display: "inline-block"
                                        }}
                                      >
                                        🎥 Join Video Session
                                      </a>
                                      <p style={{ 
                                        margin: "4px 0 0 0", 
                                        fontSize: "12px", 
                                        color: "#28a745",
                                        fontStyle: "italic"
                                      }}>
                                        Session is now available
                                      </p>
                                    </>
                                  ) : isConsultationScheduled(consultation) ? (
                                    <>
                                      <span style={{ 
                                        color: "#856404",
                                        fontSize: "14px",
                                        fontStyle: "italic",
                                        fontWeight: "600"
                                      }}>
                                        📅 Scheduled Session
                                      </span>
                                      <p style={{ 
                                        margin: "4px 0 0 0", 
                                        fontSize: "12px", 
                                        color: "#856404",
                                        fontStyle: "italic"
                                      }}>
                                        Video link will be available 10 minutes before scheduled time
                                      </p>
                                    </>
                                  ) : (
                                    <>
                                      <span style={{ 
                                        color: "#999",
                                        fontSize: "14px",
                                        fontStyle: "italic"
                                      }}>
                                        🎥 Video link unavailable
                                      </span>
                                      <p style={{ 
                                        margin: "4px 0 0 0", 
                                        fontSize: "12px", 
                                        color: "#856404",
                                        fontStyle: "italic"
                                      }}>
                                        Session time has passed
                                      </p>
                                    </>
                                  )}
                                </div>
                              )}
                            </div>
                            <div style={getStatusBadgeStyle(consultation.status, consultation.date, consultation.time)}>
                              {getConsultationStatusBadge(consultation.status, consultation.date, consultation.time).text}
                            </div>
                          </div>

                          {/* Action buttons - only show End Meeting if consultation is currently active */}
                          {consultation.video_link && !consultation.meeting_ended && isConsultationActive(consultation) && (
                            <div style={{ display: "flex", gap: "12px", marginTop: "16px", paddingTop: "16px", borderTop: "1px solid #f0f0f0" }}>
                              <button
                                onClick={() => handleEndMeeting(consultation.id)}
                                disabled={processingId === consultation.id}
                                style={{
                                  flex: 1,
                                  padding: "10px 16px",
                                  backgroundColor: "#ff6b6b",
                                  color: "white",
                                  border: "none",
                                  borderRadius: "6px",
                                  cursor: processingId === consultation.id ? 'not-allowed' : 'pointer',
                                  fontWeight: "600",
                                  opacity: processingId === consultation.id ? 0.6 : 1,
                                  fontSize: "14px"
                                }}
                              >
                                {processingId === consultation.id ? '⏳ Ending...' : '🔴 End Meeting'}
                              </button>
                              <button
                                onClick={() => openNotesModal(consultation)}
                                style={{
                                  flex: 1,
                                  padding: "10px 16px",
                                  backgroundColor: "#4CAF50",
                                  color: "white",
                                  border: "none",
                                  borderRadius: "6px",
                                  cursor: "pointer",
                                  fontWeight: "600",
                                  fontSize: "14px"
                                }}
                              >
                                📝 {consultation.counselor_notes ? 'Edit Notes' : 'Add Notes'}
                              </button>
                            </div>
                          )}

                          {/* Notes button only for scheduled (not yet active) consultations */}
                          {consultation.video_link && !consultation.meeting_ended && isConsultationScheduled(consultation) && (
                            <div style={{ marginTop: "16px", paddingTop: "16px", borderTop: "1px solid #f0f0f0" }}>
                              <button
                                onClick={() => openNotesModal(consultation)}
                                style={{
                                  padding: "10px 16px",
                                  backgroundColor: "#4CAF50",
                                  color: "white",
                                  border: "none",
                                  borderRadius: "6px",
                                  cursor: "pointer",
                                  fontWeight: "600",
                                  fontSize: "14px"
                                }}
                              >
                                📝 {consultation.counselor_notes ? 'Edit Notes' : 'Add Notes'}
                              </button>
                            </div>
                          )}

                          {/* Notes button for consultations without video link or already ended */}
                          {(!consultation.video_link || consultation.meeting_ended) && (
                            <div style={{ marginTop: "16px", paddingTop: "16px", borderTop: "1px solid #f0f0f0" }}>
                              <button
                                onClick={() => openNotesModal(consultation)}
                                style={{
                                  padding: "10px 16px",
                                  backgroundColor: "#4CAF50",
                                  color: "white",
                                  border: "none",
                                  borderRadius: "6px",
                                  cursor: "pointer",
                                  fontWeight: "600",
                                  fontSize: "14px"
                                }}
                              >
                                📝 {consultation.counselor_notes ? 'Edit Notes' : 'Add Notes'}
                              </button>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Completed/Rejected Consultations - Simple Table */}
                {completedRejectedConsultations.length > 0 && (
                  <div>
                    <h3 style={{ marginBottom: "16px", color: "var(--text)", fontSize: "20px", fontWeight: "600" }}>
                      📋 Completed & Rejected Consultations
                    </h3>
                    <div style={{
                      backgroundColor: "white",
                      borderRadius: "12px",
                      boxShadow: "var(--card-shadow)",
                      overflow: "hidden"
                    }}>
                      <div style={{ 
                        overflowY: "auto", 
                        maxHeight: "500px"
                      }}>
                        <table style={{ width: "100%", borderCollapse: "collapse" }}>
                          <thead style={{ 
                            backgroundColor: "#f8f9fa",
                            position: "sticky",
                            top: 0,
                            zIndex: 10
                          }}>
                            <tr>
                              <th style={{ 
                                padding: "16px", 
                                textAlign: "left", 
                                fontSize: "12px", 
                                fontWeight: "700", 
                                color: "#666",
                                textTransform: "uppercase",
                                borderBottom: "2px solid #e0e0e0"
                              }}>
                                Student Name
                              </th>
                              <th style={{ 
                                padding: "16px", 
                                textAlign: "left", 
                                fontSize: "12px", 
                                fontWeight: "700", 
                                color: "#666",
                                textTransform: "uppercase",
                                borderBottom: "2px solid #e0e0e0"
                              }}>
                                Department
                              </th>
                              <th style={{ 
                                padding: "16px", 
                                textAlign: "left", 
                                fontSize: "12px", 
                                fontWeight: "700", 
                                color: "#666",
                                textTransform: "uppercase",
                                borderBottom: "2px solid #e0e0e0"
                              }}>
                                Year Level
                              </th>
                              <th style={{ 
                                padding: "16px", 
                                textAlign: "left", 
                                fontSize: "12px", 
                                fontWeight: "700", 
                                color: "#666",
                                textTransform: "uppercase",
                                borderBottom: "2px solid #e0e0e0"
                              }}>
                                Date & Time
                              </th>
                              <th style={{ 
                                padding: "16px", 
                                textAlign: "left", 
                                fontSize: "12px", 
                                fontWeight: "700", 
                                color: "#666",
                                textTransform: "uppercase",
                                borderBottom: "2px solid #e0e0e0"
                              }}>
                                Status
                              </th>
                              <th style={{ 
                                padding: "16px", 
                                textAlign: "left", 
                                fontSize: "12px", 
                                fontWeight: "700", 
                                color: "#666",
                                textTransform: "uppercase",
                                borderBottom: "2px solid #e0e0e0"
                              }}>
                                Remark / Note
                              </th>
                              <th style={{ 
                                padding: "16px", 
                                textAlign: "center", 
                                fontSize: "12px", 
                                fontWeight: "700", 
                                color: "#666",
                                textTransform: "uppercase",
                                borderBottom: "2px solid #e0e0e0"
                              }}>
                                Actions
                              </th>
                            </tr>
                          </thead>
                          <tbody>
                            {completedRejectedConsultations.map((consultation) => (
                              <tr 
                                key={consultation.id} 
                                style={{ 
                                  borderBottom: "1px solid #f0f0f0",
                                  transition: "background-color 0.2s"
                                }}
                                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = "#f8f9fa"}
                                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "white"}
                              >
                                <td style={{ padding: "16px" }}>
                                  <div>
                                    <div style={{ fontSize: "14px", fontWeight: "600", color: "#333", marginBottom: "4px" }}>
                                      {consultation.student?.name || "Student"}
                                    </div>
                                    <div style={{ fontSize: "13px", color: "#888" }}>
                                      {consultation.student?.email}
                                    </div>
                                  </div>
                                </td>
                                <td style={{ padding: "16px", fontSize: "14px", color: "#333" }}>
                                  {consultation.student?.department || 'Not specified'}
                                </td>
                                <td style={{ padding: "16px", fontSize: "14px", color: "#333" }}>
                                  {consultation.student?.year_level || 'Not specified'}
                                </td>
                                <td style={{ padding: "16px" }}>
                                  <div style={{ fontSize: "14px", color: "#333", marginBottom: "2px" }}>
                                    {formatDate(consultation.date)}
                                  </div>
                                  <div style={{ fontSize: "13px", color: "#888" }}>
                                    {formatTime(consultation.time)}
                                  </div>
                                </td>
                                <td style={{ padding: "16px" }}>
                                  <span style={{
                                    padding: "6px 12px",
                                    borderRadius: "12px",
                                    fontSize: "11px",
                                    fontWeight: "700",
                                    textTransform: "uppercase",
                                    backgroundColor: consultation.status === 'rejected' ? '#ffebee' : '#e3f2fd',
                                    color: consultation.status === 'rejected' ? '#c62828' : '#1976d2',
                                    display: "inline-block"
                                  }}>
                                    {consultation.status === 'rejected' ? '✕ Rejected' : '✓ Completed'}
                                  </span>
                                </td>
                                <td style={{ padding: "16px", fontSize: "14px", color: "#666", maxWidth: "300px" }}>
                                  {consultation.status === 'rejected' && consultation.rejection_reason ? (
                                    <div>
                                      <span style={{ fontWeight: "600", color: "#c62828" }}>Rejection: </span>
                                      {consultation.rejection_reason}
                                    </div>
                                  ) : consultation.counselor_notes ? (
                                    <div>
                                      <span style={{ fontWeight: "600", color: "#2e7d32" }}>Notes: </span>
                                      {consultation.counselor_notes.length > 100 
                                        ? consultation.counselor_notes.substring(0, 100) + '...' 
                                        : consultation.counselor_notes}
                                    </div>
                                  ) : consultation.reason ? (
                                    <div>
                                      <span style={{ fontWeight: "600" }}>Reason: </span>
                                      {consultation.reason.length > 100 
                                        ? consultation.reason.substring(0, 100) + '...' 
                                        : consultation.reason}
                                    </div>
                                  ) : (
                                    <span style={{ fontStyle: "italic", color: "#999" }}>No remarks</span>
                                  )}
                                </td>
                                <td style={{ padding: "16px", textAlign: "center" }}>
                                  <button
                                    onClick={() => openNotesModal(consultation)}
                                    style={{
                                      padding: "8px 16px",
                                      backgroundColor: "#4CAF50",
                                      color: "white",
                                      border: "none",
                                      borderRadius: "6px",
                                      cursor: "pointer",
                                      fontWeight: "600",
                                      fontSize: "13px"
                                    }}
                                  >
                                    📝 {consultation.counselor_notes ? 'Edit' : 'Add'} Notes
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      {completedRejectedConsultations.length > 5 && (
                        <div style={{
                          padding: "12px",
                          backgroundColor: "#f8f9fa",
                          textAlign: "center",
                          fontSize: "13px",
                          color: "#666",
                          borderTop: "1px solid #e0e0e0"
                        }}>
                          Showing {completedRejectedConsultations.length} consultation{completedRejectedConsultations.length !== 1 ? 's' : ''} • Scroll to view more
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {/* CALENDAR TAB */}
        {activeTab === "calendar" && (
          <div>
            <h2 style={{ color: "var(--pink)", marginBottom: "24px" }}>
              Calendar & Availability Management
            </h2>

            <div style={{
              backgroundColor: "white",
              padding: "24px",
              borderRadius: "12px",
              boxShadow: "var(--card-shadow)",
              marginBottom: "32px"
            }}>
              <h3 style={{ marginTop: "0", marginBottom: "20px" }}>
                Add Available Time Slots
              </h3>
              <form onSubmit={addAvailability}>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr auto", gap: "16px", alignItems: "end" }}>
                  <div>
                    <label style={{ display: "block", marginBottom: "8px", fontWeight: "600" }}>
                      Date
                    </label>
                    <input
                      type="date"
                      value={selectedDate}
                      onChange={(e) => setSelectedDate(e.target.value)}
                      min={getMinDate()}
                      max={getMaxDate()}
                      required
                      style={{
                        width: "100%",
                        padding: "12px",
                        borderRadius: "8px",
                        border: "1px solid #e0e0e0",
                        fontSize: "14px"
                      }}
                    />
                  </div>
                  <div>
                    <label style={{ display: "block", marginBottom: "8px", fontWeight: "600" }}>
                      Start Time
                    </label>
                    <input
                      type="time"
                      value={startTime}
                      onChange={(e) => setStartTime(e.target.value)}
                      required
                      style={{
                        width: "100%",
                        padding: "12px",
                        borderRadius: "8px",
                        border: "1px solid #e0e0e0",
                        fontSize: "14px"
                      }}
                    />
                  </div>
                  <div>
                    <label style={{ display: "block", marginBottom: "8px", fontWeight: "600" }}>
                      End Time
                    </label>
                    <input
                      type="time"
                      value={endTime}
                      onChange={(e) => setEndTime(e.target.value)}
                      required
                      style={{
                        width: "100%",
                        padding: "12px",
                        borderRadius: "8px",
                        border: "1px solid #e0e0e0",
                        fontSize: "14px"
                      }}
                    />
                  </div>
                  <button
                    type="submit"
                    className="btn-action primary"
                    style={{ whiteSpace: "nowrap" }}
                  >
                    Add Slot
                  </button>
                </div>
                <p style={{ color: "#666", fontSize: "14px", marginTop: "8px" }}>
                  * Creates a single time slot with the exact start and end time you specify
                </p>
              </form>
            </div>

            <div style={{
              backgroundColor: "white",
              padding: "24px",
              borderRadius: "12px",
              boxShadow: "var(--card-shadow)"
            }}>
              <h3 style={{ marginTop: "0", marginBottom: "20px" }}>
                Your Upcoming Availability
              </h3>
              
              {Object.keys(groupedAvailability).length === 0 ? (
                <p style={{ color: "#666", fontStyle: "italic" }}>
                  No availability set. Add your available dates and times above.
                </p>
              ) : (
                <div style={{ display: "grid", gap: "20px" }}>
                  {Object.entries(groupedAvailability).map(([date, slots]) => (
                    <div key={date} style={{
                      border: "1px solid #e0e0e0",
                      borderRadius: "8px",
                      padding: "16px",
                      backgroundColor: "#f8f9fa"
                    }}>
                      <h4 style={{ margin: "0 0 12px 0", color: "var(--text)" }}>
                        {formatDate(date)}
                      </h4>
                      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: "8px" }}>
                        {slots.map((slot) => (
                          <div
                            key={slot.id}
                            style={{
                              display: "flex",
                              justifyContent: "space-between",
                              alignItems: "center",
                              padding: "8px 12px",
                              backgroundColor: slot.is_booked ? "#ffebee" : "white",
                              borderRadius: "6px",
                              border: "1px solid #e0e0e0"
                            }}
                          >
                            <span style={{ fontSize: "14px" }}>
                              {formatTime(slot.start_time)} - {formatTime(slot.end_time)}
                              {slot.is_booked && <span style={{ color: "#d32f2f", marginLeft: "8px" }}>(Booked)</span>}
                            </span>
                            {!slot.is_booked && (
                              <button
                                onClick={() => deleteAvailabilitySlot(slot.id)}
                                style={{
                                  padding: "4px 8px",
                                  backgroundColor: "#dc3545",
                                  color: "white",
                                  border: "none",
                                  borderRadius: "4px",
                                  cursor: "pointer",
                                  fontSize: "11px"
                                }}
                              >
                                Delete
                              </button>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* Notes Modal */}
      {showNotesModal && (
        <div style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: "rgba(0, 0, 0, 0.5)",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          zIndex: 1000
        }}>
          <div style={{
            backgroundColor: "white",
            borderRadius: "12px",
            padding: "32px",
            maxWidth: "600px",
            width: "90%",
            maxHeight: "80vh",
            overflow: "auto",
            boxShadow: "0 10px 40px rgba(0,0,0,0.3)"
          }}>
            <h3 style={{ marginTop: 0, marginBottom: "8px", color: "var(--text)" }}>
              📝 Counselor Notes
            </h3>
            <p style={{ margin: "0 0 8px 0", fontSize: "14px", color: "#666" }}>
              <strong>Student:</strong> {selectedConsultation?.student?.name}
            </p>
            <p style={{ margin: "0 0 20px 0", fontSize: "14px", color: "#666" }}>
              <strong>Date:</strong> {selectedConsultation ? formatDate(selectedConsultation.date) : ''} at {selectedConsultation ? formatTime(selectedConsultation.time) : ''}
            </p>

            <textarea
              value={counselorNotes}
              onChange={(e) => setCounselorNotes(e.target.value)}
              placeholder="Enter your notes, observations, and recommendations here..."
              style={{
                width: "100%",
                minHeight: "200px",
                padding: "12px",
                borderRadius: "8px",
                border: "1px solid #e0e0e0",
                fontSize: "14px",
                fontFamily: "inherit",
                resize: "vertical",
                marginBottom: "20px",
                boxSizing: "border-box"
              }}
            />

            <p style={{ 
              margin: "0 0 20px 0", 
              fontSize: "12px", 
              color: "#888",
              fontStyle: "italic"
            }}>
              These notes are private and only visible to counselors and admins.
            </p>

            <div style={{ display: "flex", gap: "12px", justifyContent: "flex-end" }}>
              <button
                onClick={closeNotesModal}
                style={{
                  padding: "10px 24px",
                  backgroundColor: "#f0f0f0",
                  color: "#333",
                  border: "none",
                  borderRadius: "6px",
                  cursor: "pointer",
                  fontWeight: "600",
                  fontSize: "14px"
                }}
              >
                Cancel
              </button>
              <button
                onClick={handleSaveNotes}
                style={{
                  padding: "10px 24px",
                  backgroundColor: "var(--teal)",
                  color: "white",
                  border: "none",
                  borderRadius: "6px",
                  cursor: "pointer",
                  fontWeight: "600",
                  fontSize: "14px"
                }}
              >
                💾 Save Notes
              </button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}