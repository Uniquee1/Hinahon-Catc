import { useState, useEffect } from 'react';
import { supabase } from '../supabaseClient';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000';

const AdminFeedbacksTab = () => {
    const [feedbacks, setFeedbacks] = useState([]);
    const [stats, setStats] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    
    // Filter states
    const [timeFilter, setTimeFilter] = useState('all');
    const [ratingFilter, setRatingFilter] = useState('all');

    useEffect(() => {
        console.log('🔍 AdminFeedbacksTab mounted');
        console.log('📍 API_URL:', API_URL);
        fetchFeedbacks();
    }, []);

    const fetchFeedbacks = async () => {
        try {
            setLoading(true);
            setError(null);

            console.log('🔄 Fetching feedbacks...');

            // Get the current session token from Supabase
            const { data: { session } } = await supabase.auth.getSession();
            
            if (!session) {
                throw new Error('You must be logged in to view feedbacks');
            }

            console.log('✅ Session found, making API request...');
            console.log('🔗 Request URL:', `${API_URL}/api/feedback/all`);

            // Fetch feedbacks from your backend API
            const response = await fetch(`${API_URL}/api/feedback/all`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${session.access_token}`
                }
            });

            console.log('📥 Response status:', response.status);

            if (!response.ok) {
                const errorText = await response.text();
                console.error('❌ Response error:', errorText);
                throw new Error(`HTTP ${response.status}: ${errorText}`);
            }

            const data = await response.json();
            console.log('📊 Response data:', data);

            if (!data.success) {
                throw new Error(data.error || 'Failed to load feedbacks');
            }

            console.log(`✅ Loaded ${data.data.length} feedbacks`);
            setFeedbacks(data.data);
            setStats(data.stats);
        } catch (error) {
            console.error('❌ Error fetching feedbacks:', error);
            setError(error.message || 'Failed to load feedbacks');
        } finally {
            setLoading(false);
        }
    };

    // Filter feedbacks based on time and rating
    const getFilteredFeedbacks = () => {
        let filtered = [...feedbacks];
        const now = new Date();

        // Time filter
        if (timeFilter !== 'all') {
            filtered = filtered.filter(feedback => {
                const feedbackDate = new Date(feedback.created_at);
                const diffTime = Math.abs(now - feedbackDate);
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

                switch (timeFilter) {
                    case 'day':
                        return diffDays <= 1;
                    case 'week':
                        return diffDays <= 7;
                    case 'month':
                        return diffDays <= 30;
                    default:
                        return true;
                }
            });
        }

        // Rating filter
        if (ratingFilter !== 'all') {
            filtered = filtered.filter(feedback => 
                feedback.rating === parseInt(ratingFilter)
            );
        }

        return filtered;
    };

    const renderStars = (rating) => {
        return (
            <div style={{ display: 'flex', gap: '2px' }}>
                {[1, 2, 3, 4, 5].map((star) => (
                    <span 
                        key={star}
                        style={{
                            fontSize: '20px',
                            color: star <= rating ? '#ffc107' : '#e0e0e0'
                        }}
                    >
                        ★
                    </span>
                ))}
            </div>
        );
    };

    const formatDate = (dateString) => {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    const resetFilters = () => {
        setTimeFilter('all');
        setRatingFilter('all');
    };

    const filteredFeedbacks = getFilteredFeedbacks();

    if (loading) {
        return (
            <div style={{ 
                display: 'flex', 
                flexDirection: 'column',
                alignItems: 'center', 
                justifyContent: 'center',
                padding: '60px 20px',
                gap: '16px'
            }}>
                <div style={{
                    width: '48px',
                    height: '48px',
                    border: '4px solid #f3f3f3',
                    borderTop: '4px solid #20c997',
                    borderRadius: '50%',
                    animation: 'spin 1s linear infinite'
                }}></div>
                <p style={{ color: '#666', fontSize: '16px' }}>Loading feedbacks...</p>
                <style>{`
                    @keyframes spin {
                        0% { transform: rotate(0deg); }
                        100% { transform: rotate(360deg); }
                    }
                `}</style>
            </div>
        );
    }

    if (error) {
        return (
            <div style={{
                backgroundColor: '#f8d7da',
                color: '#721c24',
                padding: '20px',
                borderRadius: '8px',
                textAlign: 'center'
            }}>
                <p style={{ margin: '0 0 16px 0', fontSize: '16px' }}>Error: {error}</p>
                <button 
                    onClick={fetchFeedbacks}
                    style={{
                        padding: '10px 20px',
                        backgroundColor: '#dc3545',
                        color: 'white',
                        border: 'none',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        fontWeight: '600'
                    }}
                >
                    Retry
                </button>
            </div>
        );
    }

    return (
        <div>
            <div style={{ 
                display: 'flex', 
                justifyContent: 'space-between', 
                alignItems: 'center',
                marginBottom: '24px'
            }}>
                <h2 style={{ color: '#e91e63', margin: 0 }}>Feedbacks</h2>
                <button 
                    onClick={fetchFeedbacks}
                    style={{
                        padding: '10px 20px',
                        backgroundColor: '#20c997',
                        color: 'white',
                        border: 'none',
                        borderRadius: '8px',
                        cursor: 'pointer',
                        fontWeight: '600',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px'
                    }}
                >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="23 4 23 10 17 10"></polyline>
                        <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
                    </svg>
                    Refresh
                </button>
            </div>

            {/* Filter Section */}
            <div style={{
                backgroundColor: 'white',
                padding: '20px',
                borderRadius: '12px',
                boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
                marginBottom: '24px',
                border: '1px solid #f0f0f0'
            }}>
                <h3 style={{ margin: '0 0 16px 0', fontSize: '16px', fontWeight: '600', color: '#333', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="11" cy="11" r="8"></circle>
                        <path d="m21 21-4.35-4.35"></path>
                    </svg>
                    Filter Feedbacks
                </h3>
                
                <div style={{ 
                    display: 'grid', 
                    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
                    gap: '16px',
                    marginBottom: '16px'
                }}>
                    {/* Time Period Filter */}
                    <div>
                        <label style={{ 
                            display: 'block', 
                            marginBottom: '8px', 
                            fontSize: '13px',
                            fontWeight: '600',
                            color: '#666'
                        }}>
                            Time Period
                        </label>
                        <select
                            value={timeFilter}
                            onChange={(e) => setTimeFilter(e.target.value)}
                            style={{
                                width: '100%',
                                padding: '10px 12px',
                                borderRadius: '6px',
                                border: '1px solid #e0e0e0',
                                fontSize: '13px',
                                cursor: 'pointer',
                                backgroundColor: timeFilter !== 'all' ? '#e6fff9' : 'white'
                            }}
                        >
                            <option value="all">All Time</option>
                            <option value="day">Past 24 Hours</option>
                            <option value="week">Past Week</option>
                            <option value="month">Past Month</option>
                        </select>
                    </div>

                    {/* Star Rating Filter */}
                    <div>
                        <label style={{ 
                            display: 'block', 
                            marginBottom: '8px', 
                            fontSize: '13px',
                            fontWeight: '600',
                            color: '#666'
                        }}>
                            Star Rating
                        </label>
                        <select
                            value={ratingFilter}
                            onChange={(e) => setRatingFilter(e.target.value)}
                            style={{
                                width: '100%',
                                padding: '10px 12px',
                                borderRadius: '6px',
                                border: '1px solid #e0e0e0',
                                fontSize: '13px',
                                cursor: 'pointer',
                                backgroundColor: ratingFilter !== 'all' ? '#fff8e1' : 'white'
                            }}
                        >
                            <option value="all">All Ratings</option>
                            <option value="5">⭐⭐⭐⭐⭐ (5 Stars)</option>
                            <option value="4">⭐⭐⭐⭐ (4 Stars)</option>
                            <option value="3">⭐⭐⭐ (3 Stars)</option>
                            <option value="2">⭐⭐ (2 Stars)</option>
                            <option value="1">⭐ (1 Star)</option>
                        </select>
                    </div>
                </div>

                {/* Filter Summary and Reset */}
                <div style={{ 
                    display: 'flex', 
                    justifyContent: 'space-between', 
                    alignItems: 'center',
                    paddingTop: '12px',
                    borderTop: '1px solid #f0f0f0'
                }}>
                    <div style={{ fontSize: '13px', color: '#666' }}>
                        Showing <strong style={{ color: '#20c997' }}>{filteredFeedbacks.length}</strong> of {feedbacks.length} feedback{feedbacks.length !== 1 ? 's' : ''}
                        {(timeFilter !== 'all' || ratingFilter !== 'all') && (
                            <span style={{ color: '#999', marginLeft: '8px' }}>
                                (filtered)
                            </span>
                        )}
                    </div>
                    
                    {(timeFilter !== 'all' || ratingFilter !== 'all') && (
                        <button
                            onClick={resetFilters}
                            style={{
                                padding: '6px 14px',
                                backgroundColor: '#F2F4F7',
                                color: '#344054',
                                border: '1px solid #FFEAD5',
                                borderRadius: '6px',
                                cursor: 'pointer',
                                fontSize: '12px',
                                fontWeight: '600',
                                transition: 'all 0.2s',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '6px'
                            }}
                            onMouseEnter={(e) => {
                                e.target.style.backgroundColor = '#E4E7EC';
                            }}
                            onMouseLeave={(e) => {
                                e.target.style.backgroundColor = '#F2F4F7';
                            }}
                        >
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <line x1="18" y1="6" x2="6" y2="18"></line>
                                <line x1="6" y1="6" x2="18" y2="18"></line>
                            </svg>
                            Clear Filters
                        </button>
                    )}
                </div>
            </div>
            
            {stats && (
                <div style={{
                    backgroundColor: 'white',
                    padding: '24px',
                    borderRadius: '12px',
                    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
                    marginBottom: '32px',
                    border: '1px solid #e0e0e0'
                }}>
                    <h3 style={{ margin: '0 0 24px 0', fontSize: '18px', fontWeight: '600', color: '#333', display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <line x1="18" y1="20" x2="18" y2="10"></line>
                            <line x1="12" y1="20" x2="12" y2="4"></line>
                            <line x1="6" y1="20" x2="6" y2="14"></line>
                        </svg>
                        Statistics Overview
                    </h3>

                    <div style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
                        gap: '24px',
                        marginBottom: '32px'
                    }}>
                        {/* Total Feedbacks */}
                        <div style={{
                            padding: '20px',
                            backgroundColor: '#e3f2fd',
                            borderRadius: '8px',
                            textAlign: 'center'
                        }}>
                            <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#20c997" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ marginBottom: '8px' }}>
                                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                            </svg>
                            <div style={{ fontSize: '28px', fontWeight: '700', color: '#20c997', marginBottom: '4px' }}>
                                {stats.total}
                            </div>
                            <div style={{ fontSize: '13px', color: '#666', fontWeight: '500' }}>
                                Total Feedbacks
                            </div>
                        </div>
                        
                        {/* Average Rating */}
                        <div style={{
                            padding: '20px',
                            backgroundColor: '#fff3e0',
                            borderRadius: '8px',
                            textAlign: 'center'
                        }}>
                            <svg width="36" height="36" viewBox="0 0 24 24" fill="#ff9800" stroke="#ff9800" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ marginBottom: '8px' }}>
                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                            </svg>
                            <div style={{ fontSize: '28px', fontWeight: '700', color: '#ff9800', marginBottom: '4px' }}>
                                {stats.averageRating}
                            </div>
                            <div style={{ fontSize: '13px', color: '#666', fontWeight: '500' }}>
                                Average Rating
                            </div>
                        </div>
                    </div>

                    {/* Rating Distribution */}
                    <div style={{
                        paddingTop: '24px',
                        borderTop: '1px solid #f0f0f0'
                    }}>
                        <h4 style={{ margin: '0 0 16px 0', fontSize: '15px', fontWeight: '600', color: '#333' }}>
                            Rating Distribution
                        </h4>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                            {[5, 4, 3, 2, 1].map((rating) => (
                                <div key={rating} style={{ 
                                    display: 'flex', 
                                    alignItems: 'center',
                                    gap: '12px',
                                    fontSize: '14px'
                                }}>
                                    <span style={{ 
                                        minWidth: '40px',
                                        fontWeight: '600',
                                        color: '#666'
                                    }}>
                                        {rating} ★
                                    </span>
                                    <div style={{
                                        flex: 1,
                                        height: '28px',
                                        backgroundColor: '#f5f5f5',
                                        borderRadius: '14px',
                                        overflow: 'hidden',
                                        position: 'relative'
                                    }}>
                                        <div style={{
                                            height: '100%',
                                            width: stats.total > 0 
                                                ? `${(stats.ratingDistribution[rating] / stats.total) * 100}%`
                                                : '0%',
                                            backgroundColor: '#ffc107',
                                            transition: 'width 0.3s ease',
                                            borderRadius: '14px'
                                        }}></div>
                                    </div>
                                    <span style={{ 
                                        minWidth: '35px',
                                        textAlign: 'right',
                                        fontWeight: '600',
                                        color: '#666',
                                        fontSize: '13px'
                                    }}>
                                        {stats.ratingDistribution[rating]}
                                    </span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            )}

            {/* Scrollable Feedback Container - Shows 3 at a time */}
            <div style={{
                backgroundColor: 'white',
                borderRadius: '12px',
                boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
                overflow: 'hidden'
            }}>
                <div style={{
                    padding: '20px 24px',
                    borderBottom: '1px solid #e0e0e0',
                    backgroundColor: '#f8f9fa',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                }}>
                    <h3 style={{ margin: 0, color: '#333' }}>
                        Feedback List
                    </h3>
                    {filteredFeedbacks.length > 3 && (
                        <span style={{ fontSize: '13px', color: '#666', display: 'flex', alignItems: 'center', gap: '6px' }}>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <polyline points="7 13 12 18 17 13"></polyline>
                                <polyline points="7 6 12 11 17 6"></polyline>
                            </svg>
                            Scroll to view all
                        </span>
                    )}
                </div>

                {/* Scrollable container */}
                <div style={{
                    maxHeight: '600px',
                    overflowY: 'auto',
                    padding: '16px'
                }}>
                    {filteredFeedbacks.length === 0 ? (
                        <div style={{
                            padding: '60px 20px',
                            textAlign: 'center'
                        }}>
                            <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#ccc" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" style={{ marginBottom: '16px', display: 'inline-block' }}>
                                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                                <line x1="9" y1="10" x2="15" y2="10"></line>
                                <line x1="12" y1="7" x2="12" y2="13"></line>
                            </svg>
                            <p style={{ color: '#999', fontSize: '18px', margin: 0 }}>
                                {(timeFilter !== 'all' || ratingFilter !== 'all') 
                                    ? 'No feedbacks match your filters'
                                    : 'No feedbacks yet'
                                }
                            </p>
                        </div>
                    ) : (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                            {filteredFeedbacks.map((feedback) => (
                                <div 
                                    key={feedback.id}
                                    style={{
                                        backgroundColor: '#f8f9fa',
                                        padding: '24px',
                                        borderRadius: '12px',
                                        border: '1px solid #e0e0e0',
                                        transition: 'transform 0.2s, box-shadow 0.2s'
                                    }}
                                    onMouseEnter={(e) => {
                                        e.currentTarget.style.transform = 'translateY(-2px)';
                                        e.currentTarget.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.15)';
                                    }}
                                    onMouseLeave={(e) => {
                                        e.currentTarget.style.transform = 'translateY(0)';
                                        e.currentTarget.style.boxShadow = 'none';
                                    }}
                                >
                                    <div style={{
                                        display: 'flex',
                                        justifyContent: 'space-between',
                                        alignItems: 'flex-start',
                                        marginBottom: '16px',
                                        flexWrap: 'wrap',
                                        gap: '16px'
                                    }}>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                                            <div style={{
                                                width: '48px',
                                                height: '48px',
                                                borderRadius: '50%',
                                                backgroundColor: '#20c997',
                                                color: 'white',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: '20px',
                                                fontWeight: '700'
                                            }}>
                                                {feedback.student_name?.charAt(0).toUpperCase() || '?'}
                                            </div>
                                            <div>
                                                <h4 style={{ margin: '0', color: '#333' }}>
                                                    {feedback.student_name || 'Anonymous'}
                                                </h4>
                                                <span style={{ fontSize: '12px', color: '#999' }}>
                                                    {formatDate(feedback.created_at)}
                                                </span>
                                            </div>
                                        </div>
                                        <div style={{ 
                                            display: 'flex', 
                                            flexDirection: 'column',
                                            alignItems: 'flex-end',
                                            gap: '4px'
                                        }}>
                                            {renderStars(feedback.rating)}
                                            <span style={{ 
                                                fontSize: '14px', 
                                                fontWeight: '600',
                                                color: '#666'
                                            }}>
                                                {feedback.rating}/5
                                            </span>
                                        </div>
                                    </div>
                                    <p style={{ 
                                        margin: 0,
                                        color: '#444',
                                        fontSize: '15px',
                                        lineHeight: '1.6',
                                        padding: '12px 16px',
                                        backgroundColor: 'white',
                                        borderRadius: '8px',
                                        borderLeft: '4px solid #20c997'
                                    }}>
                                        {feedback.feedback_text}
                                    </p>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                {/* Footer indicator */}
                {filteredFeedbacks.length > 0 && (
                    <div style={{
                        padding: '12px',
                        textAlign: 'center',
                        fontSize: '12px',
                        color: '#999',
                        backgroundColor: '#f8f9fa',
                        borderTop: '1px solid #e0e0e0'
                    }}>
                        {filteredFeedbacks.length} feedback{filteredFeedbacks.length !== 1 ? 's' : ''} displayed
                    </div>
                )}
            </div>
        </div>
    );
};

export default AdminFeedbacksTab;