// backend/routes/admin.js
const express = require('express');
const { createClient } = require('@supabase/supabase-js');
const { authenticateUser, requireRole } = require('../middleware/auth');

const router = express.Router();

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

/**
 * POST /api/admin/create-user
 * Creates a new user with specified role
 * Requires: admin role
 */
router.post('/create-user', authenticateUser, requireRole('admin'), async (req, res) => {
  try {
    const { email, password, name, role } = req.body;

    // Validate input
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    if (!['student', 'counselor', 'admin'].includes(role)) {
      return res.status(400).json({ error: 'Invalid role specified' });
    }

    // Create user in Supabase Auth
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true, // Auto-confirm email
      user_metadata: {
        full_name: name || email.split('@')[0]
      }
    });

    if (authError) {
      console.error('Auth error:', authError);
      return res.status(400).json({ 
        error: 'Failed to create user',
        message: authError.message 
      });
    }

    // Wait a moment for the trigger to create the profile
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Update the user profile with the correct role and name
    // (The trigger creates it with default role 'student')
    const { error: updateError } = await supabase
      .from('users')
      .update({
        name: name || email.split('@')[0],
        role: role
      })
      .eq('id', authData.user.id);

    if (updateError) {
      console.error('Profile update error:', updateError);
      
      // Rollback: delete the auth user if update fails
      await supabase.auth.admin.deleteUser(authData.user.id);
      
      return res.status(500).json({ 
        error: 'Failed to update user profile',
        message: updateError.message 
      });
    }

    console.log(`✅ User created: ${email} (${role})`);

    return res.json({
      success: true,
      message: 'User created successfully',
      user: {
        id: authData.user.id,
        email: email,
        name: name || email.split('@')[0],
        role: role
      }
    });

  } catch (err) {
    console.error('Error creating user:', err);
    return res.status(500).json({ 
      error: 'Internal server error',
      message: err.message 
    });
  }
});

/**
 * DELETE /api/admin/delete-user/:userId
 * Deletes a user completely (auth + profile)
 * Requires: admin role
 */
router.delete('/delete-user/:userId', authenticateUser, requireRole('admin'), async (req, res) => {
  try {
    const { userId } = req.params;

    // Delete from auth (this will cascade to users table due to ON DELETE CASCADE)
    const { error: authError } = await supabase.auth.admin.deleteUser(userId);

    if (authError) {
      console.error('Auth deletion error:', authError);
      return res.status(400).json({ 
        error: 'Failed to delete user',
        message: authError.message 
      });
    }

    console.log(`✅ User deleted: ${userId}`);

    return res.json({
      success: true,
      message: 'User deleted successfully'
    });

  } catch (err) {
    console.error('Error deleting user:', err);
    return res.status(500).json({ 
      error: 'Internal server error',
      message: err.message 
    });
  }
});

/**
 * PUT /api/admin/update-user-role/:userId
 * Updates a user's role
 * Requires: admin role
 */
router.put('/update-user-role/:userId', authenticateUser, requireRole('admin'), async (req, res) => {
  try {
    const { userId } = req.params;
    const { role } = req.body;

    if (!['student', 'counselor', 'admin'].includes(role)) {
      return res.status(400).json({ error: 'Invalid role specified' });
    }

    const { error } = await supabase
      .from('users')
      .update({ role })
      .eq('id', userId);

    if (error) {
      console.error('Role update error:', error);
      return res.status(400).json({ 
        error: 'Failed to update role',
        message: error.message 
      });
    }

    console.log(`✅ User role updated: ${userId} -> ${role}`);

    return res.json({
      success: true,
      message: 'Role updated successfully'
    });

  } catch (err) {
    console.error('Error updating role:', err);
    return res.status(500).json({ 
      error: 'Internal server error',
      message: err.message 
    });
  }
});

module.exports = router;