import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "../supabaseClient";
import { checkVideoLinkAccess, getConsultationStatusBadge } from "../utils/consultationTimeUtils";
import "../styles.css";

export default function LandingPage({ session, setSession }) {
  const navigate = useNavigate();
  const user = session?.user;

  const [selectedEmotion, setSelectedEmotion] = useState(null);
  const [consultations, setConsultations] = useState([]);
  const [loadingConsultations, setLoadingConsultations] = useState(true);
  const [userName, setUserName] = useState("");

  useEffect(() => {
    if (user) {
      fetchUserName();
      fetchConsultations();
    }
  }, [user]);

  const fetchUserName = async () => {
    try {
      const { data, error } = await supabase
        .from("users")
        .select("name")
        .eq("id", user.id)
        .single();

      if (error) throw error;
      setUserName(data?.name || user.email?.split("@")[0] || "User");
    } catch (err) {
      console.error("Error fetching user name:", err);
      setUserName(user.email?.split("@")[0] || "User");
    }
  };

  const fetchConsultations = async () => {
    try {
      const { data, error } = await supabase
        .from("consultations")
        .select(`
          id,
          date,
          time,
          status,
          video_link,
          counselor:counselor_id(name, email)
        `)
        .eq("student_id", user.id)
        .in("status", ["pending", "accepted"])
        .order("date", { ascending: true })
        .order("time", { ascending: true });

      if (error) throw error;
      setConsultations(data || []);
    } catch (err) {
      console.error("Error fetching consultations:", err);
    } finally {
      setLoadingConsultations(false);
    }
  };

  async function handleSignOut() {
    await supabase.auth.signOut();
    setSession(null);
    navigate("/");
  }

  // Updated emotions with 1:1 tag mapping - each emotion has its own unique tag
  const emotions = [
    { label: "Happy", icon: "🙂", tag: "happy" },
    { label: "Sad", icon: "😢", tag: "sad" },
    { label: "Angry", icon: "😡", tag: "angry" },
    { label: "Scared", icon: "😨", tag: "scared" },
    { label: "Worried", icon: "😟", tag: "worried" },
    { label: "Tired", icon: "😴", tag: "tired" },
    { label: "Disgusted", icon: "🤢", tag: "disgusted" },
    { label: "Overwhelmed", icon: "😵", tag: "overwhelmed" },
  ];

  function handleBookAppointment() {
    const emotion = emotions.find(e => e.label === selectedEmotion);
    const emotionTag = emotion?.tag || 'general';
    console.log("Booking with emotion:", selectedEmotion, "→ tag:", emotionTag);
    navigate('/booking', { state: { emotion: emotionTag } });
  }

  function handleReadArticles() {
    const emotion = emotions.find(e => e.label === selectedEmotion);
    const emotionTag = emotion?.tag || 'happy';
    console.log("Reading articles for emotion:", selectedEmotion, "→ tag:", emotionTag);
    navigate(`/articles/${emotionTag}`);
  }

  const formatDate = (dateStr) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
      year: "numeric"
    });
  };

  const formatTime = (timeStr) => {
    const [hours, minutes] = timeStr.split(":");
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? "PM" : "AM";
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  const getStatusColor = (status, date, time) => {
    return getConsultationStatusBadge(status, date, time);
  };

  return (
    <div className="landing-root">
      <header className="landing-header">
        <div className="header-left">
          <div className="logo-top">Hinahon</div>
          <div className="tagline-mini">A Mental Health Booking App</div>
        </div>

        <div className="header-right">
          <nav style={{ display: "flex", gap: 16, alignItems: "center" }}>
            <button
              onClick={() => navigate("/about")}
              style={{
                background: "none",
                border: "none",
                color: "#666",
                cursor: "pointer",
                font: "inherit",
                fontSize: "15px",
                fontWeight: "500",
                padding: "8px 12px",
                borderRadius: "6px",
                transition: "all 0.2s"
              }}
              onMouseEnter={(e) => {
                e.target.style.backgroundColor = "#f5f5f5";
                e.target.style.color = "var(--pink)";
              }}
              onMouseLeave={(e) => {
                e.target.style.backgroundColor = "transparent";
                e.target.style.color = "#666";
              }}
            >
              About
            </button>
            <button
              onClick={() => navigate("/articles")}
              style={{
                background: "none",
                border: "none",
                color: "#666",
                cursor: "pointer",
                font: "inherit",
                fontSize: "15px",
                fontWeight: "500",
                padding: "8px 12px",
                borderRadius: "6px",
                transition: "all 0.2s"
              }}
              onMouseEnter={(e) => {
                e.target.style.backgroundColor = "#f5f5f5";
                e.target.style.color = "var(--teal)";
              }}
              onMouseLeave={(e) => {
                e.target.style.backgroundColor = "transparent";
                e.target.style.color = "#666";
              }}
            >
              Articles
            </button>
          </nav>

          <button
            className="btn-profile"
            onClick={() => navigate("/profile")}
          >
            Profile
          </button>
          <button className="btn-logout" onClick={handleSignOut}>
            Sign Out
          </button>
        </div>
      </header>

      <main className="landing-hero">
        <div className="hero-inner">
          <div className="greeting">
            <div className="greet-small">
              Hello, {userName}!
            </div>

            <h2 className="brand-display" style={{ marginTop: 6 }}>
              Hinahon
            </h2>

            <p className="hero-note">
              The Digital Solution to Accessible Mental Health Services in the Philippines.
            </p>

            {/* Student Dashboard - Show ongoing consultations */}
            {consultations.length > 0 && (
              <div style={{
                backgroundColor: "white",
                borderRadius: "12px",
                padding: "20px",
                marginBottom: "24px",
                boxShadow: "var(--card-shadow)",
                border: "1px solid #f0f0f0"
              }}>
                <h3 style={{
                  margin: "0 0 16px 0",
                  fontSize: "18px",
                  color: "var(--text)",
                  fontWeight: "600"
                }}>
                  Your Consultations
                </h3>

                {loadingConsultations ? (
                  <p style={{ color: "#666", fontSize: "14px" }}>Loading...</p>
                ) : (
                  <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                    {consultations.map((consultation) => {
                      const statusInfo = getStatusColor(consultation.status, consultation.date, consultation.time);
                      const accessInfo = checkVideoLinkAccess(consultation.date, consultation.time);
                      
                      return (
                        <div
                          key={consultation.id}
                          style={{
                            backgroundColor: "#f8f9fa",
                            borderRadius: "8px",
                            padding: "16px",
                            border: "1px solid #e0e0e0"
                          }}
                        >
                          <div style={{
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "flex-start",
                            marginBottom: "8px"
                          }}>
                            <div>
                              <div style={{
                                fontSize: "14px",
                                fontWeight: "600",
                                color: "var(--text)",
                                marginBottom: "4px"
                              }}>
                                {consultation.counselor?.name || consultation.counselor?.email || "Counselor"}
                              </div>
                              <div style={{ fontSize: "13px", color: "#666" }}>
                                📅 {formatDate(consultation.date)} • 🕐 {formatTime(consultation.time)}
                              </div>
                            </div>
                            <span style={{
                              padding: "4px 10px",
                              borderRadius: "12px",
                              fontSize: "11px",
                              fontWeight: "600",
                              backgroundColor: statusInfo.bg,
                              color: statusInfo.color,
                              textTransform: "uppercase"
                            }}>
                              {statusInfo.text}
                            </span>
                          </div>

                          {/* Show video link only if accepted AND time is right */}
                          {consultation.status === "accepted" && consultation.video_link && (
                            <>
                              {accessInfo.canAccess ? (
                                <div>
                                  <a
                                    href={consultation.video_link}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    style={{
                                      display: "inline-block",
                                      marginTop: "8px",
                                      padding: "8px 16px",
                                      backgroundColor: "var(--teal)",
                                      color: "white",
                                      textDecoration: "none",
                                      borderRadius: "6px",
                                      fontSize: "13px",
                                      fontWeight: "600"
                                    }}
                                  >
                                    🎥 Join Video Call
                                  </a>
                                  <p style={{
                                    margin: "8px 0 0 0",
                                    fontSize: "12px",
                                    color: "#28a745",
                                    fontStyle: "italic"
                                  }}>
                                    {accessInfo.message}
                                  </p>
                                </div>
                              ) : (
                                <div>
                                  <button
                                    disabled
                                    style={{
                                      display: "inline-block",
                                      marginTop: "8px",
                                      padding: "8px 16px",
                                      backgroundColor: "#e0e0e0",
                                      color: "#999",
                                      border: "none",
                                      borderRadius: "6px",
                                      fontSize: "13px",
                                      fontWeight: "600",
                                      cursor: "not-allowed",
                                      opacity: "0.6"
                                    }}
                                  >
                                    🎥 Join Video Call
                                  </button>
                                  <p style={{
                                    margin: "8px 0 0 0",
                                    fontSize: "12px",
                                    color: accessInfo.reason === 'expired' ? "#d32f2f" : "#856404",
                                    fontStyle: "italic"
                                  }}>
                                    {accessInfo.message}
                                  </p>
                                </div>
                              )}
                            </>
                          )}

                          {consultation.status === "pending" && (
                            <p style={{
                              margin: "8px 0 0 0",
                              fontSize: "12px",
                              color: "#856404",
                              fontStyle: "italic"
                            }}>
                              Waiting for counselor to accept...
                            </p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            <div className="feeling-ask">How are you feeling today?</div>

            <div className="emotions-grid" role="list" aria-label="Emotions">
              {emotions.map((e) => (
                <button
                  key={e.label}
                  className={`emotion ${selectedEmotion === e.label ? "selected" : ""}`}
                  type="button"
                  onClick={() => setSelectedEmotion(e.label)}
                  aria-label={`Select ${e.label} emotion`}
                >
                  <div className="emotion-circle">{e.icon}</div>
                  <div className="emotion-label">{e.label}</div>
                </button>
              ))}
            </div>

            {selectedEmotion && (
              <div className="post-actions">
                <p className="selected-note">
                  You're feeling <strong>{selectedEmotion}</strong>. What would you like to do?
                </p>
                <div className="action-buttons">
                  <button
                    className="btn-action primary"
                    onClick={handleBookAppointment}
                  >
                    📅 Book Appointment
                  </button>
                  <button
                    className="btn-action secondary"
                    onClick={handleReadArticles}
                  >
                    📖 Read Articles
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      <footer className="landing-footer">
        ©2025 TEAM HINAHON | All Rights Reserved
      </footer>
    </div>
  );
}