import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "../supabaseClient";
import { checkVideoLinkAccess, getConsultationStatusBadge } from "../utils/consultationTimeUtils";
import "../styles.css";

export default function LandingPage({ session, setSession }) {
  const navigate = useNavigate();
  const user = session?.user;

  const [selectedEmotion, setSelectedEmotion] = useState(null);
  const [allConsultations, setAllConsultations] = useState([]);
  const [displayedConsultations, setDisplayedConsultations] = useState([]);
  const [loadingConsultations, setLoadingConsultations] = useState(true);
  const [userName, setUserName] = useState("");
  const [hasMore, setHasMore] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  
  const observerTarget = useRef(null);
  const ITEMS_PER_PAGE = 3;

  useEffect(() => {
    if (user) {
      fetchUserName();
      fetchConsultations();
    }
  }, [user]);

  // Setup intersection observer for infinite scroll
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !isLoadingMore) {
          loadMoreConsultations();
        }
      },
      { threshold: 0.1 }
    );

    if (observerTarget.current) {
      observer.observe(observerTarget.current);
    }

    return () => {
      if (observerTarget.current) {
        observer.unobserve(observerTarget.current);
      }
    };
  }, [hasMore, isLoadingMore, displayedConsultations.length]);

  const fetchUserName = async () => {
    try {
      const { data, error } = await supabase
        .from("users")
        .select("name")
        .eq("id", user.id)
        .single();

      if (error) throw error;
      setUserName(data?.name || user.email?.split("@")[0] || "User");
    } catch (err) {
      console.error("Error fetching user name:", err);
      setUserName(user.email?.split("@")[0] || "User");
    }
  };

  const fetchConsultations = async () => {
    try {
      const { data, error } = await supabase
        .from("consultations")
        .select(`
          id,
          date,
          time,
          status,
          video_link,
          reason,
          rejection_reason,
          meeting_ended,
          start_time,
          end_time,
          counselor:counselor_id(name, email)
        `)
        .eq("student_id", user.id)
        .order("date", { ascending: true })
        .order("time", { ascending: true });

      if (error) throw error;
      
      // Prioritize: ongoing > pending > expired/rejected
      const sortedConsultations = prioritizeConsultations(data || []);
      
      setAllConsultations(sortedConsultations);
      setDisplayedConsultations(sortedConsultations.slice(0, ITEMS_PER_PAGE));
      setHasMore(sortedConsultations.length > ITEMS_PER_PAGE);
    } catch (err) {
      console.error("Error fetching consultations:", err);
    } finally {
      setLoadingConsultations(false);
    }
  };

  const prioritizeConsultations = (consultations) => {
    const now = new Date();
    
    const categorized = consultations.map(consultation => {
      // Use checkVideoLinkAccess to get accurate time-based status
      const accessInfo = checkVideoLinkAccess(consultation.date, consultation.time);
      
      let priority = 0;
      let category = '';
      
      // Ongoing (accepted and currently active - can access video link)
      // Also check if meeting hasn't been manually ended
      if (consultation.status === 'accepted' && !consultation.meeting_ended && accessInfo.canAccess && accessInfo.reason === 'active') {
        priority = 1;
        category = 'ongoing';
      }
      // Pending (awaiting counselor response)
      else if (consultation.status === 'pending') {
        priority = 2;
        category = 'pending';
      }
      // Upcoming accepted (future consultations - not started yet)
      else if (consultation.status === 'accepted' && !consultation.meeting_ended && accessInfo.reason === 'not_started') {
        priority = 3;
        category = 'upcoming';
      }
      // Completed (meeting_ended = true or status = completed)
      else if (consultation.meeting_ended || consultation.status === 'completed') {
        priority = 5;
        category = 'completed';
      }
      // Expired/Rejected
      else {
        priority = 4;
        category = 'past';
      }
      
      const consultDate = new Date(`${consultation.date}T${consultation.time}`);
      return { ...consultation, priority, category, consultDate, accessInfo };
    });
    
    // Sort by priority first, then by date
    return categorized.sort((a, b) => {
      if (a.priority !== b.priority) {
        return a.priority - b.priority;
      }
      // For same priority, sort by date (ascending for ongoing/pending/upcoming, descending for past)
      if (a.priority < 4) {
        return a.consultDate - b.consultDate;
      } else {
        return b.consultDate - a.consultDate;
      }
    });
  };

  const loadMoreConsultations = () => {
    if (isLoadingMore) return;
    
    setIsLoadingMore(true);
    
    setTimeout(() => {
      const currentLength = displayedConsultations.length;
      const nextBatch = allConsultations.slice(
        currentLength,
        currentLength + ITEMS_PER_PAGE
      );
      
      setDisplayedConsultations(prev => [...prev, ...nextBatch]);
      setHasMore(currentLength + ITEMS_PER_PAGE < allConsultations.length);
      setIsLoadingMore(false);
    }, 300);
  };

  async function handleSignOut() {
    await supabase.auth.signOut();
    setSession(null);
    navigate("/");
  }

  const emotions = [
    { label: "Happy", icon: "🙂", tag: "happy" },
    { label: "Sad", icon: "😢", tag: "sad" },
    { label: "Angry", icon: "😡", tag: "angry" },
    { label: "Scared", icon: "😨", tag: "scared" },
    { label: "Worried", icon: "😟", tag: "worried" },
    { label: "Tired", icon: "😴", tag: "tired" },
    { label: "Disgusted", icon: "🤢", tag: "disgusted" },
    { label: "Overwhelmed", icon: "😵", tag: "overwhelmed" },
  ];

  function handleBookAppointment() {
    const emotion = emotions.find(e => e.label === selectedEmotion);
    const emotionTag = emotion?.tag || 'general';
    console.log("Booking with emotion:", selectedEmotion, "→ tag:", emotionTag);
    navigate('/booking', { state: { emotion: emotionTag } });
  }

  function handleReadArticles() {
    const emotion = emotions.find(e => e.label === selectedEmotion);
    const emotionTag = emotion?.tag || 'happy';
    console.log("Reading articles for emotion:", selectedEmotion, "→ tag:", emotionTag);
    navigate(`/articles/${emotionTag}`);
  }

  const formatDate = (dateStr) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
      year: "numeric"
    });
  };

  const formatTime = (timeStr) => {
    const [hours, minutes] = timeStr.split(":");
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? "PM" : "AM";
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  const getStatusColor = (status, date, time) => {
    return getConsultationStatusBadge(status, date, time);
  };

  return (
    <div className="landing-root">
      <header className="landing-header">
        <div className="header-left">
          <div className="logo-top">Hinahon</div>
          <div className="tagline-mini">A Mental Health Booking App</div>
        </div>

        <div className="header-right">
          <nav style={{ display: "flex", gap: 16, alignItems: "center" }}>
            <button
              onClick={() => navigate("/about")}
              style={{
                background: "none",
                border: "none",
                color: "#666",
                cursor: "pointer",
                font: "inherit",
                fontSize: "15px",
                fontWeight: "500",
                padding: "8px 12px",
                borderRadius: "6px",
                transition: "all 0.2s"
              }}
              onMouseEnter={(e) => {
                e.target.style.backgroundColor = "#f5f5f5";
                e.target.style.color = "var(--pink)";
              }}
              onMouseLeave={(e) => {
                e.target.style.backgroundColor = "transparent";
                e.target.style.color = "#666";
              }}
            >
              About
            </button>
            <button
              onClick={() => navigate("/articles")}
              style={{
                background: "none",
                border: "none",
                color: "#666",
                cursor: "pointer",
                font: "inherit",
                fontSize: "15px",
                fontWeight: "500",
                padding: "8px 12px",
                borderRadius: "6px",
                transition: "all 0.2s"
              }}
              onMouseEnter={(e) => {
                e.target.style.backgroundColor = "#f5f5f5";
                e.target.style.color = "var(--teal)";
              }}
              onMouseLeave={(e) => {
                e.target.style.backgroundColor = "transparent";
                e.target.style.color = "#666";
              }}
            >
              Articles
            </button>
          </nav>

          <button
            className="btn-profile"
            onClick={() => navigate("/profile")}
          >
            Profile
          </button>
          <button className="btn-logout" onClick={handleSignOut}>
            Sign Out
          </button>
        </div>
      </header>

      <main className="landing-hero">
        <div className="hero-inner">
          <div className="greeting">
            <div className="greet-small">
              Hello, {userName}!
            </div>

            <h2 className="brand-display" style={{ marginTop: 6 }}>
              Hinahon
            </h2>

            <p className="hero-note">
              The Digital Solution to Accessible Mental Health Services in the Philippines.
            </p>

            {/* Student Dashboard - Show consultations with infinite scroll */}
            {allConsultations.length > 0 && (
              <div style={{
                backgroundColor: "white",
                borderRadius: "12px",
                padding: "20px",
                marginBottom: "24px",
                boxShadow: "var(--card-shadow)",
                border: "1px solid #f0f0f0"
              }}>
                <h3 style={{
                  margin: "0 0 16px 0",
                  fontSize: "18px",
                  color: "var(--text)",
                  fontWeight: "600"
                }}>
                  Your Consultations
                </h3>

                {loadingConsultations ? (
                  <p style={{ color: "#666", fontSize: "14px" }}>Loading...</p>
                ) : (
                  <>
                    {/* Scrollable container with max height */}
                    <div style={{
                      maxHeight: "500px",
                      overflowY: "auto",
                      paddingRight: "8px"
                    }}>
                      <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                        {displayedConsultations.map((consultation) => {
                          const statusInfo = getStatusColor(consultation.status, consultation.date, consultation.time);
                          const accessInfo = consultation.accessInfo || checkVideoLinkAccess(consultation.date, consultation.time);
                          
                          return (
                            <div
                              key={consultation.id}
                              style={{
                                backgroundColor: "#f8f9fa",
                                borderRadius: "8px",
                                padding: "16px",
                                border: "1px solid #e0e0e0"
                              }}
                            >
                              <div style={{
                                display: "flex",
                                justifyContent: "space-between",
                                alignItems: "flex-start",
                                marginBottom: "8px"
                              }}>
                                <div>
                                  <div style={{
                                    fontSize: "14px",
                                    fontWeight: "600",
                                    color: "var(--text)",
                                    marginBottom: "4px"
                                  }}>
                                    {consultation.counselor?.name || consultation.counselor?.email || "Counselor"}
                                  </div>
                                  <div style={{ fontSize: "13px", color: "#666" }}>
                                    📅 {formatDate(consultation.date)} • 🕐 {formatTime(consultation.time)}
                                  </div>
                                </div>
                                <span style={{
                                  padding: "4px 10px",
                                  borderRadius: "12px",
                                  fontSize: "11px",
                                  fontWeight: "600",
                                  backgroundColor: statusInfo.bg,
                                  color: statusInfo.color,
                                  textTransform: "uppercase"
                                }}>
                                  {statusInfo.text}
                                </span>
                              </div>

                              {/* Show reason if exists */}
                              {consultation.reason && (
                                <div style={{
                                  backgroundColor: "#fff9e6",
                                  padding: "10px",
                                  borderRadius: "6px",
                                  marginBottom: "8px"
                                }}>
                                  <p style={{
                                    margin: "0 0 4px 0",
                                    fontSize: "12px",
                                    fontWeight: "600",
                                    color: "#555"
                                  }}>
                                    Reason:
                                  </p>
                                  <p style={{
                                    margin: "0",
                                    fontSize: "12px",
                                    color: "#666"
                                  }}>
                                    {consultation.reason}
                                  </p>
                                </div>
                              )}

                              {/* Show rejection reason if rejected */}
                              {consultation.status === "rejected" && consultation.rejection_reason && (
                                <div style={{
                                  backgroundColor: "#ffe6e6",
                                  padding: "10px",
                                  borderRadius: "6px",
                                  marginBottom: "8px"
                                }}>
                                  <p style={{
                                    margin: "0 0 4px 0",
                                    fontSize: "12px",
                                    fontWeight: "600",
                                    color: "#c62828"
                                  }}>
                                    Rejection Reason:
                                  </p>
                                  <p style={{
                                    margin: "0",
                                    fontSize: "12px",
                                    color: "#d32f2f"
                                  }}>
                                    {consultation.rejection_reason}
                                  </p>
                                </div>
                              )}

                              {/* Show video link only if accepted AND time is right AND not ended */}
                              {consultation.status === "accepted" && consultation.video_link && !consultation.meeting_ended && (
                                <>
                                  {accessInfo.canAccess ? (
                                    <div>
                                      <a
                                        href={consultation.video_link}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        style={{
                                          display: "inline-block",
                                          marginTop: "8px",
                                          padding: "8px 16px",
                                          backgroundColor: "var(--teal)",
                                          color: "white",
                                          textDecoration: "none",
                                          borderRadius: "6px",
                                          fontSize: "13px",
                                          fontWeight: "600"
                                        }}
                                      >
                                        🎥 Join Video Call
                                      </a>
                                      <p style={{
                                        margin: "8px 0 0 0",
                                        fontSize: "12px",
                                        color: "#28a745",
                                        fontStyle: "italic"
                                      }}>
                                        {accessInfo.message}
                                      </p>
                                    </div>
                                  ) : (
                                    <div>
                                      <button
                                        disabled
                                        style={{
                                          display: "inline-block",
                                          marginTop: "8px",
                                          padding: "8px 16px",
                                          backgroundColor: "#e0e0e0",
                                          color: "#999",
                                          border: "none",
                                          borderRadius: "6px",
                                          fontSize: "13px",
                                          fontWeight: "600",
                                          cursor: "not-allowed",
                                          opacity: "0.6"
                                        }}
                                      >
                                        🎥 Join Video Call
                                      </button>
                                      <p style={{
                                        margin: "8px 0 0 0",
                                        fontSize: "12px",
                                        color: accessInfo.reason === 'expired' ? "#d32f2f" : "#856404",
                                        fontStyle: "italic"
                                      }}>
                                        {accessInfo.message}
                                      </p>
                                    </div>
                                  )}
                                </>
                              )}

                              {consultation.status === "pending" && (
                                <p style={{
                                  margin: "8px 0 0 0",
                                  fontSize: "12px",
                                  color: "#856404",
                                  fontStyle: "italic"
                                }}>
                                  Waiting for counselor to accept...
                                </p>
                              )}

                              {consultation.meeting_ended && (
                                <p style={{
                                  margin: "8px 0 0 0",
                                  fontSize: "12px",
                                  color: "#28a745",
                                  fontStyle: "italic",
                                  fontWeight: "600"
                                }}>
                                  ✅ Meeting completed
                                </p>
                              )}
                            </div>
                          );
                        })}
                      </div>

                      {/* Infinite scroll trigger */}
                      {hasMore && (
                        <div
                          ref={observerTarget}
                          style={{
                            padding: "16px",
                            textAlign: "center",
                            color: "#666",
                            fontSize: "14px"
                          }}
                        >
                          {isLoadingMore ? (
                            <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "8px" }}>
                              <div style={{
                                width: "16px",
                                height: "16px",
                                border: "2px solid #f3f3f3",
                                borderTop: "2px solid var(--teal)",
                                borderRadius: "50%",
                                animation: "spin 1s linear infinite"
                              }} />
                              Loading more...
                            </div>
                          ) : (
                            "Scroll for more"
                          )}
                        </div>
                      )}

                      {!hasMore && displayedConsultations.length > ITEMS_PER_PAGE && (
                        <div style={{
                          padding: "16px",
                          textAlign: "center",
                          color: "#999",
                          fontSize: "13px",
                          fontStyle: "italic"
                        }}>
                          No more consultations
                        </div>
                      )}
                    </div>
                  </>
                )}
              </div>
            )}

            <div className="feeling-ask">How are you feeling today?</div>

            <div className="emotions-grid" role="list" aria-label="Emotions">
              {emotions.map((e) => (
                <button
                  key={e.label}
                  className={`emotion ${selectedEmotion === e.label ? "selected" : ""}`}
                  type="button"
                  onClick={() => setSelectedEmotion(e.label)}
                  aria-label={`Select ${e.label} emotion`}
                >
                  <div className="emotion-circle">{e.icon}</div>
                  <div className="emotion-label">{e.label}</div>
                </button>
              ))}
            </div>

            {selectedEmotion && (
              <div className="post-actions">
                <p className="selected-note">
                  You're feeling <strong>{selectedEmotion}</strong>. What would you like to do?
                </p>
                <div className="action-buttons">
                  <button
                    className="btn-action primary"
                    onClick={handleBookAppointment}
                  >
                    📅 Book Appointment
                  </button>
                  <button
                    className="btn-action secondary"
                    onClick={handleReadArticles}
                  >
                    📖 Read Articles
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      <footer className="landing-footer">
        ©2025 TEAM HINAHON | All Rights Reserved
      </footer>

      <style>{`
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}