import React, { useState, useEffect } from 'react';

export default function BackToTopButton({ 
  showAfter = 300, 
  className = '',
  style = {}
}) {
  const [isVisible, setIsVisible] = useState(false);

  // Show button when page is scrolled down
  useEffect(() => {
    const toggleVisibility = () => {
      if (window.pageYOffset > showAfter) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', toggleVisibility);

    return () => {
      window.removeEventListener('scroll', toggleVisibility);
    };
  }, [showAfter]);

  // Scroll to top smoothly
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <>
      <style>{`
        .back-to-top-button {
          position: fixed;
          bottom: 40px;
          right: 40px;
          width: 50px;
          height: 50px;
          border-radius: 50%;
          background: linear-gradient(135deg, #c71e70 0%, #00bfa5 100%);
          color: white;
          border: none;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 24px;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
          transition: all 0.3s ease;
          z-index: 999;
          opacity: 0;
          visibility: hidden;
          transform: translateY(20px);
          padding: 0;
        }

        .back-to-top-button.visible {
          opacity: 1;
          visibility: visible;
          transform: translateY(0);
        }

        .back-to-top-button:hover {
          transform: translateY(-5px);
          box-shadow: 0 8px 20px rgba(199, 30, 112, 0.4);
        }

        .back-to-top-button:active {
          transform: translateY(-2px);
        }

        /* Mobile responsive */
        @media (max-width: 768px) {
          .back-to-top-button {
            bottom: 20px;
            right: 20px;
            width: 45px;
            height: 45px;
            font-size: 20px;
          }
        }

        /* Reduced motion for accessibility */
        @media (prefers-reduced-motion: reduce) {
          .back-to-top-button {
            transition: none;
          }
        }
      `}</style>

      <button
        className={`back-to-top-button ${isVisible ? 'visible' : ''} ${className}`}
        onClick={scrollToTop}
        aria-label="Back to top"
        style={style}
      >
        ↑
      </button>
    </>
  );
}

